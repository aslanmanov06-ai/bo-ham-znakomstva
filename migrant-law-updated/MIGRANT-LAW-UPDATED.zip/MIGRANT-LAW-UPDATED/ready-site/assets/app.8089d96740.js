// Миграционный юрист — интерактивность страницы. Без библиотек.
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Уведомление о cookie (только технические cookie, согласие не требуется) ---------- */
  var cookie = $('.cookie');
  var KEY = 'sv-cookie-notice';
  var seen = false;
  try { seen = localStorage.getItem(KEY) === '1'; } catch (e) { /* приватный режим */ }
  if (cookie && !seen) {
    cookie.hidden = false;
    $('.cookie-ok', cookie).addEventListener('click', function () {
      try { localStorage.setItem(KEY, '1'); } catch (e) { /* ничего */ }
      cookie.hidden = true;
    });
  }

  /* ---------- Обращение субъекта ПДн (страница /legal/withdraw/) ---------- */
  var wform = $('.wform');
  if (wform) {
    wform.addEventListener('submit', function (e) {
      e.preventDefault();
      var err = $('.form-error', wform);
      var contact = wform.elements.contact.value.trim();
      if (!contact) { err.textContent = 'Укажите контакт, который вы оставляли в заявке'; wform.elements.contact.focus(); return; }
      err.textContent = '';
      var btn = $('button[type=submit]', wform);
      btn.disabled = true;
      var kind = $('input[name=kind]:checked', wform);
      fetch('/api/withdraw', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
        contact: contact, name: wform.elements.name.value.trim(), kind: kind ? kind.value : 'withdraw',
        comment: wform.elements.comment.value.trim(), website: wform.elements.website.value
      }) }).then(function (r) { return r.ok ? r.json() : Promise.reject(r.status); })
        .then(function () { wform.hidden = true; $('.wdone').hidden = false; })
        .catch(function () { err.textContent = 'Не удалось отправить. Напишите нам на e-mail, указанный выше.'; btn.disabled = false; });
    });
  }

  /* ---------- Прайс: ссылка на раздел раскрывает его ---------- */
  function openBlock() {
    var d = location.hash && document.getElementById(location.hash.slice(1));
    if (d && d.tagName === 'DETAILS') d.open = true;
  }
  if ($('.pblock')) { openBlock(); window.addEventListener('hashchange', openBlock); }


  /* ---------- Страница заказа инструкции (/self/order/?t=…&l=…) ---------- */
  // Токен в адресе — секрет доступа к файлам: страница отдаётся с Referrer-Policy no-referrer.
  var orderBox = $('#order');
  if (orderBox) {
    var od = JSON.parse($('#order-data').textContent);
    var qs = new URLSearchParams(location.search);
    var ol = od.strings[qs.get('l')] ? qs.get('l') : 'ru';
    var os = od.strings[ol];
    var tok = qs.get('t') || '';
    var oesc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
    var h1 = $('.doc-body h1'); if (h1) h1.textContent = os.title;
    document.documentElement.lang = ol;
    var help = '<p class="order-help">' + oesc(os.help) + ' <a href="tel:' + od.tel + '">' + oesc(od.phone) + '</a> · <a href="' + od.wa + '" rel="noopener noreferrer" target="_blank">WhatsApp</a></p>';
    var retry = '<a class="btn btn-gold" href="' + os.path + '#self">' + oesc(os.retry) + '</a>';
    var tries = 0;
    var load;
    var render = function (o) {
      if (!o) { orderBox.innerHTML = '<p class="order-msg">' + oesc(os.notFound) + '</p>' + retry + help; return; }
      var head = '<p class="order-no">' + oesc(os.order) + o.id + ' · ' + oesc(o.title) + '</p>';
      if (o.status === 'paid') {
        var until = new Date(o.until).toLocaleDateString('ru-RU');
        orderBox.innerHTML = head + '<p class="order-msg order-ok">' + oesc(os.paid) + '</p><ul class="order-files">' + o.files.map(function (f) {
          return '<li><span>' + oesc(f) + '</span><a class="btn btn-gold" href="/api/shop/file?t=' + encodeURIComponent(tok) + '&amp;f=' + encodeURIComponent(f) + '" download>' + oesc(os.download) + '</a></li>';
        }).join('') + '</ul><p class="order-save">' + oesc(os.save.replace('%', until)) + '</p>' + help;
        return;
      }
      if (o.status === 'canceled' || o.status === 'error') { orderBox.innerHTML = head + '<p class="order-msg">' + oesc(os.canceled) + '</p>' + retry + help; return; }
      if (o.status === 'expired') { orderBox.innerHTML = head + '<p class="order-msg">' + oesc(os.expired) + '</p>' + help; return; }
      orderBox.innerHTML = head + '<p class="order-msg order-wait"><span class="spin" aria-hidden="true"></span>' + oesc(os.wait) + '</p>' + help;
      if (++tries < 200) setTimeout(load, tries < 20 ? 3000 : 10000);
    };
    load = function () {
      fetch('/api/shop/status?t=' + encodeURIComponent(tok), { cache: 'no-store' })
        .then(function (r) { if (r.status === 404) return null; if (!r.ok) throw r.status; return r.json(); })
        .then(render)
        .catch(function () { if (++tries < 200) setTimeout(load, 5000); });
    };
    if (/^[a-f0-9]{48}$/.test(tok)) load(); else render(null);
  }

  var dataEl = document.getElementById('page-data');
  if (!dataEl) return;
  var data = JSON.parse(dataEl.textContent);

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; });
  }
  function restart(el, cls) { el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); }

  /* ---------- Шапка: меню языков и меню на телефоне ---------- */
  var langBtn = $('.lang-btn');
  var langMenu = $('#lang-menu');
  var menuBtn = $('.menu-btn');
  var mnav = $('#mnav');
  function setLang(open) {
    langBtn.setAttribute('aria-expanded', String(open));
    langMenu.hidden = !open;
  }
  function setMenu(open) {
    if (!mnav) return;
    mnav.hidden = !open;
    menuBtn.setAttribute('aria-expanded', String(open));
    document.body.classList.toggle('menu-open', open);
  }
  langBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    setMenu(false);
    setLang(langMenu.hidden);
  });
  document.addEventListener('click', function (e) {
    if (!langMenu.hidden && !langMenu.contains(e.target)) setLang(false);
  });
  if (menuBtn) {
    menuBtn.addEventListener('click', function () { setLang(false); setMenu(mnav.hidden); });
    $$('a', mnav).forEach(function (a) { a.addEventListener('click', function () { setMenu(false); }); });
  }
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (!langMenu.hidden) { setLang(false); langBtn.focus(); } else if (mnav && !mnav.hidden) { setMenu(false); menuBtn.focus(); }
  });
  // Шапка прилипает; после начала прокрутки становится плотнее.
  var header = $('.header');
  function onScroll() { header.classList.toggle('scrolled', window.scrollY > 8); }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- «У меня…» → «Ваш план» ---------- */
  var sits = $$('.sit');
  var plan = $('#plan');
  var form = $('.form');
  var narrow = window.matchMedia('(max-width: 760px)');

  // Страна: для граждан ЕАЭС (Казахстан, Кыргызстан) — свои варианты вместо патента.
  var ctyBtns = $$('.cty-b');
  var ctyNote = $('.cty-note');
  var pressed = $('.cty-b[aria-pressed="true"]');
  var eaeu = !!pressed && data.cty.eaeu.indexOf(pressed.getAttribute('data-c')) >= 0;
  var curSit = +($('.sit[aria-checked="true"]') || { getAttribute: function () { return 0; } }).getAttribute('data-i');
  function plansNow() { return eaeu ? data.cty.plans : data.plans; }
  ctyBtns.forEach(function (b) {
    b.addEventListener('click', function () {
      var c = b.getAttribute('data-c');
      ctyBtns.forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
      eaeu = data.cty.eaeu.indexOf(c) >= 0;
      if (form) form.elements.country.value = c;
      ctyNote.textContent = eaeu ? data.cty.notes.eaeu : c === 'other' ? data.cty.notes.other : data.cty.notes.patent;
      var labels = eaeu ? data.cty.sits : data.cty.baseSits;
      sits.forEach(function (s, k) { $('.sit-t', s).textContent = labels[k]; });
      showPlan(curSit, false);
      if (!reduce) { restart($('.sits-list'), 'swap'); restart($('.plan-in', plan), 'swap'); }
    });
  });

  function showPlan(i, fromUser) {
    curSit = i;
    var p = plansNow()[i];
    sits.forEach(function (b, k) {
      b.setAttribute('aria-checked', String(k === i));
      b.tabIndex = k === i ? 0 : -1;
    });
    plan.classList.toggle('is-urgent', p.urgent);
    $('.plan-tag', plan).textContent = p.urgent ? data.urgentTag : data.tag;
    $('.plan-title', plan).textContent = p.title;
    $('.plan-price', plan).textContent = p.price;
    $('.plan-lead', plan).textContent = p.lead;
    $('.plan-bring-v', plan).textContent = p.bring;
    $('.plan-steps', plan).innerHTML = p.steps.map(function (s, k) { return '<li><b>' + (k + 1) + '</b><span>' + esc(s) + '</span></li>'; }).join('');
    var cta = $('.plan-cta', plan);
    cta.textContent = p.urgent ? data.callNow : data.discuss;
    cta.href = p.urgent ? data.tel : '#contact';
    cta.classList.toggle('btn-urgent', p.urgent);
    cta.classList.toggle('btn-gold', !p.urgent);
    if (form) { form.elements.stage.value = p.stage; form.elements.situation.value = p.title; }
    if (!fromUser || reduce) return;
    restart($('.plan-head', plan), 'swap');
    [$('.plan-lead', plan), $('.plan-steps', plan)].forEach(function (el) { restart(el, 'swap'); el.classList.add('swap-2'); });
    [$('.plan-bring', plan), $('.plan-actions', plan)].forEach(function (el) { restart(el, 'swap'); el.classList.add('swap-3'); });
    // На телефоне план ниже списка — показываем его, иначе выбор не виден.
    if (narrow.matches) plan.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  sits.forEach(function (b, i) {
    b.addEventListener('click', function () { showPlan(i, true); });
    // Группа радиокнопок: стрелки переключают выбор.
    b.addEventListener('keydown', function (e) {
      var d = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 }[e.key];
      if (!d) return;
      e.preventDefault();
      var n = (i + d + sits.length) % sits.length;
      showPlan(n, false);
      sits[n].focus();
    });
  });

  /* ---------- Эффекты: свет под курсором, лёгкий наклон карточек, появление секций ---------- */
  // Свет под курсором (идея SpotlightCard): координаты курсора — в переменные --mx/--my карточки (первый экран).
  var fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  if (fine) {
    $$('.act').forEach(function (el) {
      var tilt = !reduce; // лёгкий наклон (идея TiltedCard)
      var traf = 0, ex = 0, ey = 0;
      function apply() {
        traf = 0;
        var r = el.getBoundingClientRect();
        var x = (ex - r.left) / r.width, y = (ey - r.top) / r.height;
        el.style.setProperty('--mx', (x * 100).toFixed(1) + '%');
        el.style.setProperty('--my', (y * 100).toFixed(1) + '%');
        if (tilt) el.style.transform = 'perspective(900px) rotateX(' + ((0.5 - y) * 5).toFixed(2) + 'deg) rotateY(' + ((x - 0.5) * 6).toFixed(2) + 'deg) translateY(-3px)';
      }
      el.addEventListener('pointermove', function (e) { ex = e.clientX; ey = e.clientY; if (!traf) traf = requestAnimationFrame(apply); });
      el.addEventListener('pointerleave', function () { if (traf) { cancelAnimationFrame(traf); traf = 0; } if (tilt) el.style.transform = ''; });
    });
  }
  // Секции плавно появляются при прокрутке (идея FadeContent). Без IntersectionObserver и при reduced-motion — видны сразу.
  if (!reduce && 'IntersectionObserver' in window) {
    var rio2 = new IntersectionObserver(function (es) {
      es.forEach(function (x) { if (x.isIntersecting) { x.target.classList.add('rv-in'); rio2.unobserve(x.target); } });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.01 });
    // Нижние разделы: появление, прорисовка контуров иконок, линия «Как мы работаем» — по классу .rv-in (styles.css).
    $$('main > .section, .lower > .section, .footer').forEach(function (el) {
      if (el.getBoundingClientRect().top < window.innerHeight * 0.9) return; // уже на экране — не прячем
      el.classList.add('rv');
      rio2.observe(el);
    });
  }

  /* ---------- Частые вопросы и «Что я получу»: ответ раскрывается плавно, без скачка ---------- */
  $$('details.q, details.shop-get, details.shop-cmp').forEach(function (d) {
    var sum = $('summary', d);
    var body = function () { return d.lastElementChild; };
    var anim = null;
    sum.addEventListener('click', function (e) {
      if (reduce || !body().animate) return; // без анимации — обычное поведение details
      e.preventDefault();
      var el = body();
      if (anim) anim.cancel();
      if (!d.open) {
        d.open = true;
        var h = el.offsetHeight;
        anim = el.animate([{ height: '0px', opacity: 0 }, { height: h + 'px', opacity: 1 }], { duration: 320, easing: 'cubic-bezier(.2,.8,.2,1)' });
        anim.onfinish = function () { anim = null; };
      } else {
        d.classList.add('closing');
        anim = el.animate([{ height: el.offsetHeight + 'px', opacity: 1 }, { height: '0px', opacity: 0 }], { duration: 260, easing: 'ease-in' });
        anim.onfinish = function () { d.open = false; d.classList.remove('closing'); anim = null; };
        anim.oncancel = function () { d.classList.remove('closing'); };
      }
    });
  });

  /* ---------- Заявка ---------- */
  var errBox = $('.form-error', form);
  var submitBtn = $('.submit', form);
  form.elements.consent.addEventListener('change', function () {
    if (form.elements.consent.checked) { $('.check-box', form).classList.remove('invalid'); if (errBox.textContent === data.errConsent) errBox.textContent = ''; }
  });
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var name = form.elements.name.value.trim();
    var contact = form.elements.contact.value.trim();
    form.elements.name.parentNode.classList.toggle('invalid', !name);
    form.elements.contact.parentNode.classList.toggle('invalid', !contact);
    if (!name || !contact) {
      errBox.textContent = data.errRequired;
      (name ? form.elements.contact : form.elements.name).focus();
      return;
    }
    var consent = form.elements.consent;
    $('.check-box', form).classList.toggle('invalid', !consent.checked);
    if (!consent.checked) {
      errBox.textContent = data.errConsent;
      consent.focus();
      return;
    }
    errBox.textContent = '';
    submitBtn.disabled = true;
    var label = submitBtn.textContent;
    submitBtn.textContent = data.sending;
    var body = {
      name: name, contact: contact, message: form.elements.message.value.trim(),
      stage: form.elements.stage.value, country: form.elements.country.value, lang: form.elements.lang.value, website: form.elements.website.value,
      consent: 'yes', consent_version: form.elements.consent_version.value,
      page: location.pathname
    };
    fetch('/api/lead', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      .then(function (r) { return r.ok ? r.json() : Promise.reject(r.status); })
      .then(function (res) { showDone(res && res.id); })
      .catch(function () {
        errBox.textContent = data.errNetwork;
        submitBtn.disabled = false;
        submitBtn.textContent = label;
      });
  });
  function showDone(id) {
    var slot = $('.form-slot');
    slot.innerHTML = '<div class="done" tabindex="-1"><span class="done-mark" aria-hidden="true"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg></span>' +
      '<h3>' + esc(data.doneTitle) + '</h3><p>' + esc(data.doneText) + '</p>' +
      '<p>' + esc(data.doneNo) + ': <span class="done-no">ML-' + String(id || 1).padStart(4, '0') + '</span></p></div>';
    $('.done', slot).focus({ preventScroll: true });
  }

  /* ---------- «Оформите документы самостоятельно»: анкета → заказ → оплата ЮKassa ---------- */
  var shop = data.shop;
  var dlg = $('#shop-dlg');
  if (shop && dlg && typeof dlg.showModal === 'function') {
    var S = shop.s;
    var shopPay = true; // уточняется ответом /api/shop/products
    var rubs = function (n) { return Number(n).toLocaleString('ru-RU').replace(/\s/g, '\u00a0') + '\u00a0₽'; }; // неразрывные пробелы: цена не переносится
    var byId = function (id) { return shop.products.filter(function (p) { return p.id === id; })[0]; };
    var curP = null;
    var steps = $$('.dlg-step', dlg);
    var step = function (name) {
      steps.forEach(function (el) { el.hidden = el.getAttribute('data-step') !== name; });
      var first = $('[data-step="' + name + '"] input, [data-step="' + name + '"] button', dlg);
      if (first && name !== 'quiz') first.focus();
    };
    var sform = $('.shop-form', dlg);
    var serr = $('.form-error', sform);
    var payBtn = $('.co-pay', sform);
    var nextBtn = $('.dlg-next', dlg);
    var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    var quizReady = function () { return ['q1', 'q2', 'q3'].every(function (n) { return $('input[name=' + n + ']:checked', dlg); }); };
    $$('.qz input', dlg).forEach(function (r) { r.addEventListener('change', function () { nextBtn.disabled = !quizReady(); }); });
    var setPay = function (can) {
      payBtn.hidden = !can;
      payBtn.disabled = !can;
      $('.co-off', sform).hidden = can;
      $('.co-consult', sform).hidden = can;
    };

    var openShop = function (id) {
      curP = byId(id);
      if (!curP) return;
      $('.dlg-pt', dlg).textContent = curP.title;
      $('.dlg-pp', dlg).textContent = rubs(curP.price);
      $('.qz-q3', dlg).textContent = S.q3[curP.id] || S.q3.rvp;
      $$('.qz input', dlg).forEach(function (r) { r.checked = false; });
      nextBtn.disabled = true;
      serr.textContent = '';
      payBtn.textContent = S.pay.replace('%', rubs(curP.price));
      setPay(shopPay && curP.ready);
      step('quiz');
      dlg.showModal();
    };
    $$('.shop-buy').forEach(function (b) { b.addEventListener('click', function () { openShop(b.getAttribute('data-p')); }); });
    $('.dlg-x', dlg).addEventListener('click', function () { dlg.close(); });
    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
    $$('.dlg-consult', dlg).forEach(function (a) { a.addEventListener('click', function () { dlg.close(); }); });
    $('.dlg-back', dlg).addEventListener('click', function () { step('quiz'); });

    nextBtn.addEventListener('click', function () {
      var v = function (n) { return $('input[name=' + n + ']:checked', dlg).value; };
      var risk = v('q1') !== 'yes' || v('q2') === 'yes';
      var soft = v('q3') !== 'yes';
      $('.res-t', dlg).textContent = risk ? S.riskTitle : S.okTitle;
      $('.res-x', dlg).textContent = risk ? S.riskText : soft ? S.softText : S.okText;
      $('[data-step="result"]', dlg).classList.toggle('is-risk', risk);
      var go = $('.res-go', dlg);
      go.textContent = risk ? S.anyway : S.next;
      go.className = 'btn res-go ' + (risk ? 'btn-line' : 'btn-gold');
      $('[data-step="result"] .dlg-consult', dlg).className = 'btn dlg-consult ' + (risk ? 'btn-gold' : 'btn-line');
      step('result');
    });
    $('.res-go', dlg).addEventListener('click', function () { step('checkout'); });

    sform.addEventListener('submit', function (e) {
      e.preventDefault();
      var email = sform.elements.email.value.trim();
      var bad = !EMAIL.test(email);
      sform.elements.email.parentNode.classList.toggle('invalid', bad);
      if (bad) { serr.textContent = S.errEmail; sform.elements.email.focus(); return; }
      if (!sform.elements.consent.checked) { serr.textContent = data.errConsent; sform.elements.consent.focus(); return; }
      if (!sform.elements.offer.checked) { serr.textContent = S.errOffer; sform.elements.offer.focus(); return; }
      serr.textContent = '';
      payBtn.disabled = true;
      payBtn.textContent = S.toPay;
      fetch('/api/shop/order', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
        product: curP.id, email: email, consent: true, offer: true, consent_version: shop.consentVersion,
        lang: data.lang, website: sform.elements.website.value
      }) }).then(function (r) { return r.json().catch(function () { return {}; }).then(function (b) { return { ok: r.ok, status: r.status, b: b }; }); })
        .then(function (r) {
          if (r.ok && r.b.url) { location.assign(r.b.url); return; }
          if (r.status === 503 || r.status === 409) { setPay(false); return; }
          throw r.status;
        })
        .catch(function () {
          serr.textContent = S.errPay;
          payBtn.disabled = false;
          payBtn.textContent = S.pay.replace('%', rubs(curP.price));
        });
    });

    /* Направления слева, описание справа (вкладки). Неактивные описания скрыты классом, а не атрибутом hidden:
       hidden означает «товар снят с продажи на сервере». */
    var tabs = $$('.shop-tab');
    var selectTab = function (tab, focus) {
      if (!tab || tab.hidden) return;
      tabs.forEach(function (b) {
        var on = b === tab;
        b.setAttribute('aria-selected', String(on));
        b.tabIndex = on ? 0 : -1;
        var panel = document.getElementById(b.getAttribute('aria-controls'));
        if (panel) {
          panel.classList.toggle('is-active', on);
          if (on && !reduce) restart(panel, 'swap');
        }
      });
      if (focus) tab.focus();
    };
    tabs.forEach(function (b, i) {
      b.addEventListener('click', function () { selectTab(b, false); });
      b.addEventListener('keydown', function (e) {
        var vis = tabs.filter(function (x) { return !x.hidden; });
        var k = vis.indexOf(b);
        var n = { ArrowDown: k + 1, ArrowRight: k + 1, ArrowUp: k - 1, ArrowLeft: k - 1, Home: 0, End: vis.length - 1 }[e.key];
        if (n === undefined) return;
        e.preventDefault();
        selectTab(vis[(n + vis.length) % vis.length], true);
      });
    });
    // Цена «от …» на первом экране и в заголовке раздела — по самой дешёвой инструкции.
    var setFrom = function () {
      var prices = shop.products.filter(function (p) { var c = $('.shop-card[data-p="' + p.id + '"]'); return c && !c.hidden; }).map(function (p) { return p.price; });
      if (!prices.length || !data.from) return;
      var txt = data.from.replace('%', rubs(Math.min.apply(null, prices)));
      $$('[data-from]').forEach(function (el) { el.textContent = txt; });
    };


    // Актуальные цены и тексты — с сервера (их меняет администратор без пересборки сайта).
    fetch('/api/shop/products?lang=' + encodeURIComponent(data.lang), { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : Promise.reject(r.status); })
      .then(function (res) {
        shopPay = !!res.pay;
        res.products.forEach(function (p) {
          var mine = byId(p.id);
          var card = $('.shop-card[data-p="' + p.id + '"]');
          if (!mine || !card) return;
          Object.keys(p).forEach(function (key) { mine[key] = p[key]; });
          $('.shop-price', card).textContent = rubs(p.price);
          var tab = $('.shop-tab[data-p="' + p.id + '"]');
          if (tab) $('.shop-tab-price', tab).textContent = rubs(p.price);
          if (p.title) $('.shop-title', card).textContent = p.title;
          if (p.title && tab) $('.shop-tab-name', tab).textContent = p.title;
          if (p.short) $('.shop-short', card).textContent = p.short;
          if (p.includes) {
            var tick = $('.shop-inc svg', card).outerHTML;
            $('.shop-inc', card).innerHTML = p.includes.map(function (x) { return '<li>' + tick + '<span>' + esc(x) + '</span></li>'; }).join('');
          }
          var note = $('.shop-note', card);
          if (note && typeof p.note === 'string') { note.textContent = p.note; note.hidden = !p.note.trim(); }
        });
        // Товар, снятый с продажи на сервере, скрываем.
        $$('.shop-card').forEach(function (card) {
          card.hidden = !res.products.some(function (p) { return p.id === card.getAttribute('data-p'); });
          var tab = $('.shop-tab[data-p="' + card.getAttribute('data-p') + '"]');
          if (tab) tab.hidden = card.hidden;
        });
        var cur = $('.shop-tab[aria-selected="true"]');
        if (cur && cur.hidden) selectTab(tabs.filter(function (x) { return !x.hidden; })[0], false);
        setFrom();
      })
      .catch(function () { /* сервер недоступен — остаются цены из сборки; заказ всё равно проверит сервер */ });
  }
})();
