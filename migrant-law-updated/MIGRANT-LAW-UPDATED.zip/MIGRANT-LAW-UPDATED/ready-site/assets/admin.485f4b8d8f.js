// Админ-панель sverify.online (/admin/). Без библиотек. API — /api/admin/* (server/admin.mjs).
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var LANGS = [['ru', 'Русский'], ['tg', 'Тоҷикӣ'], ['kk', 'Қазақша'], ['ky', 'Кыргызча'], ['uz', 'Oʻzbekcha']];
  var app = $('#app');

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function h(tag, attrs, kids) {
    var el = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      var v = attrs[k];
      if (v == null || v === false) return;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
      else if (k === 'value') el.value = v;
      else if (k === 'checked') el.checked = !!v;
      else el.setAttribute(k, v === true ? '' : v);
    });
    (kids || []).forEach(function (c) { if (c != null && c !== false) el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return el;
  }
  function api(method, path, data, raw) {
    var opts = { method: method, headers: { 'X-Admin': '1' }, credentials: 'same-origin', cache: 'no-store' };
    if (raw) { opts.body = raw; opts.headers['Content-Type'] = 'application/octet-stream'; }
    else if (data !== undefined) { opts.body = JSON.stringify(data); opts.headers['Content-Type'] = 'application/json'; }
    return fetch('/api/admin' + path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (b) {
        if (r.status === 401 && path !== '/login') { showLogin(); throw new Error('Войдите в панель'); }
        if (r.ok && method !== 'GET' && !/^\/(preview|preflight|translate|login|files)/.test(path)) setTimeout(recheckDirty);
        if (!r.ok) { var e = new Error(b.error || ('Ошибка ' + r.status)); e.log = b.log; e.need2fa = b.need2fa; e.status = r.status; e.where = b.where; throw e; }
        return b;
      });
    });
  }
  /* несохранённые правки: панель предупреждает перед уходом из раздела */
  var formDirty = false;
  function recheckDirty() { formDirty = $$('.field .btn-gold:not(:disabled)').length > 0; }
  document.addEventListener('input', function (e) {
    if (e.target.closest('#main') && e.target.type !== 'search' && !e.target.closest('.no-dirty')) formDirty = true;
  });
  window.addEventListener('beforeunload', function (e) { if (formDirty) e.preventDefault(); });
  // Своё окно подтверждения. С opts.input — поле ввода, результат — введённая строка.
  function ask(text, opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      var field = opts.input ? h('input', { type: opts.input, autocomplete: 'new-password', 'aria-label': text }) : null;
      var dlg;
      var close = function (v) { dlg.close(); dlg.remove(); resolve(v); };
      dlg = h('dialog', { class: 'dlg' }, [h('p', { text: text }), field, h('div', { class: 'row' }, [
        h('button', { type: 'button', class: 'btn btn-gold sm', text: opts.ok || 'Да', onclick: function () { close(field ? field.value : true); } }),
        h('button', { type: 'button', class: 'btn btn-line sm', text: 'Отмена', onclick: function () { close(field ? '' : false); } })
      ])]);
      dlg.addEventListener('cancel', function (e) { e.preventDefault(); close(field ? '' : false); });
      document.body.appendChild(dlg);
      dlg.showModal();
      if (field) field.focus();
    });
  }
  var toastT;
  function toast(msg, bad) {
    var t = $('#toast');
    t.textContent = msg; t.className = 'toast show' + (bad ? ' bad' : '');
    clearTimeout(toastT); toastT = setTimeout(function () { t.className = 'toast'; }, bad ? 6000 : 2500);
  }
  var err = function (e) { toast(e.message, true); };
  function rub(n) { return Number(n).toLocaleString('ru-RU') + ' ₽'; }
  function kb(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' МБ' : Math.max(1, Math.round(n / 1024)) + ' КБ'; }
  function autosize(t) { t.style.height = 'auto'; t.style.height = (t.scrollHeight + 2) + 'px'; }
  function area(value, onInput, ph) {
    var t = h('textarea', { rows: 1, placeholder: ph || '' });
    t.value = value || '';
    t.addEventListener('input', function () { autosize(t); onInput(t.value); });
    setTimeout(function () { autosize(t); });
    return t;
  }
  function pickFile(accept, multiple, cb) {
    var i = h('input', { type: 'file', accept: accept || '', multiple: multiple ? true : null, class: 'hidden-file' });
    i.addEventListener('change', function () { cb(Array.prototype.slice.call(i.files)); i.remove(); });
    document.body.appendChild(i); i.click();
  }

  /* ---------- вход ---------- */
  function showLogin() {
    app.className = 'login-wrap';
    app.innerHTML = '';
    var user = h('input', { type: 'text', autocomplete: 'username', placeholder: 'Логин', autocapitalize: 'none', required: true });
    var pw = h('input', { type: 'password', autocomplete: 'current-password', placeholder: 'Пароль', required: true });
    var code = h('input', { type: 'text', inputmode: 'numeric', autocomplete: 'one-time-code', placeholder: 'Код из приложения', hidden: true, maxlength: 6 });
    var msg = h('p', { class: 'login-err', role: 'alert' });
    var form = h('form', { class: 'login', onsubmit: function (e) {
      e.preventDefault(); msg.textContent = '';
      api('POST', '/login', { login: user.value, password: pw.value, code: code.value }).then(function () { pw.value = ''; start(); }).catch(function (e2) {
        msg.textContent = e2.message;
        if (e2.need2fa) { code.hidden = false; code.value = ''; code.focus(); } else pw.select();
      });
    } }, [
      h('img', { src: '/media/emblem-112.webp', width: 64, height: 64, alt: '' }),
      h('h1', { text: 'Админ-панель' }), h('p', { class: 'muted', text: 'Migrant-law.ru' }), user, pw, code,
      h('button', { class: 'btn btn-gold', type: 'submit', text: 'Войти' }), msg
    ]);
    app.appendChild(form);
    user.focus();
  }

  /* ---------- каркас ---------- */
  var NAV = [
    ['Обзор', [['dash', 'Сводка', null]]],
    ['Сайт', [['builder', 'Конструктор', 'content'], ['texts', 'Тексты', 'content'], ['design', 'Дизайн и контакты', 'design'], ['files', 'Файлы и картинки', 'files'], ['prices', 'Прайс', 'prices'], ['shop', 'Инструкции', 'shop'], ['legal', 'Реквизиты', 'legal'], ['publish', 'Публикация', 'publish'], ['versions', 'Версии контента', 'publish']]],
    ['Клиенты', [['leads', 'Заявки', 'leads'], ['orders', 'Заказы', 'orders']]],
    ['Система', [['users', 'Пользователи', 'users'], ['audit', 'Журнал действий', 'audit'], ['integrations', 'Интеграции', 'system'], ['system', 'Сервер', 'system']]],
    ['Аккаунт', [['profile', 'Мой профиль', null]]]
  ];
  var ME = null;
  function can(p) { return p === null || ME.perms.indexOf('*') >= 0 || ME.perms.indexOf(p) >= 0; }
  var current = 'dash';
  function start() {
    return api('GET', '/me').then(function (m) { ME = m.user; shell(); });
  }
  function allowedTabs() {
    var out = [];
    NAV.forEach(function (g) { g[1].forEach(function (t) { if (can(t[2])) out.push(t[0]); }); });
    return out;
  }
  function shell() {
    app.className = 'shell';
    app.innerHTML = '';
    var nav = h('nav', { class: 'side', 'aria-label': 'Разделы панели' }, [
      h('div', { class: 'side-top' }, [
        h('a', { class: 'side-brand', href: '/', target: '_blank', rel: 'noopener' }, [h('img', { src: '/media/emblem-112.webp', width: 36, height: 36, alt: '' }), h('span', { text: 'Migrant-law.ru' })]),
        h('button', { type: 'button', class: 'side-toggle', text: 'Меню', 'aria-expanded': 'false', onclick: function (e) { var open = nav.classList.toggle('open'); e.target.setAttribute('aria-expanded', String(open)); } })
      ]),
      h('button', { type: 'button', class: 'side-search', text: 'Поиск…  Ctrl+K', onclick: openPalette })
    ]);
    NAV.forEach(function (g) {
      var tabs = g[1].filter(function (t) { return can(t[2]); });
      if (!tabs.length) return;
      nav.appendChild(h('p', { class: 'side-group', text: g[0] }));
      tabs.forEach(function (t) { nav.appendChild(h('button', { type: 'button', class: 'side-btn', 'data-tab': t[0], onclick: function () { confirmLeave().then(function (ok) { if (ok) { nav.classList.remove('open'); go(t[0]); } }); } }, [t[1]])); });
    });
    nav.appendChild(h('span', { class: 'side-dirty', id: 'dirty', hidden: true, text: 'Есть неопубликованные изменения' }));
    nav.appendChild(h('p', { class: 'side-who', text: ME.name + ' · ' + ME.roleLabel }));
    nav.appendChild(h('button', { type: 'button', class: 'side-out', text: 'Выйти', onclick: function () { api('POST', '/logout').then(showLogin); } }));
    app.appendChild(nav);
    app.appendChild(h('main', { class: 'main', id: 'main' }));
    var hash = location.hash.slice(1);
    var tabs = allowedTabs();
    go(tabs.indexOf(hash) >= 0 ? hash : 'dash');
    refreshDirty();
    refreshBadge();
    clearInterval(badgeTimer);
    badgeTimer = setInterval(refreshBadge, 60000);
  }
  var badgeTimer;
  function refreshBadge() {
    if (!can('leads')) return;
    api('GET', '/dashboard').then(function (d) {
      var btn = $('.side-btn[data-tab="leads"]');
      if (!btn) return;
      var n = d.leads.fresh + d.requests.length;
      var b = $('.side-badge', btn);
      if (!b) { b = h('span', { class: 'side-badge' }); btn.appendChild(b); }
      b.textContent = String(n); b.hidden = !n;
      document.title = (n ? '(' + n + ') ' : '') + 'Админ-панель — Migrant-law.ru';
    }).catch(function (e) { console.warn(e.message); });
  }
  function hotkeys(e) {
    if (!(e.ctrlKey || e.metaKey) || !ME) return;
    var k = e.key.toLowerCase();
    if (k === 'k' || k === 'л') { e.preventDefault(); openPalette(); }
    if (k === 's' || k === 'ы') {
      var btn = $('.b-form .btn-gold:last-of-type') || $('.mhead-act .btn-gold');
      if (btn && !btn.disabled) { e.preventDefault(); btn.click(); }
    }
  }
  document.addEventListener('keydown', hotkeys);
  // Быстрый переход: разделы, группы текстов, свои страницы.
  function openPalette() {
    if ($('.palette')) return;
    var items = [];
    NAV.forEach(function (g) { g[1].forEach(function (t) { if (can(t[2])) items.push({ label: t[1], hint: g[0], run: function () { go(t[0]); } }); }); });
    if (can('content')) GROUPS.forEach(function (g, i) { items.push({ label: g[0], hint: 'Тексты', run: function () { openGroup = i; go('texts'); } }); });
    B.pages.forEach(function (p) { items.push({ label: p.title.ru, hint: 'Страница', run: function () { B.page = p.id; go('builder'); } }); });
    var list = h('div', { class: 'pal-list', role: 'listbox' }), sel = 0, shown = [];
    var dlg;
    var close = function () { dlg.close(); dlg.remove(); };
    var choose = function (it) { close(); confirmLeave().then(function (ok) { if (ok) it.run(); }); };
    var input = h('input', { type: 'search', placeholder: 'Раздел, группа текстов, страница', 'aria-label': 'Поиск по панели', oninput: function () { sel = 0; draw(); }, onkeydown: function (e) {
      if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(sel + 1, shown.length - 1); draw(); }
      if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(sel - 1, 0); draw(); }
      if (e.key === 'Enter' && shown[sel]) { e.preventDefault(); choose(shown[sel]); }
    } });
    function draw() {
      var q = input.value.trim().toLowerCase();
      shown = items.filter(function (it) { return !q || (it.label + ' ' + it.hint).toLowerCase().indexOf(q) >= 0; }).slice(0, 12);
      list.innerHTML = '';
      shown.forEach(function (it, i) { list.appendChild(h('button', { type: 'button', role: 'option', class: 'pal-item' + (i === sel ? ' on' : ''), onclick: function () { choose(it); } }, [h('span', { text: it.label }), h('small', { class: 'muted', text: it.hint })])); });
    }
    dlg = h('dialog', { class: 'dlg palette' }, [input, list]);
    dlg.addEventListener('cancel', function () { dlg.remove(); });
    dlg.addEventListener('click', function (e) { if (e.target === dlg) close(); });
    document.body.appendChild(dlg);
    dlg.showModal(); draw(); input.focus();
  }
  function confirmLeave() {
    if (!formDirty) return Promise.resolve(true);
    return ask('Есть несохранённые правки. Уйти без сохранения?', { ok: 'Уйти' }).then(function (ok) { if (ok) formDirty = false; return ok; });
  }
  function refreshDirty() {
    api('GET', '/status').then(function (s) { var d = $('#dirty'); if (d) d.hidden = !s.dirty; }).catch(function (e) { console.warn(e.message); });
  }
  function changed() { refreshDirty(); }
  function go(tab) {
    current = tab;
    history.replaceState(null, '', '#' + tab);
    formDirty = false;
    $$('.side-btn').forEach(function (b) { var on = b.getAttribute('data-tab') === tab; b.classList.toggle('on', on); if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
    var main = $('#main');
    main.className = 'main' + (tab === 'builder' ? ' wide' : '');
    main.innerHTML = '<p class="muted">Загрузка…</p>';
    ({ dash: viewDash, builder: viewBuilder, design: viewDesign, publish: viewPublish, versions: viewVersions, texts: viewTexts, files: viewFiles, prices: viewPrices, shop: viewShop, legal: viewLegal, leads: viewLeads, orders: viewOrders, users: viewUsers, audit: viewAudit, integrations: viewIntegrations, system: viewSystem, profile: viewProfile }[tab])(main);
  }
  function head(main, title, sub, actions) {
    main.innerHTML = '';
    main.appendChild(h('header', { class: 'mhead' }, [h('div', {}, [h('h1', { text: title }), sub ? h('p', { class: 'muted', text: sub }) : null]), h('div', { class: 'mhead-act' }, actions || [])]));
  }

  /* ---------- сводка ---------- */
  function stat(label, value, sub) { return h('div', { class: 'tile' }, [h('span', { class: 'tile-l', text: label }), h('b', { class: 'tile-v', text: String(value) }), sub ? h('small', { class: 'muted', text: sub }) : null]); }
  var SVG = 'http://www.w3.org/2000/svg';
  function svgEl(tag, attrs) { var e = document.createElementNS(SVG, tag); Object.keys(attrs).forEach(function (k) { e.setAttribute(k, attrs[k]); }); return e; }
  // Заявки по дням: один ряд столбиков, значение — во всплывающей подсказке столбика.
  function dayChart(days) {
    var W = 600, H = 120, base = H - 4, max = Math.max.apply(null, days.map(function (d) { return d.n; }).concat([1]));
    var step = W / days.length, s = svgEl('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'chart', role: 'img', 'aria-label': 'Заявки за 30 дней' });
    s.appendChild(svgEl('line', { x1: 0, x2: W, y1: base, y2: base, class: 'chart-base' }));
    days.forEach(function (d, i) {
      var g = svgEl('g', { class: 'chart-col' });
      var t = svgEl('title', {}); t.textContent = d.d.split('-').reverse().join('.') + ': ' + d.n;
      g.appendChild(t);
      g.appendChild(svgEl('rect', { x: i * step, y: 0, width: step, height: H, fill: 'transparent' }));
      if (d.n) { var ht = Math.max(4, d.n / max * (base - 6)); g.appendChild(svgEl('rect', { x: i * step + 2, y: base - ht, width: step - 4, height: ht, rx: 3, class: 'chart-bar' })); }
      s.appendChild(g);
    });
    return h('div', {}, [s, h('div', { class: 'chart-x muted' }, [h('span', { text: days[0].d.slice(8) + '.' + days[0].d.slice(5, 7) }), h('span', { text: 'максимум в день: ' + max }), h('span', { text: 'сегодня' })])]);
  }
  function stageBars(stages) {
    var keys = Object.keys(stages).sort(function (a, b) { return stages[b] - stages[a]; });
    var max = stages[keys[0]];
    return h('div', { class: 'hbars' }, keys.map(function (k) {
      var bar = h('i', {}); bar.style.width = (stages[k] / max * 100) + '%';
      return h('div', { class: 'hbar' }, [h('span', { text: STAGES[k] || k }), h('div', { class: 'hbar-t' }, [bar]), h('b', { text: String(stages[k]) })]);
    }));
  }
  function viewDash(main) {
    api('GET', '/dashboard').then(function (d) {
      head(main, 'Сводка', 'Здравствуйте, ' + ME.name + '.');
      var tiles = h('section', { class: 'tiles' });
      if (d.leads) { tiles.appendChild(stat('Новые заявки', d.leads.fresh, 'ждут обработки')); tiles.appendChild(stat('Заявок за 7 дней', d.leads.week, 'всего активных: ' + d.leads.total)); }
      if (d.orders) { tiles.appendChild(stat('Оплаченные заказы', d.orders.paid, 'за 7 дней: ' + d.orders.week)); tiles.appendChild(stat('Выручка инструкций', rub(d.orders.revenue))); }
      if (d.site) tiles.appendChild(stat('Сайт', d.site.dirty ? 'Есть правки' : 'Актуален', d.site.publishedAt ? 'публикация: ' + dt(d.site.publishedAt) : 'ещё не публиковался'));
      if (tiles.children.length) main.appendChild(tiles);
      if (d.requests && d.requests.length) main.appendChild(h('section', { class: 'card alert' }, [h('h2', { text: 'Открытые обращения по персональным данным: ' + d.requests.length }), h('p', { class: 'muted', text: 'Ответить нужно в течение 10 рабочих дней. Самое раннее — от ' + dt(d.requests[0].at) + '.' }), h('div', {}, [h('button', { class: 'btn btn-line sm', type: 'button', text: 'Открыть заявки', onclick: function () { go('leads'); } })])]));
      if (d.leads) main.appendChild(h('section', { class: 'card' }, [h('h2', { text: 'Заявки за 30 дней' }), dayChart(d.leads.days)]));
      if (d.leads && Object.keys(d.leads.stages).length) main.appendChild(h('section', { class: 'card' }, [h('h2', { text: 'С чем обращаются' }), stageBars(d.leads.stages)]));
      if (can('content')) main.appendChild(h('section', { class: 'card' }, [h('h2', { text: 'Быстрые действия' }), h('div', { class: 'row' }, [
        h('button', { class: 'btn btn-gold sm', type: 'button', text: 'Открыть конструктор', onclick: function () { go('builder'); } }),
        can('publish') ? h('button', { class: 'btn btn-line sm', type: 'button', text: 'Опубликовать', onclick: function () { go('publish'); } }) : null,
        h('a', { class: 'btn btn-line sm', href: '/', target: '_blank', rel: 'noopener', text: 'Открыть сайт' })
      ])]));
    }).catch(err);
  }

  /* ---------- публикация ---------- */
  function viewPublish(main) {
    api('GET', '/status').then(function (s) {
      head(main, 'Публикация', 'Изменения в панели появляются на сайте после публикации. Перед каждой публикацией сохраняется копия сайта.');
      var logBox = h('pre', { class: 'log', hidden: true });
      var btn = h('button', { class: 'btn btn-gold big', type: 'button', text: 'Опубликовать изменения', onclick: function () {
        btn.disabled = true; btn.textContent = 'Собираем сайт…';
        api('POST', '/publish').then(function (r) {
          toast('Опубликовано'); logBox.hidden = false; logBox.textContent = r.log || ''; viewPublish(main); refreshDirty();
        }).catch(function (e) {
          toast(e.message, true); logBox.hidden = false; logBox.textContent = e.log || e.message; btn.disabled = false; btn.textContent = 'Опубликовать изменения';
        });
      } });
      var checkBox = h('div', { class: 'preflight' });
      var runCheck = function () {
        checkBox.innerHTML = '<p class="muted">Проверяем черновик…</p>';
        api('POST', '/preflight', {}).then(function (r) {
          checkBox.innerHTML = '';
          var line = function (kind, text) { checkBox.appendChild(h('p', { class: 'pf ' + kind, text: text })); };
          if (r.buildError) line('bad', 'Сайт не соберётся: ' + r.buildError); else line('good', 'Сайт собирается без ошибок');
          line('info', r.changes === null ? 'Изменения: первая публикация из панели' : (r.changes.length ? 'Изменено: ' + r.changes.join(', ') : 'Изменений с прошлой публикации нет'));
          if (r.missingFiles.length) line('bad', 'Нет файлов, на которые есть ссылки: ' + r.missingFiles.join(', '));
          if (r.untranslated.length) line('warn', 'Нет перевода заголовка (покажется русский): ' + r.untranslated.join(', '));
          if (r.legalMissing) line('warn', 'Не заполнены реквизиты: ' + r.legalMissing);
          btn.disabled = !!r.buildError;
        }).catch(function (e) { checkBox.innerHTML = ''; checkBox.appendChild(h('p', { class: 'pf bad', text: e.message })); });
      };
      main.appendChild(h('section', { class: 'card' }, [h('div', { class: 'row between' }, [h('h2', { text: 'Проверка перед публикацией' }), h('button', { class: 'btn-text', type: 'button', text: 'Проверить снова', onclick: runCheck })]), checkBox]));
      runCheck();
      main.appendChild(h('section', { class: 'card' }, [
        h('p', { class: 'stat' }, [s.dirty ? h('b', { class: 'warn', text: 'Есть неопубликованные изменения' }) : h('b', { class: 'ok', text: 'Сайт актуален' }),
          s.publishedAt ? ' · последняя публикация: ' + new Date(s.publishedAt).toLocaleString('ru-RU') : '']),
        h('div', { class: 'row' }, [btn, h('a', { class: 'btn btn-line', href: '/', target: '_blank', rel: 'noopener', text: 'Открыть сайт' })]),
        logBox
      ]));
      var rel = h('section', { class: 'card' }, [h('h2', { text: 'Резервные копии' }), h('p', { class: 'muted', text: 'Если после публикации что-то не так — верните сайт к копии. Правки в панели при этом сохраняются; их можно исправить и опубликовать снова.' })]);
      if (!s.releases.length) rel.appendChild(h('p', { class: 'muted', text: 'Копий пока нет — появятся после первой публикации.' }));
      s.releases.forEach(function (id) {
        var d = id.slice(6, 8) + '.' + id.slice(4, 6) + '.' + id.slice(0, 4) + ' ' + id.slice(9, 11) + ':' + id.slice(11, 13) + ' (UTC)';
        rel.appendChild(h('div', { class: 'line' }, [h('span', { text: 'Сайт до публикации ' + d }), h('button', { class: 'btn btn-line sm', type: 'button', text: 'Вернуть эту версию', onclick: async function () {
          if (!await ask('Вернуть сайт к версии ' + d + '?')) return;
          api('POST', '/rollback', { id: id }).then(function () { toast('Сайт возвращён к копии'); viewPublish(main); }).catch(err);
        } })]));
      });
      main.appendChild(rel);
      main.appendChild(h('section', { class: 'card' }, [h('h2', { text: 'Как это устроено' }), h('ul', { class: 'help' }, [
        h('li', { text: 'Тексты — все надписи сайта на 5 языках. Изменённые поля помечены, их можно вернуть к исходным.' }),
        h('li', { text: 'Конструктор — блоки разных типов на главной и на своих страницах, порядок перетаскиванием, предпросмотр.' }),
        h('li', { text: 'Дизайн и контакты — телефон, мессенджеры, цвета, объявление, пункты меню.' }),
        h('li', { text: 'Файлы — PDF, картинки, документы. Ссылка вида /files/имя работает после публикации.' }),
        h('li', { text: 'Инструкции и их PDF меняются сразу, без публикации (покупатель видит новые цены при загрузке страницы).' })
      ])]));
    }).catch(err);
  }

  /* ---------- тексты ---------- */
  var GROUPS = [
    ['Шапка и меню', ['k.nav', 'k.call', 'k.menu', 'brand1', 'brand2', 'langLabel', 'skip']],
    ['Первый экран', ['k.h1', 'k.lead', 'k.perks', 'k.ctaMain', 'k.ctaStage', 'k.acts']],
    ['Migrant AI', ['k.aiText', 'k.aiAsk', 'k.aiPh', 'k.aiRobot', 'k.aiChips', 'j.aiHello', 'j.aiSend', 'j.aiNote', 'j.aiToLawyer', 'aiQs', 'aiDefault', 'aiThink']],
    ['Найти свой этап', ['k.stageEyebrow', 'k.stageTitle', 'k.stageSub', 'j.iHave', 'j.sits', 'j.plans', 'j.plan', 'j.urgentTag', 'j.cost', 'j.bringLabel', 'j.discuss', 'j.callNow', 'j.wa', 'j.from', 'j.priceNote', 'j.priceAll', 'k.cty']],
    ['Контакты и форма заявки', ['k.ctEyebrow', 'k.ctTitle', 'j.ctText', 'j.hours', 'j.fSit', 'j.fName', 'j.fContact', 'j.fMsg', 'j.fMsgPh', 'j.fSubmit', 'j.doneTitle', 'j.doneText', 'j.doneNo', 'cbBefore', 'cbLink', 'cbAfter', 'policyNote', 'policyLink', 'errRequired', 'errConsent', 'errNetwork', 'sending']],
    ['Самостоятельно (инструкции)', ['k.shop']],
    ['Как мы работаем', ['k.howEyebrow', 'k.howTitle', 'j.how', 'j.youGet']],
    ['О нас', ['k.aboutEyebrow', 'k.aboutTitle', 'k.aboutText', 'j.factsLabel', 'j.facts']],
    ['Вопросы и ответы', ['k.faqTitle', 'j.faq']],
    ['Подвал, cookie, SEO', ['j.footer', 'ftCopy', 'docsTitle', 'docs', 'ckText', 'ckMore', 'ckOk', 'metaTitle', 'metaDesc']]
  ];
  var LABELS = {
    'k.nav': 'Пункты меню (Услуги, Консультация, Цены, О нас, Контакты)', 'k.call': 'Кнопка «Позвонить»', 'k.menu': 'Подпись кнопки меню', brand1: 'Название сайта', brand2: 'Подзаголовок названия', langLabel: 'Подпись выбора языка', skip: 'Ссылка «Перейти к содержанию» (для экранного диктора)',
    'k.perks': 'Три преимущества под заголовком', 'k.acts': 'Действия: текст и кнопка «Самостоятельно», текст «Найти свой этап»', 'k.h1': 'Главный заголовок: до золотого слова / золотое слово / после', 'k.lead': 'Текст под заголовком', 'k.ctaMain': 'Золотая кнопка', 'k.ctaStage': 'Название действия «Найти свой этап»',
    'k.aiText': 'Текст блока Migrant AI', 'k.aiAsk': 'Подпись поля вопроса', 'k.aiPh': 'Подсказка в поле вопроса', 'k.aiRobot': 'Описание робота (для экранного диктора)', 'k.aiChips': 'Примеры вопросов (кнопки)', 'j.aiHello': 'Приветствие помощника', 'j.aiNote': 'Предупреждение под чатом', 'j.aiToLawyer': 'Ссылка «к юристу» после ответа', aiQs: 'Готовые ответы без нейросети: вопрос, ответ, ключевые слова', aiDefault: 'Ответ, если вопрос не распознан',
    'k.stageEyebrow': 'Надзаголовок', 'k.stageTitle': 'Заголовок: до золотого / золотое / после', 'k.stageSub': 'Текст справа от заголовка', 'j.sits': 'Ситуации (кнопки слева) — порядок связан с планами', 'j.plans': 'Планы: название, текст, шаги, «Возьмите с собой»', 'k.cty': 'Выбор страны и тексты для ЕАЭС',
    'k.ctEyebrow': 'Надзаголовок', 'k.ctTitle': 'Заголовок: обычная часть / золотая часть', 'j.ctText': 'Текст', 'j.hours': 'Часы работы', 'j.fSubmit': 'Кнопка отправки', 'j.doneTitle': 'Заголовок после отправки', 'j.doneText': 'Текст после отправки',
    'k.shop': 'Все тексты раздела инструкций (карточки товаров — во вкладке «Инструкции»)',
    'k.howTitle': 'Заголовок: обычная / золотая часть', 'j.how': 'Шаги: когда, название, текст, результат',
    'k.aboutTitle': 'Заголовок: до золотого / золотое / после', 'k.aboutText': 'Текст', 'j.facts': 'Факты: заголовок и подпись',
    'k.faqTitle': 'Заголовок: обычная / золотая часть', 'j.faq': 'Вопросы и ответы',
    'j.footer': 'Строка в подвале', metaTitle: 'Заголовок страницы для поисковиков', metaDesc: 'Описание для поисковиков', docs: 'Названия документов в подвале', ckText: 'Текст уведомления о cookie'
  };
  var textLang = 'ru', textQuery = '';
  function applyTextSearch() {
    var q = textQuery.trim().toLowerCase();
    $$('.group').forEach(function (g) {
      var any = false;
      $$('.field', g).forEach(function (f) {
        var hit = !q || f.textContent.toLowerCase().indexOf(q) >= 0 || $$('textarea,input', f).some(function (x) { return x.value.toLowerCase().indexOf(q) >= 0; });
        f.hidden = !hit; any = any || hit;
      });
      g.hidden = !any;
      if (q && any) g.open = true;
    });
  }
  function collectStrings(v, out) {
    if (typeof v === 'string') { if (v.trim()) out.push(v); }
    else if (Array.isArray(v)) v.forEach(function (x) { collectStrings(x, out); });
    else if (v && typeof v === 'object') Object.keys(v).forEach(function (k) { collectStrings(v[k], out); });
    return out;
  }
  function fillStrings(v, queue) {
    if (typeof v === 'string') return v.trim() ? queue.shift() : v;
    if (Array.isArray(v)) return v.map(function (x) { return fillStrings(x, queue); });
    if (v && typeof v === 'object') { var o = {}; Object.keys(v).forEach(function (k) { o[k] = fillStrings(v[k], queue); }); return o; }
    return v;
  }
  var openGroup = 0;
  function viewTexts(main) {
    Promise.all([api('GET', '/texts?lang=' + textLang), textLang === 'ru' ? null : api('GET', '/texts?lang=ru')]).then(function (res) {
      var d = res[0], ru = res[1];
      head(main, 'Тексты', 'Все надписи сайта. Выберите язык и раздел, измените текст и нажмите «Сохранить». На сайте — после публикации.');
      var langs = h('div', { class: 'tabs' }, LANGS.map(function (l) {
        return h('button', { type: 'button', class: 'tab' + (l[0] === textLang ? ' on' : ''), text: l[1], onclick: function () { textLang = l[0]; viewTexts(main); } });
      }));
      main.appendChild(langs);
      var search = h('input', { type: 'search', placeholder: 'Поиск по всем надписям этого языка', 'aria-label': 'Поиск по надписям', value: textQuery, oninput: function (e) { textQuery = e.target.value; applyTextSearch(); } });
      main.appendChild(search);
      var used = {};
      GROUPS.forEach(function (g) { g[1].forEach(function (k) { used[k] = 1; }); });
      var rest = [];
      Object.keys(d.def).forEach(function (k) {
        if (k === 'j' || k === 'k') Object.keys(d.def[k]).forEach(function (k2) { if (!used[k + '.' + k2]) rest.push(k + '.' + k2); });
        else if (!used[k] && k !== 'code' && k !== 'path') rest.push(k);
      });
      var groups = GROUPS.concat([['Прочее', rest]]);
      groups.forEach(function (g, gi) {
        var det = h('details', { class: 'group' }, [h('summary', {}, [g[0], h('small', { text: String(g[1].filter(function (p) { return getAt(d.def, p) !== undefined; }).length) })])]);
        if (gi === openGroup) det.open = true;
        det.addEventListener('toggle', function () { if (det.open) openGroup = gi; });
        g[1].forEach(function (path) {
          var def = getAt(d.def, path);
          if (def === undefined) return;
          var ruVal = ru ? (ru.patch[path] !== undefined ? ru.patch[path] : getAt(ru.def, path)) : undefined;
          det.appendChild(fieldEditor(path, def, d.patch[path], ruVal));
        });
        main.appendChild(det);
      });
      applyTextSearch();
    }).catch(err);
  }
  function getAt(o, p) { return p.split('.').reduce(function (a, k) { return a == null ? undefined : a[k]; }, o); }
  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function blank(sample) {
    if (typeof sample === 'string') return '';
    if (typeof sample === 'number') return 0;
    if (Array.isArray(sample)) return sample.map(blank);
    if (sample && typeof sample === 'object') { var o = {}; Object.keys(sample).forEach(function (k) { o[k] = blank(sample[k]); }); return o; }
    return '';
  }
  // Редактор значения любой формы: строка, список, вложенные списки и объекты.
  function valueEditor(val, onChange, sample) {
    if (typeof val === 'string') return area(val, onChange);
    if (typeof val === 'number') return h('input', { type: 'number', value: String(val), oninput: function (e) { onChange(Number(e.target.value)); } });
    if (Array.isArray(val)) {
      var box = h('div', { class: 'arr' });
      var itemSample = sample && sample.length ? sample[0] : (val.length ? val[0] : '');
      var render = function () {
        box.innerHTML = '';
        val.forEach(function (item, i) {
          var row = h('div', { class: 'arr-item' + (typeof item === 'string' ? ' flat' : '') }, [
            h('span', { class: 'arr-n', text: String(i + 1) }),
            valueEditor(item, function (v) { val[i] = v; onChange(val); }, itemSample),
            h('span', { class: 'arr-ctl' }, [
              h('button', { type: 'button', title: 'Выше', text: '↑', disabled: i === 0 ? true : null, onclick: function () { var t = val[i - 1]; val[i - 1] = val[i]; val[i] = t; onChange(val); render(); } }),
              h('button', { type: 'button', title: 'Ниже', text: '↓', disabled: i === val.length - 1 ? true : null, onclick: function () { var t = val[i + 1]; val[i + 1] = val[i]; val[i] = t; onChange(val); render(); } }),
              h('button', { type: 'button', title: 'Удалить', class: 'del', text: '×', onclick: function () { val.splice(i, 1); onChange(val); render(); } })
            ])
          ]);
          box.appendChild(row);
        });
        box.appendChild(h('button', { type: 'button', class: 'add', text: '+ Добавить', onclick: function () { val.push(blank(itemSample)); onChange(val); render(); } }));
      };
      render();
      return box;
    }
    if (val && typeof val === 'object') {
      return h('div', { class: 'obj' }, Object.keys(val).map(function (k) {
        return h('label', { class: 'obj-f' }, [h('span', { text: k }), valueEditor(val[k], function (v) { val[k] = v; onChange(val); }, sample && sample[k])]);
      }));
    }
    return h('span', { text: String(val) });
  }
  function fieldEditor(path, def, patched, ruVal, translated) {
    var isChanged = patched !== undefined;
    var val = clone(translated !== undefined ? translated : (isChanged ? patched : def));
    var save = h('button', { type: 'button', class: 'btn btn-gold sm', text: 'Сохранить', disabled: translated !== undefined ? null : true });
    var reset = h('button', { type: 'button', class: 'btn-text', text: 'Вернуть исходный', hidden: !isChanged });
    var badge = h('span', { class: 'badge', text: 'изменено', hidden: !isChanged });
    var box = h('div', { class: 'field' + (isChanged ? ' changed' : '') }, [
      h('div', { class: 'field-h' }, [h('b', { text: LABELS[path] || path }), h('code', { text: path }), badge]),
      typeof ruVal === 'string' ? h('p', { class: 'ru-ref', text: 'RU: ' + ruVal }) : null,
      valueEditor(val, function (v) { val = v; save.disabled = false; }, def),
      h('div', { class: 'field-act' }, [save, reset, ruVal !== undefined ? h('button', { type: 'button', class: 'btn-text', text: 'Перевести с русского', onclick: function (e) {
        var strings = collectStrings(ruVal, []);
        if (!strings.length) return;
        e.target.disabled = true; e.target.textContent = 'Переводим…';
        api('POST', '/translate', { lang: textLang, strings: strings }).then(function (r) { box.replaceWith(fieldEditor(path, def, patched, ruVal, fillStrings(ruVal, r.strings.slice()))); formDirty = true; toast('Перевод готов. Проверьте и сохраните.'); })
          .catch(function (e2) { err(e2); e.target.disabled = false; e.target.textContent = 'Перевести с русского'; });
      } }) : null])
    ]);
    save.addEventListener('click', function () {
      api('PUT', '/texts', { lang: textLang, path: path, value: val }).then(function () {
        toast('Сохранено'); save.disabled = true; box.classList.add('changed'); badge.hidden = false; reset.hidden = false; changed();
      }).catch(err);
    });
    reset.addEventListener('click', async function () {
      if (!await ask('Вернуть исходный текст этого поля?')) return;
      api('PUT', '/texts', { lang: textLang, path: path, reset: true }).then(function () { toast('Возвращён исходный текст'); changed(); go('texts'); }).catch(err);
    });
    return box;
  }

  /* ---------- конструктор ---------- */
  var BLOCK_KINDS = [
    ['text', 'Текст и картинка', 'Заголовок, абзацы, картинка, кнопки'], ['cards', 'Карточки', 'Сетка преимуществ или услуг'], ['steps', 'Шаги', 'Нумерованный порядок действий'],
    ['faq', 'Вопросы и ответы', 'Раскрывающийся список'], ['gallery', 'Галерея', 'Сетка картинок'], ['video', 'Видео', 'Файл MP4 из загруженных'], ['cta', 'Призыв', 'Золотой блок с кнопкой'], ['table', 'Таблица', 'Две колонки: услуга и значение']
  ];
  var KIND_NAME = {}; BLOCK_KINDS.forEach(function (k) { KIND_NAME[k[0]] = k[1]; });
  var ITEM_FIELDS = { cards: ['Заголовок карточки', 'Текст', true], steps: ['Название шага', 'Что сделать', false], faq: ['Вопрос', 'Ответ', false], gallery: ['Подпись', null, true], table: ['Левая колонка', 'Правая колонка', false] };
  var SECTION_NAMES = { ai: 'Migrant AI (чат с роботом)', stage: 'Найти свой этап', contact: 'Контакты (форма заявки)', self: 'Оформите документы самостоятельно', how: 'Как мы работаем', about: 'О нас', faq: 'Вопросы и ответы' };
  var B = { blocks: [], layout: null, files: [], pages: [], page: 'main', device: 'desktop' };
  var previewBusy = false, previewAgain = false;
  function newId(prefix) { return prefix + '-' + Math.random().toString(36).slice(2, 10).padEnd(8, '0'); }
  function refreshPreview() {
    var frame = $('#pv-frame'), note = $('#pv-note');
    if (!frame) return;
    if (previewBusy) { previewAgain = true; return; }
    previewBusy = true; if (note) note.textContent = 'Собираем черновик…';
    api('POST', '/preview').then(function () {
      var f = $('#pv-frame'), n = $('#pv-note');
      B.previewFresh = true;
      if (f) loadFrame();
      if (n) n.textContent = 'Черновик · форма заявки здесь отключена';
    }).catch(function (e) { var n = $('#pv-note'); if (n) n.textContent = e.message; }).then(function () {
      previewBusy = false;
      if (previewAgain) { previewAgain = false; refreshPreview(); }
    });
  }
  var PREVIEW_LANGS = [['', 'RU'], ['tj/', 'TJ'], ['kz/', 'KZ'], ['kg/', 'KG'], ['uz/', 'UZ']];
  function loadFrame() {
    var f = $('#pv-frame');
    if (f) f.src = '/api/admin/preview/' + (B.plang || '') + currentPagePath() + '?v=' + Date.now();
  }
  function scrollPreview(id) {
    var f = $('#pv-frame'), el = f && f.contentDocument && f.contentDocument.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  function rememberBuilder() { B.saved = clone({ blocks: B.blocks, layout: B.layout, pages: B.pages }); }
  function undoBuilder(main) {
    var prev = B.history.pop();
    if (!prev) return;
    B.blocks = prev.blocks; B.layout = prev.layout; B.pages = prev.pages;
    if (B.page !== 'main' && !currentPage()) B.page = 'main';
    Promise.all([api('PUT', '/blocks', { blocks: B.blocks, layout: B.layout }), api('PUT', '/pages', B.pages)]).then(function () { rememberBuilder(); toast('Отменено'); changed(); B.previewFresh = false; renderBuilder(main); }).catch(err);
  }
  function currentPage() { return B.pages.filter(function (p) { return p.id === B.page; })[0] || null; }
  function currentPagePath() { var p = currentPage(); return p ? p.slug + '/' : ''; }
  function viewBuilder(main) {
    Promise.all([api('GET', '/blocks'), api('GET', '/pages'), can('files') ? api('GET', '/files') : Promise.resolve([])]).then(function (r) {
      B.blocks = r[0].blocks; B.layout = r[0].layout; B.pages = r[1]; B.files = r[2];
      B.history = []; B.previewFresh = false; rememberBuilder();
      if (B.page !== 'main' && !currentPage()) B.page = 'main';
      renderBuilder(main);
    }).catch(err);
  }
  function renderBuilder(main) {
    head(main, 'Конструктор', 'Собирайте страницы из блоков: перетаскивайте строки, справа — предпросмотр. На сайте изменения появятся после публикации.', [
      h('button', { class: 'btn btn-line', type: 'button', text: 'Отменить действие', disabled: B.history.length ? null : true, onclick: function () { undoBuilder(main); } }),
      can('publish') ? h('button', { class: 'btn btn-gold', type: 'button', text: 'К публикации', onclick: function () { go('publish'); } }) : null
    ]);
    var tabs = h('div', { class: 'tabs' }, [h('button', { type: 'button', class: 'tab' + (B.page === 'main' ? ' on' : ''), text: 'Главная', onclick: function () { B.page = 'main'; renderBuilder(main); } })]
      .concat(B.pages.map(function (p) { return h('button', { type: 'button', class: 'tab' + (B.page === p.id ? ' on' : ''), text: (p.hidden ? '◌ ' : '') + p.title.ru, onclick: function () { B.page = p.id; renderBuilder(main); } }); }))
      .concat([h('button', { type: 'button', class: 'add', text: '+ Страница', onclick: function () { editPage(main, null); } })]));
    main.appendChild(tabs);
    var pane = h('div', { class: 'b-pane', id: 'b-pane' });
    var frame = h('iframe', { id: 'pv-frame', title: 'Предпросмотр', class: 'pv-frame ' + B.device });
    frame.addEventListener('load', function () {
      if (frame.contentWindow) frame.contentWindow.addEventListener('keydown', hotkeys); // когда фокус внутри предпросмотра
      if (B.focus) { scrollPreview(B.focus); B.focus = null; }
    });
    var deviceBtn = function (id, label) { return h('button', { type: 'button', class: 'tab dev' + (B.device === id ? ' on' : ''), text: label, onclick: function (e) {
      B.device = id; frame.className = 'pv-frame ' + id;
      $$('.tab.dev').forEach(function (x) { x.classList.remove('on'); }); e.target.classList.add('on');
    } }); };
    var langSel = h('select', { class: 'pv-lang no-dirty', 'aria-label': 'Язык предпросмотра', onchange: function (e) { B.plang = e.target.value; loadFrame(); } }, PREVIEW_LANGS.map(function (l) { return h('option', { value: l[0], text: l[1], selected: (B.plang || '') === l[0] ? true : null }); }));
    main.appendChild(h('div', { class: 'builder' }, [pane, h('div', { class: 'b-view' }, [
      h('div', { class: 'row pv-bar' }, [deviceBtn('desktop', 'Компьютер'), deviceBtn('phone', 'Телефон'), langSel, h('button', { type: 'button', class: 'btn-text', text: 'Обновить', onclick: refreshPreview }), h('span', { class: 'muted', id: 'pv-note' })]),
      h('div', { class: 'pv-box' }, [frame])
    ])]));
    renderRows(main, pane);
    if (B.previewFresh) loadFrame(); else refreshPreview();
  }
  function saveStructure(main, msg) {
    var p = currentPage();
    if (B.saved) B.history.push(B.saved);
    if (B.history.length > 30) B.history.shift();
    var undoBtn = $$('.mhead-act .btn-line').filter(function (x) { return x.textContent === 'Отменить действие'; })[0];
    if (undoBtn) undoBtn.disabled = false;
    var done = function () { rememberBuilder(); toast(msg || 'Сохранено'); changed(); B.previewFresh = false; refreshPreview(); };
    if (p) return api('PUT', '/pages', B.pages).then(done).catch(function (e) { err(e); viewBuilder(main); });
    return api('PUT', '/blocks', { blocks: B.blocks, layout: B.layout }).then(done).catch(function (e) { err(e); viewBuilder(main); });
  }
  function renderRows(main, pane) {
    pane.innerHTML = '';
    var page = currentPage();
    var ids = page ? page.blocks.map(function (b) { return b.id; }) : B.layout.order;
    var blocks = page ? page.blocks : B.blocks;
    var byId = {}; blocks.forEach(function (b) { byId[b.id] = b; });
    var move = function (from, to) {
      if (to < 0 || to >= ids.length || from === to) return;
      ids.splice(to, 0, ids.splice(from, 1)[0]);
      if (page) page.blocks.sort(function (a, b) { return ids.indexOf(a.id) - ids.indexOf(b.id); });
      renderRows(main, pane); saveStructure(main, 'Порядок сохранён');
    };
    if (page) pane.appendChild(h('div', { class: 'row' }, [
      h('a', { class: 'btn btn-line sm', href: '/' + page.slug + '/', target: '_blank', rel: 'noopener', text: '/' + page.slug + '/' }),
      h('button', { type: 'button', class: 'btn btn-line sm', text: 'Настройки страницы', onclick: function () { editPage(main, page); } })
    ]));
    var list = h('div', { class: 'rows' });
    if (!page) list.appendChild(h('div', { class: 'b-row fixed' }, [h('span', { text: 'Первый экран (Фемида, заголовок, кнопки)' })]));
    var dragFrom = null;
    ids.forEach(function (id, i) {
      var b = byId[id];
      var off = !page && B.layout.hidden.indexOf(id) >= 0;
      var name = b ? ((b.title && b.title.ru) || b.id) : (SECTION_NAMES[id] || id);
      var row = h('div', { class: 'b-row' + (off ? ' off' : ''), draggable: 'true', 'data-id': id, ondragstart: function (e) { dragFrom = i; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', id); row.classList.add('drag'); }, ondragend: function () { row.classList.remove('drag'); }, ondragover: function (e) { e.preventDefault(); row.classList.add('over'); }, ondragleave: function () { row.classList.remove('over'); }, ondrop: function (e) { e.preventDefault(); row.classList.remove('over'); if (dragFrom !== null) move(dragFrom, i); } }, [
        h('span', { class: 'b-grip', 'aria-hidden': 'true', text: '⋮⋮' }),
        h('div', { class: 'b-name', title: 'Показать в предпросмотре', onclick: function () { scrollPreview(id); } }, [h('b', { text: name }), h('small', { class: 'muted', text: (b ? KIND_NAME[b.type || 'text'] : 'Раздел сайта') + (off ? ' · скрыт' : '') })]),
        h('span', { class: 'arr-ctl' }, [
          h('button', { type: 'button', title: 'Выше', 'aria-label': 'Выше', text: '↑', disabled: i === 0 ? true : null, onclick: function () { move(i, i - 1); } }),
          h('button', { type: 'button', title: 'Ниже', 'aria-label': 'Ниже', text: '↓', disabled: i === ids.length - 1 ? true : null, onclick: function () { move(i, i + 1); } }),
          b ? h('button', { type: 'button', class: 'eye', text: 'Изменить', onclick: function () { editBlock(main, pane, b); } }) : h('button', { type: 'button', class: 'eye', text: 'Тексты', onclick: function () { go('texts'); } }),
          !page ? h('button', { type: 'button', class: 'eye', text: off ? 'Показать' : 'Скрыть', onclick: function () {
            if (off) B.layout.hidden.splice(B.layout.hidden.indexOf(id), 1); else B.layout.hidden.push(id);
            renderRows(main, pane); saveStructure(main);
          } }) : null,
          b ? h('button', { type: 'button', title: 'Копия', 'aria-label': 'Копия блока', class: 'eye', text: '⧉', onclick: function () {
            var copy = clone(b); copy.id = newId('b');
            blocks.splice(blocks.indexOf(b) + 1, 0, copy);
            if (!page) B.layout.order.splice(B.layout.order.indexOf(id) + 1, 0, copy.id);
            renderRows(main, pane); saveStructure(main, 'Блок скопирован');
          } }) : null,
          b ? h('button', { type: 'button', title: 'Удалить', 'aria-label': 'Удалить блок', class: 'del', text: '×', onclick: async function () {
            if (!await ask('Удалить блок «' + name + '»?')) return;
            blocks.splice(blocks.indexOf(b), 1);
            if (!page) { B.layout.order = B.layout.order.filter(function (x) { return x !== id; }); B.layout.hidden = B.layout.hidden.filter(function (x) { return x !== id; }); }
            renderRows(main, pane); saveStructure(main, 'Блок удалён');
          } }) : null
        ])
      ]);
      list.appendChild(row);
    });
    pane.appendChild(list);
    pane.appendChild(h('h2', { text: 'Добавить блок' }));
    pane.appendChild(h('div', { class: 'kinds' }, BLOCK_KINDS.map(function (k) {
      return h('button', { type: 'button', class: 'kind', 'data-kind': k[0], onclick: function () { editBlock(main, pane, null, k[0]); } }, [h('b', { text: k[1] }), h('small', { class: 'muted', text: k[2] })]);
    })));
  }
  var PAGE_TEMPLATES = {
    service: { name: 'Услуга', make: function () { return [
      { type: 'text', title: 'Заголовок: что это за услуга', text: 'Кому подходит и какой результат получит клиент.', buttons: [{ label: { ru: 'Получить консультацию' }, href: '/#contact' }] },
      { type: 'steps', title: 'Как проходит работа', n: 3 }, { type: 'table', title: 'Стоимость', n: 3 }, { type: 'faq', title: 'Частые вопросы', n: 3 },
      { type: 'cta', title: 'Остались вопросы?', text: 'Оставьте заявку, юрист свяжется с вами.', buttons: [{ label: { ru: 'Оставить заявку' }, href: '/#contact' }] }
    ]; } },
    promo: { name: 'Акция', make: function () { return [
      { type: 'cta', title: 'Название акции', text: 'Условия и срок действия.', buttons: [{ label: { ru: 'Записаться' }, href: '/#contact' }] }, { type: 'cards', title: 'Что входит', n: 3 }
    ]; } },
    info: { name: 'Статья', make: function () { return [{ type: 'text', title: 'Заголовок статьи', text: 'Текст статьи.' }, { type: 'faq', title: 'Частые вопросы', n: 2 }]; } }
  };
  function templateBlocks(key) {
    return PAGE_TEMPLATES[key].make().map(function (t) {
      var items = [];
      for (var i = 0; i < (t.n || 0); i++) items.push({ title: { ru: 'Элемент ' + (i + 1) }, text: { ru: 'Заполните текст' }, image: '' });
      return { id: newId('b'), type: t.type, style: 'plain', title: { ru: t.title }, eyebrow: {}, text: t.text ? { ru: t.text } : {}, image: '', imageAlt: {}, video: '', buttons: t.buttons || [], files: [], items: items };
    });
  }
  // Черновой перевод: заполняет только пустые языки у объектов вида { ru: '…', uz: '…' }.
  var TARGET_LANGS = ['tg', 'kk', 'ky', 'uz'];
  function translateObjs(objs, done) {
    var filled = objs.filter(function (o) { return o && (o.ru || '').trim(); });
    if (!filled.length) { toast('Сначала заполните русский текст', true); return; }
    var next = function (i) {
      if (i >= TARGET_LANGS.length) { formDirty = true; toast('Перевод готов. Проверьте его перед публикацией.'); done(); return; }
      var lang = TARGET_LANGS[i], todo = filled.filter(function (o) { return !(o[lang] || '').trim(); });
      if (!todo.length) { next(i + 1); return; }
      toast('Перевод: ' + lang + ' (' + (i + 1) + ' из 4)…');
      api('POST', '/translate', { lang: lang, strings: todo.map(function (o) { return o.ru; }) }).then(function (r) {
        todo.forEach(function (o, j) { o[lang] = r.strings[j]; });
        next(i + 1);
      }).catch(function (e) { toast(lang + ': ' + e.message, true); done(); });
    };
    next(0);
  }
  // Панель форматирования над текстом блока: разметка, которую понимает сайт.
  function textTools(t) {
    var wrap = function (before, after, ph) {
      var a = t.selectionStart, z = t.selectionEnd, picked = t.value.slice(a, z) || ph;
      t.setRangeText(before + picked + after, a, z, 'select');
      t.dispatchEvent(new Event('input', { bubbles: true })); t.focus();
    };
    return h('div', { class: 'tools' }, [
      h('button', { type: 'button', text: 'Ж', title: 'Жирный', 'aria-label': 'Жирный', onclick: function () { wrap('**', '**', 'текст'); } }),
      h('button', { type: 'button', text: 'Список', onclick: function () { wrap('- ', '', 'пункт'); } }),
      h('button', { type: 'button', text: 'Ссылка', onclick: function () { wrap('[', '](https://)', 'текст'); } })
    ]);
  }
  function editPage(main, page) {
    var isNew = !page;
    var p = isNew ? { id: newId('p'), slug: '', title: {}, desc: {}, blocks: [], inMenu: false, hidden: true, noindex: false } : clone(page);
    p.desc = p.desc || {};
    var lang = 'ru', template = '';
    head(main, isNew ? 'Новая страница' : 'Страница: ' + p.title.ru, 'Адрес — латиницей. Русский заголовок обязателен; на других языках, если не заполнено, покажется русский.', [h('button', { class: 'btn btn-line', type: 'button', text: '← К конструктору', onclick: function () { confirmLeave().then(function (ok) { if (ok) renderBuilder(main); }); } })]);
    var form = h('section', { class: 'card' });
    main.appendChild(form);
    var render = function () {
      form.innerHTML = '';
      form.appendChild(h('div', { class: 'tabs' }, LANGS.map(function (l) { return h('button', { type: 'button', class: 'tab' + (l[0] === lang ? ' on' : ''), text: l[1], onclick: function () { lang = l[0]; render(); } }); })));
      form.appendChild(h('label', { class: 'f' }, [h('span', { text: 'Заголовок' + (lang === 'ru' ? ' *' : '') }), h('input', { type: 'text', name: 'page-title', value: p.title[lang] || '', oninput: function (e) { p.title[lang] = e.target.value; } })]));
      form.appendChild(h('label', { class: 'f' }, [h('span', { text: 'Описание для поисковиков' }), area(p.desc[lang], function (v) { p.desc[lang] = v; })]));
      form.appendChild(h('label', { class: 'f' }, [h('span', { text: 'Адрес страницы: sverify.online/…' }), h('input', { type: 'text', name: 'page-slug', value: p.slug, placeholder: 'naprimer-akcii', oninput: function (e) { p.slug = e.target.value.trim().toLowerCase(); } })]));
      if (isNew) form.appendChild(h('label', { class: 'f' }, [h('span', { text: 'Шаблон' }), h('select', { onchange: function (e) { template = e.target.value; } }, [h('option', { value: '', text: 'Пустая страница' })].concat(Object.keys(PAGE_TEMPLATES).map(function (k) { return h('option', { value: k, text: PAGE_TEMPLATES[k].name, selected: template === k ? true : null }); })))]));
      form.appendChild(h('div', {}, [h('button', { type: 'button', class: 'btn btn-line sm', text: 'Перевести заголовок и описание', onclick: function () { translateObjs([p.title, p.desc], render); } })]));
      var check = function (key, label) { return h('label', { class: 'check' }, [h('input', { type: 'checkbox', checked: !!p[key], onchange: function (e) { p[key] = e.target.checked; } }), label]); };
      form.appendChild(check('inMenu', 'Показать в меню сайта'));
      form.appendChild(check('hidden', 'Черновик (на сайт не попадёт)'));
      form.appendChild(check('noindex', 'Скрыть от поисковиков'));
      form.appendChild(h('div', { class: 'row' }, [
        h('button', { type: 'button', class: 'btn btn-gold', text: 'Сохранить страницу', onclick: function () {
          if (!(p.title.ru || '').trim()) { lang = 'ru'; render(); toast('Нужен заголовок на русском', true); return; }
          var list = B.pages.slice();
          var clean = function (o) { var r = {}; Object.keys(o).forEach(function (k) { if ((o[k] || '').trim()) r[k] = o[k]; }); return r; };
          p.title = clean(p.title); p.desc = clean(p.desc);
          if (isNew && template) p.blocks = templateBlocks(template);
          if (isNew) list.push(p); else list[list.map(function (x) { return x.id; }).indexOf(p.id)] = p;
          api('PUT', '/pages', list).then(function () { B.pages = list; B.page = p.id; rememberBuilder(); toast('Страница сохранена'); changed(); B.previewFresh = false; renderBuilder(main); }).catch(err);
        } }),
        !isNew ? h('button', { type: 'button', class: 'btn-text del', text: 'Удалить страницу', onclick: async function () {
          if (!await ask('Удалить страницу «' + p.title.ru + '» со всеми блоками?')) return;
          var list = B.pages.filter(function (x) { return x.id !== p.id; });
          api('PUT', '/pages', list).then(function () { B.pages = list; B.page = 'main'; rememberBuilder(); toast('Страница удалена'); changed(); B.previewFresh = false; renderBuilder(main); }).catch(err);
        } }) : null
      ]));
    };
    render();
  }
  function editBlock(main, pane, source, kind) {
    var isNew = !source;
    var b = isNew ? { id: newId('b'), type: kind, style: 'plain', eyebrow: {}, title: {}, text: {}, imageAlt: {}, image: '', video: '', buttons: [], files: [], items: [] } : clone(source);
    ['eyebrow', 'title', 'text', 'imageAlt'].forEach(function (k) { b[k] = b[k] || {}; });
    b.type = b.type || 'text'; b.buttons = b.buttons || []; b.files = b.files || []; b.items = b.items || []; b.video = b.video || '';
    if (isNew && ITEM_FIELDS[b.type]) b.items.push({ title: {}, text: {}, image: '' });
    var lang = 'ru';
    var images = function () { return B.files.filter(function (f) { return /\.(jpe?g|png|webp|gif)$/i.test(f.name); }); };
    var videos = function () { return B.files.filter(function (f) { return /\.mp4$/i.test(f.name); }); };
    var uploadInto = function (accept, set) {
      pickFile(accept, false, function (fs) { uploadFiles(fs, function (up) { if (up[0]) { B.files.unshift(up[0]); set(up[0].url); } render(); }); });
    };
    var fileSelect = function (list, value, empty, onPick) {
      return h('select', { onchange: function (e) { onPick(e.target.value); render(); } }, [h('option', { value: '', text: empty })].concat(list.map(function (f) { return h('option', { value: f.url, text: f.name, selected: value === f.url ? true : null }); })));
    };
    var form = h('div', { class: 'card b-form' });
    pane.innerHTML = '';
    pane.appendChild(form);
    var hasImage = b.type === 'text' || b.type === 'cta';
    function render() {
      form.innerHTML = '';
      form.appendChild(h('div', { class: 'row between' }, [h('h2', { text: (isNew ? 'Новый блок: ' : 'Блок: ') + KIND_NAME[b.type] }), h('button', { type: 'button', class: 'btn-text', text: '← К списку', onclick: function () { confirmLeave().then(function (ok) { if (ok) renderRows(main, pane); }); } })]));
      form.appendChild(h('div', { class: 'tabs' }, LANGS.map(function (l) {
        return h('button', { type: 'button', class: 'tab' + (l[0] === lang ? ' on' : ''), text: l[1], onclick: function () { lang = l[0]; render(); } });
      })));
      var ml = function (key, label, ph, big) {
        if (big) { var ta = area(b[key][lang], function (v) { b[key][lang] = v; }, ph); return h('div', { class: 'f' }, [h('span', { text: label }), textTools(ta), ta]); }
        return h('label', { class: 'f' }, [h('span', { text: label }), h('input', { type: 'text', name: 'block-' + key, value: b[key][lang] || '', placeholder: ph || '', oninput: function (e) { b[key][lang] = e.target.value; } })]);
      };
      form.appendChild(ml('eyebrow', 'Надзаголовок (маленькие золотые буквы)', 'Например: Акция'));
      form.appendChild(ml('title', 'Заголовок' + (lang === 'ru' ? ' *' : ''), 'Заголовок блока'));
      form.appendChild(ml('text', 'Текст', 'Пустая строка — новый абзац. Строки с «- » — список. **жирный**, [текст ссылки](https://…)', true));
      if (b.type !== 'cta') form.appendChild(h('label', { class: 'f' }, [h('span', { text: 'Вид' }), h('select', { onchange: function (e) { b.style = e.target.value; } }, [
        h('option', { value: 'plain', text: 'Обычный', selected: b.style !== 'card' ? true : null }), h('option', { value: 'card', text: 'В золотой рамке', selected: b.style === 'card' ? true : null })
      ])]));
      if (hasImage) {
        form.appendChild(h('div', { class: 'f' }, [h('span', { text: 'Картинка (справа от текста)' }), h('div', { class: 'row' }, [fileSelect(images(), b.image, '— без картинки —', function (v) { b.image = v; }), h('button', { type: 'button', class: 'btn btn-line sm', text: 'Загрузить', onclick: function () { uploadInto('image/*', function (u) { b.image = u; }); } })]), b.image ? h('img', { class: 'thumb', src: '/api/admin/files/raw/' + encodeURIComponent(b.image.replace('/files/', '')), alt: '' }) : null]));
        if (b.image) form.appendChild(ml('imageAlt', 'Описание картинки (для незрячих и поисковиков)', ''));
      }
      if (b.type === 'video') form.appendChild(h('div', { class: 'f' }, [h('span', { text: 'Видео (MP4, до 60 МБ)' }), h('div', { class: 'row' }, [fileSelect(videos(), b.video, '— выберите файл —', function (v) { b.video = v; }), h('button', { type: 'button', class: 'btn btn-line sm', text: 'Загрузить', onclick: function () { uploadInto('video/mp4', function (u) { b.video = u; }); } })])]));
      if (ITEM_FIELDS[b.type]) form.appendChild(itemsEditor());
      var btns = h('div', { class: 'f' }, [h('span', { text: 'Кнопки (до 4): первая золотая' })]);
      b.buttons.forEach(function (x, i) {
        x.label = x.label || {};
        btns.appendChild(h('div', { class: 'row sub' }, [
          h('input', { type: 'text', placeholder: 'Надпись (' + lang + ')', value: x.label[lang] || '', oninput: function (e) { x.label[lang] = e.target.value; } }),
          h('input', { type: 'text', placeholder: 'Ссылка: #contact, tel:+7…, https://…', value: x.href || '', oninput: function (e) { x.href = e.target.value.trim(); } }),
          h('button', { type: 'button', class: 'btn-text del', text: '×', 'aria-label': 'Убрать кнопку', onclick: function () { b.buttons.splice(i, 1); render(); } })
        ]));
      });
      if (b.buttons.length < 4) btns.appendChild(h('button', { type: 'button', class: 'add', text: '+ Кнопка', onclick: function () { b.buttons.push({ label: {}, href: '#contact' }); render(); } }));
      form.appendChild(btns);
      var fl = h('div', { class: 'f' }, [h('span', { text: 'Файлы для скачивания' })]);
      b.files.forEach(function (x, i) {
        x.label = x.label || {};
        fl.appendChild(h('div', { class: 'row sub' }, [
          h('input', { type: 'text', placeholder: 'Название (' + lang + ')', value: x.label[lang] || '', oninput: function (e) { x.label[lang] = e.target.value; } }),
          h('select', { onchange: function (e) { x.href = e.target.value; } }, B.files.map(function (f) { return h('option', { value: f.url, text: f.name, selected: x.href === f.url ? true : null }); })),
          h('button', { type: 'button', class: 'btn-text del', text: '×', 'aria-label': 'Убрать файл', onclick: function () { b.files.splice(i, 1); render(); } })
        ]));
      });
      fl.appendChild(h('div', { class: 'row' }, [
        B.files.length ? h('button', { type: 'button', class: 'add', text: '+ Из загруженных', onclick: function () { b.files.push({ label: {}, href: B.files[0].url }); render(); } }) : null,
        can('files') ? h('button', { type: 'button', class: 'add', text: '+ Загрузить', onclick: function () {
          pickFile('', true, function (fs) { uploadFiles(fs, function (up) { up.forEach(function (u) { B.files.unshift(u); b.files.push({ label: { ru: u.name.replace(/\.[^.]+$/, '') }, href: u.url }); }); render(); }); });
        } }) : null
      ]));
      form.appendChild(fl);
      form.appendChild(h('div', { class: 'row' }, [
        h('button', { type: 'button', class: 'btn btn-line', text: 'Перевести на все языки', onclick: function () {
          var objs = [b.eyebrow, b.title, b.text, b.imageAlt];
          b.buttons.concat(b.files).forEach(function (x) { objs.push(x.label); });
          b.items.forEach(function (x) { objs.push(x.title, x.text); });
          translateObjs(objs, render);
        } }),
        h('button', { type: 'button', class: 'btn btn-gold', text: 'Сохранить блок', onclick: saveBlock })
      ]));
    }
    function itemsEditor() {
      var conf = ITEM_FIELDS[b.type];
      var box = h('div', { class: 'f' }, [h('span', { text: 'Элементы блока' })]);
      b.items.forEach(function (x, i) {
        x.title = x.title || {}; x.text = x.text || {};
        box.appendChild(h('div', { class: 'item-ed' }, [
          h('div', { class: 'row between' }, [h('small', { class: 'muted', text: '№ ' + (i + 1) }), h('span', { class: 'arr-ctl' }, [
            h('button', { type: 'button', text: '↑', 'aria-label': 'Выше', disabled: i === 0 ? true : null, onclick: function () { b.items.splice(i - 1, 0, b.items.splice(i, 1)[0]); render(); } }),
            h('button', { type: 'button', text: '↓', 'aria-label': 'Ниже', disabled: i === b.items.length - 1 ? true : null, onclick: function () { b.items.splice(i + 1, 0, b.items.splice(i, 1)[0]); render(); } }),
            h('button', { type: 'button', text: '×', class: 'del', 'aria-label': 'Удалить элемент', onclick: function () { b.items.splice(i, 1); render(); } })
          ])]),
          h('input', { type: 'text', placeholder: conf[0] + ' (' + lang + ')', value: x.title[lang] || '', oninput: function (e) { x.title[lang] = e.target.value; } }),
          conf[1] ? area(x.text[lang], function (v) { x.text[lang] = v; }, conf[1] + ' (' + lang + ')') : null,
          conf[2] ? h('div', { class: 'row' }, [fileSelect(images(), x.image, '— картинка —', function (v) { x.image = v; }), h('button', { type: 'button', class: 'btn btn-line sm', text: 'Загрузить', onclick: function () { uploadInto('image/*', function (u) { x.image = u; }); } })]) : null
        ]));
      });
      if (b.items.length < 40) box.appendChild(h('button', { type: 'button', class: 'add', text: '+ Элемент', onclick: function () { b.items.push({ title: {}, text: {}, image: '' }); render(); } }));
      return box;
    }
    function saveBlock() {
      if (!(b.title.ru || '').trim()) { lang = 'ru'; render(); toast('Нужен заголовок на русском', true); return; }
      var clean = function (o) { var r = {}; Object.keys(o || {}).forEach(function (k) { if ((o[k] || '').trim()) r[k] = o[k]; }); return r; };
      var labeled = function (list) { return list.filter(function (x) { return x.href && (x.label.ru || '').trim(); }).map(function (x) { return { label: clean(x.label), href: x.href }; }); };
      var out = { id: b.id, type: b.type, style: b.style, title: clean(b.title), eyebrow: clean(b.eyebrow), text: clean(b.text), image: b.image || '', imageAlt: clean(b.imageAlt), video: b.video || '', buttons: labeled(b.buttons), files: labeled(b.files),
        items: b.items.map(function (x) { return { title: clean(x.title), text: clean(x.text), image: x.image || '' }; }) };
      var page = currentPage();
      var list = page ? page.blocks : B.blocks;
      var at = isNew ? -1 : list.map(function (x) { return x.id; }).indexOf(b.id);
      if (at >= 0) list[at] = out; else list.push(out);
      if (!page && B.layout.order.indexOf(b.id) < 0) { var pos = B.layout.order.indexOf('faq'); B.layout.order.splice(pos < 0 ? B.layout.order.length : pos, 0, b.id); }
      renderRows(main, pane);
      B.focus = b.id;
      formDirty = false;
      saveStructure(main, 'Блок сохранён');
    }
    render();
  }

  /* ---------- дизайн и контакты ---------- */
  var THEME_LABELS = [['gold', 'Основной акцент (золото)'], ['goldHi', 'Светлый акцент'], ['bg', 'Фон'], ['text', 'Текст'], ['muted', 'Второстепенный текст']];
  function viewDesign(main) {
    api('GET', '/settings').then(function (d) {
      var s = d.settings;
      var save = function () { api('PUT', '/settings', s).then(function () { toast('Сохранено'); changed(); }).catch(err); };
      head(main, 'Дизайн и контакты', 'Контакты, цвета, меню, объявление. На сайте — после публикации.', [h('button', { class: 'btn btn-gold', type: 'button', text: 'Сохранить', onclick: save })]);
      var input = function (key, label) { return h('label', { class: 'f' }, [h('span', { text: label }), h('input', { type: 'text', name: key, value: s[key], oninput: function (e) { s[key] = e.target.value.trim(); } })]); };
      main.appendChild(h('section', { class: 'card grid2' }, [h('h2', { class: 'span2', text: 'Контакты на всём сайте' }), input('phone', 'Телефон'), input('telegram', 'Telegram'), input('whatsapp', 'WhatsApp'), input('max', 'MAX (ссылка https://max.ru/…, можно оставить пустым)')]));
      var theme = h('section', { class: 'card' }, [h('h2', { text: 'Цвета' })]);
      var grid = h('div', { class: 'grid2' });
      THEME_LABELS.forEach(function (t) {
        var k = t[0];
        grid.appendChild(h('label', { class: 'f colorf' }, [h('span', { text: t[1] }), h('input', { type: 'color', value: s.theme[k] || d.defaultTheme[k], oninput: function (e) { s.theme[k] = e.target.value; } })]));
      });
      theme.appendChild(grid);
      theme.appendChild(h('div', {}, [h('button', { class: 'btn-text', type: 'button', text: 'Вернуть фирменные цвета', onclick: function () { s.theme = {}; api('PUT', '/settings', s).then(function () { toast('Цвета сброшены'); changed(); viewDesign(main); }).catch(err); } })]));
      main.appendChild(theme);
      var langA = 'ru';
      var ann = h('section', { class: 'card' });
      var renderAnn = function () {
        ann.innerHTML = '';
        ann.appendChild(h('h2', { text: 'Объявление над шапкой' }));
        ann.appendChild(h('label', { class: 'check' }, [h('input', { type: 'checkbox', checked: s.announce.enabled, onchange: function (e) { s.announce.enabled = e.target.checked; } }), 'Показывать на сайте']));
        ann.appendChild(h('div', { class: 'tabs' }, LANGS.map(function (l) { return h('button', { type: 'button', class: 'tab' + (l[0] === langA ? ' on' : ''), text: l[1], onclick: function () { langA = l[0]; renderAnn(); renderMenu(); } }); })));
        ann.appendChild(area(s.announce.text[langA], function (v) { s.announce.text[langA] = v; }, 'Текст объявления'));
        ann.appendChild(h('div', {}, [h('button', { type: 'button', class: 'btn btn-line sm', text: 'Перевести на все языки', onclick: function () { translateObjs([s.announce.text], renderAnn); } })]));
        ann.appendChild(h('label', { class: 'f' }, [h('span', { text: 'Ссылка (необязательно)' }), h('input', { type: 'text', value: s.announce.href, oninput: function (e) { s.announce.href = e.target.value.trim(); } })]));
      };
      renderAnn();
      main.appendChild(ann);
      var menu = h('section', { class: 'card' });
      var renderMenu = function () {
        menu.innerHTML = '';
        menu.appendChild(h('h2', { text: 'Дополнительные пункты меню' }));
        menu.appendChild(h('p', { class: 'muted', text: 'Свои страницы добавляются в меню галочкой в их настройках. Здесь — любые другие ссылки. Язык названия — как выбран в блоке объявления выше; русское обязательно.' }));
        s.menu.forEach(function (m, i) {
          menu.appendChild(h('div', { class: 'row sub' }, [
            h('input', { type: 'text', placeholder: 'Название (' + langA + ')', value: m.label[langA] || '', oninput: function (e) { m.label[langA] = e.target.value; } }),
            h('input', { type: 'text', placeholder: 'https://… или /страница/', value: m.href, oninput: function (e) { m.href = e.target.value.trim(); } }),
            h('button', { type: 'button', class: 'btn-text del', text: '×', 'aria-label': 'Убрать пункт', onclick: function () { s.menu.splice(i, 1); renderMenu(); } })
          ]));
        });
        if (s.menu.length < 8) menu.appendChild(h('button', { type: 'button', class: 'add', text: '+ Пункт меню', onclick: function () { s.menu.push({ label: {}, href: '/' }); renderMenu(); } }));
      };
      renderMenu();
      main.appendChild(menu);
      main.appendChild(h('section', { class: 'card' }, [h('h2', { text: 'Для опытных' }),
        h('label', { class: 'check' }, [h('input', { type: 'checkbox', checked: s.noindex, onchange: function (e) { s.noindex = e.target.checked; } }), 'Закрыть весь сайт от поисковиков (robots.txt)']),
        h('label', { class: 'f' }, [h('span', { text: 'Своё CSS — добавляется в конец стилей сайта' }), area(s.customCss, function (v) { s.customCss = v; }, '.hero { … }')])]));
    }).catch(err);
  }

  /* ---------- файлы ---------- */
  function uploadFiles(files, done) {
    var out = [];
    var next = function (i) {
      if (i >= files.length) { if (out.length) changed(); done(out); return; }
      var f = files[i];
      toast('Загрузка: ' + f.name + '…');
      api('PUT', '/files/' + encodeURIComponent(f.name), undefined, f).then(function (r) { out.push({ name: r.name, url: r.url, size: f.size, mtime: Date.now() }); next(i + 1); })
        .catch(function (e) { toast(f.name + ': ' + e.message, true); next(i + 1); });
    };
    next(0);
  }
  function viewFiles(main) {
    api('GET', '/files').then(function (list) {
      head(main, 'Файлы и картинки', 'PDF, картинки, документы (до 60 МБ). На сайте доступны по ссылке /files/имя после публикации. Файл с тем же именем заменяет старый.', [
        h('button', { class: 'btn btn-gold', type: 'button', text: '+ Загрузить', onclick: function () { pickFile('', true, function (fs) { uploadFiles(fs, function () { viewFiles(main); }); }); } })
      ]);
      var drop = h('section', { class: 'card drop', text: 'Перетащите файлы сюда' });
      drop.addEventListener('dragover', function (e) { e.preventDefault(); drop.classList.add('over'); });
      drop.addEventListener('dragleave', function () { drop.classList.remove('over'); });
      drop.addEventListener('drop', function (e) { e.preventDefault(); drop.classList.remove('over'); uploadFiles(Array.prototype.slice.call(e.dataTransfer.files), function () { viewFiles(main); }); });
      main.appendChild(drop);
      var box = h('section', { class: 'card' });
      if (!list.length) box.appendChild(h('p', { class: 'muted', text: 'Файлов пока нет.' }));
      list.forEach(function (f) {
        var img = /\.(jpe?g|png|webp|gif)$/i.test(f.name);
        box.appendChild(h('div', { class: 'line' }, [
          h('div', { class: 'row' }, [img ? h('img', { class: 'thumb sm', src: '/api/admin/files/raw/' + encodeURIComponent(f.name), alt: '' }) : h('span', { class: 'ext', text: f.name.split('.').pop() }),
            h('div', {}, [h('b', { text: f.name }), h('p', { class: 'muted', text: kb(f.size) + ' · ' + f.url + (f.used.length ? ' · используется: ' + f.used.join(', ') : ' · не используется') })])]),
          h('div', { class: 'row' }, [
            h('button', { type: 'button', class: 'btn btn-line sm', text: 'Копировать ссылку', onclick: function () { navigator.clipboard.writeText(f.url).then(function () { toast('Ссылка скопирована: ' + f.url); }); } }),
            h('button', { type: 'button', class: 'btn-text del', text: 'Удалить', onclick: async function () {
              var warn = f.used.length ? 'Файл используется: ' + f.used.join(', ') + '. Ссылки перестанут работать. Всё равно удалить?' : 'Удалить ' + f.name + '?';
              if (!await ask(warn)) return;
              api('DELETE', '/files/' + encodeURIComponent(f.name) + (f.used.length ? '?force=1' : '')).then(function () { toast('Удалён'); changed(); viewFiles(main); }).catch(err);
            } })
          ])
        ]));
      });
      main.appendChild(box);
    }).catch(err);
  }

  /* ---------- прайс ---------- */
  function viewPrices(main) {
    api('GET', '/prices').then(function (doc) { renderPrices(main, doc); }).catch(err);
  }
  function renderPrices(main, doc) {
    var save = function () { api('PUT', '/prices', doc).then(function () { toast('Прайс сохранён'); changed(); }).catch(err); };
    head(main, 'Прайс', 'Страница /prices/ и цены «от» на главной. Услуги, на которые ссылается главная (РВП, ВНЖ, патент и т. д.), лучше не переименовывать — проверка перед публикацией подскажет, что исправить.', [
      h('button', { class: 'btn btn-gold', type: 'button', text: 'Сохранить прайс', onclick: save })
    ]);
    var pct = h('input', { type: 'number', class: 'num no-dirty', placeholder: '+10 или −5', 'aria-label': 'Изменение цен в процентах' });
    main.appendChild(h('div', { class: 'row filters' }, [
      h('input', { type: 'search', placeholder: 'Поиск услуги', 'aria-label': 'Поиск услуги', oninput: function (e) {
        var q = e.target.value.trim().toLowerCase();
        $$('.price-row').forEach(function (r) { r.hidden = !!q && r.getAttribute('data-name').indexOf(q) < 0; });
        $$('.group').forEach(function (g) { var any = $$('.price-row', g).some(function (r) { return !r.hidden; }); g.hidden = !any; if (q && any) g.open = true; });
      } }),
      pct, h('span', { class: 'muted', text: '%' }),
      h('button', { type: 'button', class: 'btn btn-line sm', text: 'Изменить все цены', onclick: async function () {
        var p = Number(pct.value);
        if (!p || p <= -100) { toast('Укажите процент', true); return; }
        if (!await ask('Изменить все цены на ' + p + '% с округлением до 100 ₽? Изменения применятся после «Сохранить прайс».')) return;
        doc.blocks.forEach(function (b) { b.items.forEach(function (it) { it[2] = Math.round(it[2] * (1 + p / 100) / 100) * 100; }); });
        renderPrices(main, doc); formDirty = true;
      } })
    ]));
    doc.blocks.forEach(function (b, bi) {
      var sec = h('details', { class: 'group' }, [h('summary', {}, [b.title, h('small', { text: String(b.items.length) })])]);
      sec.appendChild(h('label', { class: 'f' }, [h('span', { text: 'Название раздела' }), h('input', { type: 'text', value: b.title, oninput: function (e) { b.title = e.target.value; } })]));
      var items = h('div', { class: 'price-items' });
      var render = function () {
        items.innerHTML = '';
        b.items.forEach(function (it, i) {
          items.appendChild(h('div', { class: 'row sub price-row', 'data-name': String(it[1]).toLowerCase() }, [
            h('input', { type: 'text', class: 'grow', value: it[1], 'aria-label': 'Услуга', oninput: function (e) { it[1] = e.target.value; } }),
            h('input', { type: 'number', class: 'num', min: 0, step: 500, value: String(it[2]), 'aria-label': 'Цена', oninput: function (e) { it[2] = parseInt(e.target.value, 10) || 0; } }),
            h('span', { class: 'muted', text: '₽' }),
            h('button', { type: 'button', class: 'btn-text del', text: '×', 'aria-label': 'Удалить услугу', onclick: function () { b.items.splice(i, 1); formDirty = true; render(); } })
          ]));
        });
        items.appendChild(h('button', { type: 'button', class: 'add', text: '+ Услуга', onclick: function () { b.items.push([0, '', 0]); formDirty = true; render(); } }));
      };
      render();
      sec.appendChild(items);
      sec.appendChild(h('button', { type: 'button', class: 'btn-text del', text: 'Удалить раздел', onclick: async function () { if (await ask('Удалить раздел «' + b.title + '»?')) { doc.blocks.splice(bi, 1); formDirty = true; renderPrices(main, doc); } } }));
      main.appendChild(sec);
    });
    main.appendChild(h('button', { type: 'button', class: 'add', text: '+ Раздел прайса', onclick: function () { doc.blocks.push({ title: 'Новый раздел', items: [[0, '', 0]] }); formDirty = true; renderPrices(main, doc); } }));
  }

  /* ---------- инструкции ---------- */
  function viewShop(main) {
    api('GET', '/shop').then(function (d) {
      var doc = d.doc;
      head(main, 'Инструкции', 'Платные PDF-инструкции. Цены, тексты и файлы меняются сразу (публикация не нужна). Без файлов товар купить нельзя.', [
        h('button', { class: 'btn btn-gold', type: 'button', text: 'Сохранить инструкции', onclick: function () {
          api('PUT', '/shop/products', doc).then(function () { toast('Сохранено — уже на сайте'); }).catch(err);
        } })
      ]);
      doc.products.forEach(function (p) {
        var lang = 'ru';
        var card = h('details', { class: 'group' });
        var body = h('div');
        var render = function () {
          body.innerHTML = '';
          p.t[lang] = p.t[lang] || {};
          var t = p.t[lang];
          body.appendChild(h('div', { class: 'row' }, [
            h('label', { class: 'f' }, [h('span', { text: 'Цена, ₽' }), h('input', { type: 'number', min: 1, step: 500, value: String(p.price), oninput: function (e) { p.price = parseInt(e.target.value, 10) || 0; } })]),
            h('label', { class: 'check' }, [h('input', { type: 'checkbox', checked: p.active !== false, onchange: function (e) { p.active = e.target.checked; } }), 'В продаже'])
          ]));
          body.appendChild(h('div', { class: 'tabs' }, LANGS.map(function (l) { return h('button', { type: 'button', class: 'tab' + (l[0] === lang ? ' on' : ''), text: l[1], onclick: function () { lang = l[0]; render(); } }); })));
          body.appendChild(h('label', { class: 'f' }, [h('span', { text: 'Название' }), h('input', { type: 'text', value: t.title || '', oninput: function (e) { t.title = e.target.value; } })]));
          body.appendChild(h('label', { class: 'f' }, [h('span', { text: 'Короткое описание' }), area(t.short, function (v) { t.short = v; })]));
          t.includes = t.includes || [];
          body.appendChild(h('div', { class: 'f' }, [h('span', { text: '«Что внутри»' }), valueEditor(t.includes, function () {}, [''])]));
          body.appendChild(h('label', { class: 'f' }, [h('span', { text: 'Примечание под «Что внутри»' }), area(t.note, function (v) { t.note = v; })]));
          var files = d.files[p.id] || [];
          var fb = h('div', { class: 'f' }, [h('span', { text: 'Файлы (выдаются покупателю после оплаты)' })]);
          files.forEach(function (f) {
            fb.appendChild(h('div', { class: 'line' }, [h('span', { text: f.name + ' · ' + kb(f.size) }), h('button', { type: 'button', class: 'btn-text del', text: 'Удалить', onclick: async function () {
              if (!await ask('Удалить ' + f.name + '?')) return;
              api('DELETE', '/shop/files/' + p.id + '/' + encodeURIComponent(f.name)).then(function () { toast('Удалён'); viewShop(main); }).catch(err);
            } })]));
          });
          fb.appendChild(h('button', { type: 'button', class: 'add', text: '+ Загрузить PDF / образцы', onclick: function () {
            pickFile('.pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.webp,.zip,.txt,.rtf,.odt', true, function (fs) {
              var i = 0;
              var next = function () {
                if (i >= fs.length) { viewShop(main); return; }
                var f = fs[i++]; toast('Загрузка: ' + f.name + '…');
                api('PUT', '/shop/files/' + p.id + '/' + encodeURIComponent(f.name), undefined, f).then(next).catch(function (e) { toast(f.name + ': ' + e.message, true); next(); });
              };
              next();
            });
          } }));
          body.appendChild(fb);
        };
        card.appendChild(h('summary', {}, [(p.t.ru && p.t.ru.title) || p.id, h('small', { text: rub(p.price) + ' · файлов: ' + (d.files[p.id] || []).length })]));
        card.appendChild(body);
        render();
        main.appendChild(card);
      });
    }).catch(err);
  }

  /* ---------- реквизиты ---------- */
  var LEGAL_LABELS = [
    ['operatorFullName', 'ФИО или полное наименование (ИП Иванов Иван Иванович / ООО «…»)'], ['operatorShortName', 'Краткое наименование'], ['operatorKind', 'Статус: ИП, ООО, адвокат, самозанятый'],
    ['inn', 'ИНН'], ['ogrnLabel', 'Название номера: ОГРН или ОГРНИП'], ['ogrn', 'ОГРН / ОГРНИП'], ['registrationInfo', 'Дата регистрации и регистрирующий орган'],
    ['address', 'Адрес регистрации / местонахождения'], ['postAddress', 'Почтовый адрес (если отличается)'], ['email', 'E-mail для обращений'], ['phone', 'Телефон'],
    ['responsiblePerson', 'Ответственный за обработку персональных данных'], ['rknRegistryNumber', 'Номер в реестре операторов ПДн Роскомнадзора'],
    ['hostingProvider', 'Хостинг-провайдер (наименование, ИНН)'], ['hostingAddress', 'Адрес хостинг-провайдера'], ['dataLocation', 'Где хранятся данные (город, Россия)'],
    ['retentionDays', 'Срок хранения заявок, дней'], ['docsDate', 'Дата редакции документов'], ['consentVersion', 'Версия текста согласия'], ['privacyVersion', 'Версия политики']
  ];
  function viewLegal(main) {
    api('GET', '/legal').then(function (d) {
      head(main, 'Реквизиты', 'Сведения о владельце для документов (политика, согласие, оферта, реквизиты). Если меняется текст согласия — увеличьте «Версию текста согласия» (например 1.2 → 1.3) и дату.', [
        h('button', { class: 'btn btn-gold', type: 'button', text: 'Сохранить', onclick: function () { api('PUT', '/legal', d).then(function () { toast('Сохранено'); changed(); }).catch(err); } })
      ]);
      var box = h('section', { class: 'card grid2' });
      LEGAL_LABELS.forEach(function (l) {
        var k = l[0];
        box.appendChild(h('label', { class: 'f' }, [h('span', { text: l[1] }), h('input', { type: k === 'retentionDays' ? 'number' : 'text', value: String(d[k] == null ? '' : d[k]), oninput: function (e) { d[k] = k === 'retentionDays' ? parseInt(e.target.value, 10) || 0 : e.target.value; } })]));
      });
      main.appendChild(box);
    }).catch(err);
  }

  /* ---------- заявки и заказы ---------- */
  var STAGES = { uchet: 'Регистрация и учёт', patent: 'Патент', eaeu: 'Работа по договору (ЕАЭС)', rvp: 'РВП', vnzh: 'ВНЖ', grazh: 'Гражданство', problem: 'Отказ, запрет, РКЛ', urgent: 'СРОЧНО', help: 'Не знает, с чего начать' };
  var COUNTRIES = { tj: 'Таджикистан', uz: 'Узбекистан', kg: 'Кыргызстан', kz: 'Казахстан', md: 'Молдова', other: 'другая' };
  var CRM = { new: 'Новая', work: 'В работе', done: 'Завершена', rejected: 'Отказ' };
  function dt(s) { return s ? new Date(s).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }) : ''; }
  function table(cols, rows) {
    return h('div', { class: 'table-wrap' }, [h('table', {}, [
      h('thead', {}, [h('tr', {}, cols.map(function (c) { return h('th', { text: c }); }))]),
      h('tbody', {}, rows.map(function (r) { return h('tr', { class: r.cls || '' }, r.cells.map(function (c) { return h('td', {}, [c instanceof Node ? c : (c == null ? '' : String(c))]); })); }))
    ])]);
  }
  function csvCell(v) { var s = String(v == null ? '' : v); s = /^[=+\-@]/.test(s) ? "'" + s : s; return '"' + s.replace(/"/g, '""') + '"'; } // апостроф: Excel не выполнит значение как формулу
  function downloadCsv(name, cols, rows) {
    var text = '﻿' + [cols].concat(rows).map(function (r) { return r.map(csvCell).join(';'); }).join('\r\n');
    var a = h('a', { href: URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' })), download: name });
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 5000);
  }
  var leadFilter = { q: '', st: '' };
  function leadStatus(l) { return (l.crm && l.crm.status) || 'new'; }
  function contactLink(c) {
    var d = String(c || '').replace(/\D/g, '');
    return d.length >= 10 && /^[+\d\s()-]+$/.test(c) ? h('a', { href: 'tel:+' + d, text: c }) : h('span', { text: c || '' });
  }
  function messengerLinks(c) {
    var d = String(c || '').replace(/\D/g, '');
    if (d.length < 10 || !/^[+\d\s()-]+$/.test(c)) return null;
    return h('div', { class: 'row' }, [h('a', { class: 'btn btn-line sm', href: 'https://wa.me/' + d, target: '_blank', rel: 'noopener', text: 'WhatsApp' }), h('a', { class: 'btn btn-line sm', href: 'https://t.me/+' + d, target: '_blank', rel: 'noopener', text: 'Telegram' })]);
  }
  // Срок ответа на обращение — 10 рабочих дней (суббота и воскресенье не считаются; праздники — проверьте сами).
  function workdaysLeft(at) {
    var d = new Date(at), left = 10;
    while (left > 0) { d.setDate(d.getDate() + 1); if (d.getDay() !== 0 && d.getDay() !== 6) left--; }
    return Math.ceil((d - Date.now()) / 864e5);
  }
  function leadCard(l, main) {
    if (l.destroyedAt) return h('div', { class: 'lead off' }, [h('span', { text: '№' + l.id + ' · ' + dt(l.at) + ' · данные уничтожены ' + dt(l.destroyedAt) + (l.destroyReason ? ' (' + l.destroyReason + ')' : '') })]);
    var st = leadStatus(l), note = (l.crm && l.crm.note) || '';
    var det = h('details', { class: 'lead' + (l.blockedAt ? ' off' : '') + (l.stage === 'urgent' ? ' urgent' : '') });
    det.appendChild(h('summary', {}, [h('b', { text: '№' + l.id }), h('span', { text: l.name || '' }), h('span', { text: l.contact || '' }), h('span', { class: 'muted', text: STAGES[l.stage] || l.stage || '' }), h('span', { class: 'muted', text: dt(l.at) }), h('span', { class: 'pill-s s-' + (l.blockedAt ? 'blocked' : st), text: l.blockedAt ? 'Заблокирована' : CRM[st] })]));
    var sel = h('select', { 'aria-label': 'Статус заявки' }, Object.keys(CRM).map(function (k) { return h('option', { value: k, text: CRM[k], selected: k === st ? true : null }); }));
    var noteBox = area(note, function (v) { note = v; }, 'Заметка менеджера: что договорились, когда перезвонить');
    det.appendChild(h('div', { class: 'lead-body' }, [
      messengerLinks(l.contact),
      h('p', {}, ['Контакт: ', contactLink(l.contact), ' · Страна: ' + (COUNTRIES[l.country] || '—') + ' · Язык: ' + (l.lang || '—')]),
      l.message ? h('p', { class: 'lead-msg', text: l.message }) : null,
      l.blockedAt ? h('p', { class: 'warn', text: 'Обработка прекращена: ' + (l.blockReason || '') }) : null,
      !l.blockedAt ? h('div', { class: 'row' }, [sel]) : null,
      !l.blockedAt ? noteBox : null,
      h('div', { class: 'row' }, [
        !l.blockedAt ? h('button', { type: 'button', class: 'btn btn-gold sm', text: 'Сохранить', onclick: function () { api('PUT', '/leads/' + l.id, { status: sel.value, note: note }).then(function () { toast('Сохранено'); viewLeads(main); }).catch(err); } }) : null,
        can('pd') && !l.blockedAt ? h('button', { type: 'button', class: 'btn-text', text: 'Заблокировать (отзыв согласия)', onclick: async function () { if (await ask('Заблокировать заявку №' + l.id + '? Обработка прекратится.')) api('POST', '/leads/' + l.id + '/block', {}).then(function () { toast('Заблокирована'); viewLeads(main); }).catch(err); } }) : null,
        can('pd') ? h('button', { type: 'button', class: 'btn-text del', text: 'Уничтожить данные', onclick: async function () { if (await ask('Безвозвратно уничтожить персональные данные заявки №' + l.id + '? После этого оформите акт об уничтожении.')) api('POST', '/leads/' + l.id + '/destroy', { reason: 'по решению администратора' }).then(function () { toast('Данные уничтожены'); viewLeads(main); }).catch(err); } }) : null
      ])
    ]));
    return det;
  }
  function viewLeads(main) {
    Promise.all([api('GET', '/leads'), api('GET', '/requests')]).then(function (r) {
      var leads = r[0].slice().reverse(), reqs = r[1].slice().reverse();
      head(main, 'Заявки', 'Персональные данные — не пересылайте и не храните копии вне сервера без необходимости.', can('pd') ? [h('button', { class: 'btn btn-line', type: 'button', text: 'Скачать CSV', onclick: function () {
        downloadCsv('zayavki.csv', ['№', 'Когда', 'Имя', 'Контакт', 'Этап', 'Страна', 'Язык', 'Описание', 'Статус', 'Заметка'], leads.filter(function (l) { return !l.destroyedAt && !l.blockedAt; }).map(function (l) { return [l.id, dt(l.at), l.name, l.contact, STAGES[l.stage] || l.stage, COUNTRIES[l.country] || '', l.lang, l.message, CRM[leadStatus(l)], (l.crm && l.crm.note) || '']; }));
      } })] : []);
      var listBox = h('section', { class: 'card' });
      var renderList = function () {
        listBox.innerHTML = '';
        var q = leadFilter.q.toLowerCase();
        var shown = leads.filter(function (l) {
          if (leadFilter.st && (l.destroyedAt || leadStatus(l) !== leadFilter.st)) return false;
          return !q || [l.id, l.name, l.contact, l.message].join(' ').toLowerCase().indexOf(q) >= 0;
        });
        if (!shown.length) listBox.appendChild(h('p', { class: 'muted', text: leads.length ? 'Ничего не найдено.' : 'Заявок пока нет.' }));
        shown.forEach(function (l) { listBox.appendChild(leadCard(l, main)); });
      };
      main.appendChild(h('div', { class: 'row filters' }, [
        h('input', { type: 'search', placeholder: 'Поиск: имя, контакт, номер', 'aria-label': 'Поиск заявок', value: leadFilter.q, oninput: function (e) { leadFilter.q = e.target.value; renderList(); } }),
        h('select', { class: 'no-dirty', 'aria-label': 'Статус', onchange: function (e) { leadFilter.st = e.target.value; renderList(); } }, [h('option', { value: '', text: 'Все статусы' })].concat(Object.keys(CRM).map(function (k) { return h('option', { value: k, text: CRM[k], selected: leadFilter.st === k ? true : null }); })))
      ]));
      renderList();
      main.appendChild(listBox);
      main.appendChild(h('section', { class: 'card' }, [h('h2', { text: 'Обращения по персональным данным' }), h('p', { class: 'muted', text: 'Отзыв согласия, запросы сведений. Ответить нужно в течение 10 рабочих дней.' }),
        reqs.length ? table(['№', 'Когда', 'Что', 'Контакт', 'Имя', 'Комментарий', 'Найдено заявок', 'Статус', ''], reqs.map(function (q) {
          return { cells: [q.id, dt(q.at), { withdraw: 'отзыв согласия', info: 'запрос сведений', correct: 'уточнение' }[q.kind] || q.kind, q.contact, q.name, q.comment, (q.leads || []).join(', '), q.status === 'done' ? 'выполнено' : (workdaysLeft(q.at) >= 0 ? 'новое · осталось дней: ' + workdaysLeft(q.at) : 'ПРОСРОЧЕНО'),
            q.status !== 'done' && can('pd') ? h('button', { type: 'button', class: 'btn btn-line sm', text: 'Выполнено', onclick: function () { api('POST', '/requests/' + q.id + '/done').then(function () { toast('Отмечено'); viewLeads(main); }).catch(err); } }) : ''] };
        })) : h('p', { class: 'muted', text: 'Обращений нет.' })]));
    }).catch(err);
  }
  function viewOrders(main) {
    api('GET', '/orders').then(function (list) {
      list = list.slice().reverse();
      head(main, 'Заказы инструкций', 'Оплаченные заказы открывают покупателю скачивание на 30 дней. Отметка возврата закрывает доступ, но деньги возвращаются в кабинете ЮKassa.');
      var ST = { new: 'создан', pending: 'ждёт оплаты', paid: 'оплачен', canceled: 'отменён', error: 'ошибка', refunded: 'возврат' };
      var linkBox = h('p', { class: 'card', hidden: true });
      main.appendChild(linkBox);
      main.appendChild(h('section', { class: 'card' }, [list.length ? table(['№', 'Когда', 'Инструкция', 'Сумма', 'E-mail', 'Статус', 'Оплачен', 'Скачиваний', ''], list.map(function (o) {
        var actions = o.status === 'paid' ? h('span', { class: 'row' }, [
          h('button', { type: 'button', class: 'btn btn-line sm', text: 'Новая ссылка', onclick: async function () { if (await ask('Выдать новую ссылку? Старая перестанет работать, срок начнётся заново.')) api('POST', '/orders/' + o.id + '/relink').then(function (r) { linkBox.hidden = false; linkBox.textContent = 'Ссылка для покупателя №' + o.id + ' (показывается один раз): ' + r.link; }).catch(err); } }),
          h('button', { type: 'button', class: 'btn-text del', text: 'Возврат', onclick: async function () { if (await ask('Отметить возврат по заказу №' + o.id + '? Доступ к файлам закроется.')) api('POST', '/orders/' + o.id + '/refunded').then(function () { toast('Возврат отмечен'); viewOrders(main); }).catch(err); } })
        ]) : '';
        return { cls: o.status === 'paid' ? '' : 'off', cells: [o.id, dt(o.at), o.title, rub(o.price), o.email, ST[o.status] || o.status, dt(o.paidAt), o.downloads || 0, actions] };
      })) : h('p', { class: 'muted', text: 'Заказов пока нет.' })]));
    }).catch(err);
  }

  /* ---------- версии контента ---------- */
  function viewVersions(main) {
    api('GET', '/snapshots').then(function (list) {
      head(main, 'Версии контента', 'Снимок всех текстов, блоков, страниц, прайса, реквизитов и настроек (без файлов). Создаётся при каждой публикации; хранятся последние 30.', [
        h('button', { class: 'btn btn-gold', type: 'button', text: 'Сохранить версию', onclick: function () { api('POST', '/snapshots', {}).then(function () { toast('Версия сохранена'); viewVersions(main); }).catch(err); } })
      ]);
      var box = h('section', { class: 'card' });
      if (!list.length) box.appendChild(h('p', { class: 'muted', text: 'Версий пока нет — первая появится при публикации.' }));
      list.forEach(function (v) {
        box.appendChild(h('div', { class: 'line' }, [h('span', { text: dt(v.at) + ' · ' + (v.reason || '') + ' · ' + (v.by || '') }), h('button', { class: 'btn btn-line sm', type: 'button', text: 'Восстановить', onclick: async function () {
          if (!await ask('Заменить текущие правки этой версией? Текущее состояние сначала сохранится как отдельная версия.')) return;
          api('POST', '/snapshots/' + v.id + '/restore').then(function () { toast('Восстановлено — проверьте и опубликуйте'); changed(); viewVersions(main); }).catch(err);
        } })]));
      });
      main.appendChild(box);
    }).catch(err);
  }

  /* ---------- пользователи ---------- */
  function viewUsers(main) {
    Promise.all([api('GET', '/users'), api('GET', '/sessions')]).then(function (r) {
      var roles = r[0].roles;
      var assignable = function (k) { return ME.owner || (k !== 'superadmin' && k !== 'admin'); };
      head(main, 'Пользователи', 'Суперадмин — всё. Администратор — сайт, клиенты, журнал. Редактор — только содержимое сайта. Менеджер — заявки и заказы.');
      var box = h('section', { class: 'card' });
      r[0].users.forEach(function (u) {
        var managed = ME.owner || (u.role !== 'superadmin' && u.role !== 'admin');
        var roleSel = h('select', { 'aria-label': 'Роль ' + u.login, onchange: function (e) { api('PUT', '/users/' + u.id, { role: e.target.value }).then(function () { toast('Роль изменена'); viewUsers(main); }).catch(function (e2) { err(e2); viewUsers(main); }); } }, Object.keys(roles).filter(assignable).map(function (k) { return h('option', { value: k, text: roles[k], selected: u.role === k ? true : null }); }));
        box.appendChild(h('div', { class: 'line user' + (u.disabled ? ' off' : '') }, [
          h('div', {}, [h('b', { text: u.name + ' (' + u.login + ')' + (u.owner ? ' · владелец' : '') }), h('p', { class: 'muted', text: (u.disabled ? 'Отключён · ' : '') + (u.totp ? '2FA включена · ' : 'без 2FA · ') + (u.lastLogin ? 'входил(а) ' + dt(u.lastLogin) : 'не входил(а)') })]),
          !managed ? h('p', { class: 'muted', text: 'Менять может только владелец' }) : h('div', { class: 'row' }, [u.owner ? null : roleSel,
            h('button', { class: 'btn btn-line sm', type: 'button', text: 'Новый пароль', onclick: async function () { var pw = await ask('Новый пароль для ' + u.login + ' (от 12 символов):', { input: 'password', ok: 'Сменить' }); if (pw) api('PUT', '/users/' + u.id, { password: pw }).then(function () { toast('Пароль изменён, сессии закрыты'); }).catch(err); } }),
            u.totp ? h('button', { class: 'btn-text', type: 'button', text: 'Сбросить 2FA', onclick: async function () { if (await ask('Сбросить 2FA у ' + u.login + '?')) api('PUT', '/users/' + u.id, { resetTotp: true }).then(function () { viewUsers(main); }).catch(err); } }) : null,
            u.owner ? null : h('button', { class: 'btn-text', type: 'button', text: u.disabled ? 'Включить' : 'Отключить', onclick: function () { api('PUT', '/users/' + u.id, { disabled: !u.disabled }).then(function () { viewUsers(main); }).catch(err); } }),
            u.id !== ME.id ? h('button', { class: 'btn-text del', type: 'button', text: 'Удалить', onclick: async function () { if (await ask('Удалить пользователя ' + u.login + '?')) api('DELETE', '/users/' + u.id).then(function () { viewUsers(main); }).catch(err); } }) : null
          ])
        ]));
      });
      main.appendChild(box);
      var nu = { login: '', name: '', role: 'editor', password: '' };
      var field = function (k, label, type) { return h('label', { class: 'f' }, [h('span', { text: label }), h('input', { type: type || 'text', name: 'new-' + k, autocomplete: 'off', oninput: function (e) { nu[k] = e.target.value; } })]); };
      main.appendChild(h('section', { class: 'card grid2' }, [h('h2', { class: 'span2', text: 'Добавить пользователя' }), field('login', 'Логин (латиницей)'), field('name', 'Имя'), field('password', 'Пароль (от 12 символов)', 'password'),
        h('label', { class: 'f' }, [h('span', { text: 'Роль' }), h('select', { onchange: function (e) { nu.role = e.target.value; } }, Object.keys(roles).filter(assignable).map(function (k) { return h('option', { value: k, text: roles[k], selected: k === nu.role ? true : null }); }))]),
        h('div', {}, [h('button', { class: 'btn btn-gold', type: 'button', text: 'Создать', onclick: function () { api('POST', '/users', nu).then(function () { toast('Пользователь создан'); viewUsers(main); }).catch(err); } })])]));
      var sess = h('section', { class: 'card' }, [h('h2', { text: 'Кто сейчас в панели' })]);
      r[1].forEach(function (s) {
        sess.appendChild(h('div', { class: 'line' }, [h('div', {}, [h('b', { text: s.login }), h('p', { class: 'muted', text: s.ip + ' · ' + dt(new Date(s.at).toISOString()) + ' · ' + s.ua })]), h('button', { class: 'btn-text del', type: 'button', text: 'Завершить', onclick: function () { api('DELETE', '/sessions/' + s.id).then(function () { viewUsers(main); }).catch(err); } })]));
      });
      main.appendChild(sess);
    }).catch(err);
  }

  /* ---------- журнал ---------- */
  function viewAudit(main) {
    api('GET', '/audit').then(function (list) {
      head(main, 'Журнал действий', 'Кто, когда и что делал в панели (последние 1000 записей). Просмотр заявок тоже записывается.');
      var q = '';
      var box = h('section', { class: 'card' });
      var render = function () {
        box.innerHTML = '';
        var shown = list.filter(function (a) { return !q || (a.user + ' ' + a.action + ' ' + a.ip).toLowerCase().indexOf(q) >= 0; });
        box.appendChild(shown.length ? table(['Когда', 'Кто', 'IP', 'Действие'], shown.map(function (a) { return { cells: [dt(a.at), a.user, a.ip, a.action] }; })) : h('p', { class: 'muted', text: 'Записей нет.' }));
      };
      main.appendChild(h('input', { type: 'search', placeholder: 'Поиск по журналу', 'aria-label': 'Поиск по журналу', oninput: function (e) { q = e.target.value.toLowerCase(); render(); } }));
      render();
      main.appendChild(box);
    }).catch(err);
  }

  /* ---------- интеграции ---------- */
  var INTEGR = [
    ['Telegram-уведомления', 'Уведомления без персональных данных: номер и этап заявки.', [['TELEGRAM_BOT_TOKEN', 'Токен бота'], ['TELEGRAM_CHAT_ID', 'ID чата (через запятую)']]],
    ['ЮKassa', 'Приём оплаты инструкций. Webhook: https://sverify.online/api/shop/webhook', [['YK_SHOP_ID', 'shopId'], ['YK_SECRET_KEY', 'Секретный ключ'], ['YK_VAT_CODE', 'Код НДС (1 — без НДС)']]],
    ['Migrant AI', 'Ключ и модель OpenRouter.', [['AI_KEY', 'API-ключ'], ['AI_MODEL', 'Модель']]]
  ];
  function restartLeads(main) {
    return api('POST', '/system/restart-leads').then(function () { toast('Применяем: сервис заявок перезапускается…'); setTimeout(function () { viewIntegrations(main); }, 5000); });
  }
  function viewIntegrations(main) {
    api('GET', '/integrations').then(function (d) {
      var changes = {};
      head(main, 'Интеграции', 'Секретные значения не показываются. Пустое поле секрета оставляет прежнее значение. При сохранении сервис заявок перезапускается (около 5 секунд).', [
        h('button', { class: 'btn btn-gold', type: 'button', text: 'Сохранить и применить', onclick: function () {
          if (!Object.keys(changes).length) { toast('Изменений нет'); return; }
          api('PUT', '/integrations', changes).then(function () { return restartLeads(main); }).catch(err);
        } })
      ]);
      INTEGR.forEach(function (g) {
        var sec = h('section', { class: 'card' }, [h('h2', { text: g[0] }), h('p', { class: 'muted', text: g[1] })]);
        g[2].forEach(function (f) {
          var k = f[0], m = d[k];
          var st = m.set ? (m.secret ? 'задан' : '') + (m.source === 'panel' ? ' (панель)' : ' (файл сервера)') : 'не задан';
          sec.appendChild(h('label', { class: 'f' }, [h('span', { text: f[1] + ' — ' + st }), h('input', { type: m.secret ? 'password' : 'text', autocomplete: 'new-password', name: k, value: m.value, placeholder: m.secret && m.set ? '•••••••• (оставить прежний)' : '', oninput: function (e) { changes[k] = e.target.value; } })]));
          if (m.secret && m.source === 'panel') sec.appendChild(h('div', {}, [h('button', { class: 'btn-text del', type: 'button', text: 'Удалить значение из панели', onclick: async function () { if (await ask('Удалить значение?')) api('PUT', '/integrations', (function () { var o = {}; o[k] = ''; return o; })()).then(function () { return restartLeads(main); }).catch(err); } })]));
        });
        if (g[0] === 'Telegram-уведомления') sec.appendChild(h('div', {}, [h('button', { class: 'btn btn-line sm', type: 'button', text: 'Отправить проверочное сообщение', onclick: function () { api('POST', '/integrations/test-telegram').then(function () { toast('Сообщение отправлено'); }).catch(err); } })]));
        main.appendChild(sec);
      });
    }).catch(err);
  }

  /* ---------- сервер ---------- */
  function pct(free, total) { return Math.round((1 - free / total) * 100) + '%'; }
  function gb(n) { return (n / 1073741824).toFixed(1) + ' ГБ'; }
  function viewSystem(main) {
    api('GET', '/system').then(function (s) {
      head(main, 'Сервер', 'Состояние сервера и сервиса заявок.');
      main.appendChild(h('section', { class: 'tiles' }, [
        stat('Диск занят', pct(s.disk.free, s.disk.total), 'свободно ' + gb(s.disk.free)), stat('Память занята', pct(s.mem.free, s.mem.total), 'всего ' + gb(s.mem.total)),
        stat('Нагрузка (1 мин)', s.load[0].toFixed(2)), stat('Работает без перезагрузки', Math.floor(s.uptime / 86400) + ' дн.')
      ]));
      var l = s.leads;
      var on = function (b) { return b ? 'включено' : 'выключено'; };
      main.appendChild(h('section', { class: 'card' }, [h('h2', { text: 'Сервис заявок' }), l.error ? h('p', { class: 'warn', text: 'Нет связи: ' + l.error }) : h('ul', { class: 'help' }, [
        h('li', { text: 'Работает без перезапуска: ' + Math.floor(l.uptime / 60) + ' мин' }), h('li', { text: 'Версия согласия: ' + l.consent }), h('li', { text: 'Telegram: ' + on(l.telegram) }), h('li', { text: 'Оплата ЮKassa: ' + on(l.pay) }), h('li', { text: 'Migrant AI: ' + on(l.ai) })]),
        h('div', {}, [h('button', { class: 'btn btn-line sm', type: 'button', text: 'Перезапустить сервис заявок', onclick: async function () { if (await ask('Перезапустить? Около 5 секунд форма на сайте не будет принимать заявки.')) api('POST', '/system/restart-leads').then(function () { toast('Перезапуск…'); setTimeout(function () { viewSystem(main); }, 5000); }).catch(err); } })])]));
    }).catch(err);
  }

  /* ---------- профиль ---------- */
  function viewProfile(main) {
    api('GET', '/me').then(function (m) {
      ME = m.user;
      head(main, 'Мой профиль', ME.name + ' · ' + ME.login + ' · ' + ME.roleLabel);
      var cur = h('input', { type: 'password', name: 'current', autocomplete: 'current-password' }), nw = h('input', { type: 'password', name: 'new', autocomplete: 'new-password' });
      main.appendChild(h('section', { class: 'card' }, [h('h2', { text: 'Сменить пароль' }), h('label', { class: 'f' }, [h('span', { text: 'Текущий пароль' }), cur]), h('label', { class: 'f' }, [h('span', { text: 'Новый пароль (от 12 символов)' }), nw]),
        h('div', {}, [h('button', { class: 'btn btn-gold', type: 'button', text: 'Сменить', onclick: function () { api('POST', '/me/password', { current: cur.value, password: nw.value }).then(function () { toast('Пароль изменён, другие сессии закрыты'); cur.value = ''; nw.value = ''; }).catch(err); } })])]));
      var tf = h('section', { class: 'card' }, [h('h2', { text: 'Двухфакторный вход' })]);
      if (ME.totp) {
        var p2 = h('input', { type: 'password', placeholder: 'Текущий пароль', autocomplete: 'current-password' });
        tf.appendChild(h('p', { class: 'ok', text: '2FA включена.' })); tf.appendChild(p2);
        tf.appendChild(h('div', {}, [h('button', { class: 'btn btn-line', type: 'button', text: 'Отключить 2FA', onclick: function () { api('POST', '/me/totp/disable', { current: p2.value }).then(function () { toast('2FA отключена'); viewProfile(main); }).catch(err); } })]));
      } else {
        tf.appendChild(h('p', { class: 'muted', text: 'Вход будет требовать код из приложения (Google Authenticator, Яндекс Ключ и другие).' }));
        tf.appendChild(h('div', {}, [h('button', { class: 'btn btn-gold', type: 'button', text: 'Включить 2FA', onclick: function () {
          api('POST', '/me/totp/setup').then(function (r) {
            tf.innerHTML = '';
            var code = h('input', { type: 'text', inputmode: 'numeric', maxlength: 6, placeholder: 'Код из приложения' });
            tf.appendChild(h('h2', { text: 'Двухфакторный вход' }));
            tf.appendChild(h('p', { text: 'Добавьте в приложении аккаунт вручную, тип «по времени», ключ:' }));
            tf.appendChild(h('code', { class: 'secret', text: r.secret }));
            tf.appendChild(h('a', { href: r.uri, text: 'С телефона: открыть в приложении' }));
            tf.appendChild(code);
            tf.appendChild(h('div', {}, [h('button', { class: 'btn btn-gold', type: 'button', text: 'Подтвердить', onclick: function () { api('POST', '/me/totp/enable', { code: code.value }).then(function () { toast('2FA включена'); viewProfile(main); }).catch(err); } })]));
          }).catch(err);
        } })]));
      }
      main.appendChild(tf);
    }).catch(err);
  }

  start().catch(function () { showLogin(); });
})();
