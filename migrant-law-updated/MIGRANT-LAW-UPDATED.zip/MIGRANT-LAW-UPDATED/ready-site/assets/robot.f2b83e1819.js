// Страница-рамка /robot/ с 3D-роботом Migrant AI (Spline). Живёт в iframe на главной.
// Рантайм Spline выполняет код через new Function (embind), поэтому ему нужна CSP с 'unsafe-eval' —
// она разрешена только здесь, на /robot/, а не на страницах с формой и чатом.
// Главная передаёт положение курсора (postMessage), чтобы робот смотрел на него по всей карточке.
import { Application } from './spline-1.9.98/runtime.js';

const canvas = document.getElementById('robot');
const parentOrigin = location.origin;
const say = (t) => { if (window.parent !== window) window.parent.postMessage({ robot: t }, parentOrigin); };

new Application(canvas).load('/assets/spline-1.9.98/robot.splinecode')
  .then(() => say('ready'))
  .catch(() => say('failed'));

window.addEventListener('message', (e) => {
  if (e.origin !== parentOrigin || !e.data || e.data.robot !== 'pointer') return;
  const { x, y } = e.data;
  if (typeof x !== 'number' || typeof y !== 'number') return;
  canvas.dispatchEvent(new PointerEvent('pointermove', { clientX: x, clientY: y, bubbles: true, pointerType: 'mouse', isPrimary: true }));
});
