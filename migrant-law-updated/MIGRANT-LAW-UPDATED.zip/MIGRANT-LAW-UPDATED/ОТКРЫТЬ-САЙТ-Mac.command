#!/bin/sh
cd "$(dirname "$0")"
node open-site.mjs
