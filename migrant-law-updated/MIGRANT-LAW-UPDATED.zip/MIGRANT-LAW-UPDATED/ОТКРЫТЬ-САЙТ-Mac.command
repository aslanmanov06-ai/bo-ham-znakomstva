#!/bin/sh
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then echo "Нужна программа Node.js: откроется nodejs.org, установите версию LTS и запустите этот файл снова."; open https://nodejs.org/; exit 1; fi
node open-site.mjs
