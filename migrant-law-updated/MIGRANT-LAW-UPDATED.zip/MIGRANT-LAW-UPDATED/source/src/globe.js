// Глобус первого экрана: объёмная тёмная сфера с золотыми материками (точки и контуры — scripts/make-globe.mjs),
// сеткой параллелей и меридианов, светом сверху-слева, бирюзовыми и золотыми орбитами с бегущими искрами
// и флагами-булавками стран. Вращается непрерывно; когда к зрителю повёрнуты Россия и Центральная Азия — медленнее.
// Без библиотек (Canvas 2D, перспективная проекция). При prefers-reduced-motion — неподвижный кадр;
// вне экрана и в фоновой вкладке не рисует; на телефоне — облегчённый режим (меньше точек, 30 кадров/с).
(function () {
  'use strict';
  var cv = document.querySelector('canvas.globe');
  if (!cv || !cv.getContext || typeof GLOBE_DOTS === 'undefined') return;
  var ctx = cv.getContext('2d');
  var PERIOD = 56000;            // мс на полный оборот
  var SLOW = 0.72;               // 0…1: насколько вращение замедляется, когда Евразия повёрнута к зрителю
  var CENTER = 74;               // долгота, которая задерживается перед зрителем (Центральная Азия)
  var TILT = 0.50;               // наклон оси к зрителю, рад
  var ROLL = -0.20;              // наклон оси вбок, рад
  var CAM = 3.4;                 // расстояние камеры в радиусах сферы (перспектива)
  var KR = 0.355;                // радиус сферы в долях стороны холста
  var mq = function (q) { return !!window.matchMedia && matchMedia(q).matches; };
  var reduce = mq('(prefers-reduced-motion: reduce)');
  var small = mq('(max-width: 760px)');
  var lite = small;               // облегчённый режим: меньше деталей, 30 кадров/с
  var D2R = Math.PI / 180, TAU = Math.PI * 2;
  var GOLD = '243,213,143', TEAL = '92,225,230';

  /* ---------- Данные ---------- */
  function vec(lat, lon) { var cl = Math.cos(lat); return [cl * Math.sin(lon), Math.sin(lat), cl * Math.cos(lon)]; }
  // Точки суши: номера на сфере Фибоначчи (приращения в 36-ричной записи).
  function dots(s, step) {
    var n = GLOBE_DOTS.n, ga = Math.PI * (3 - Math.sqrt(5)), parts = s ? s.split(',') : [], out = [], i = 0;
    for (var k = 0; k < parts.length; k++) {
      i += parseInt(parts[k], 36);
      if (step > 1 && k % step) continue;
      var y = 1 - (i / (n - 1)) * 2, lon = i * ga, r = Math.sqrt(1 - y * y);
      out.push(r * Math.sin(lon), y, r * Math.cos(lon));
    }
    return new Float32Array(out);
  }
  // Контуры материков: кольца из вершин (широта, долгота ×10; дальше приращения).
  function coast(s) {
    return (s ? s.split(';') : []).map(function (ring) {
      var a = ring.split(','), la = 0, lo = 0, out = new Float32Array(a.length / 2 * 3);
      for (var i = 0; i < a.length; i += 2) {
        la += +a[i]; lo += +a[i + 1];
        var v = vec(la / 10 * D2R, lo / 10 * D2R);
        out[i / 2 * 3] = v[0]; out[i / 2 * 3 + 1] = v[1]; out[i / 2 * 3 + 2] = v[2];
      }
      return out;
    });
  }
  // Сетка: параллели и меридианы через 20°.
  function grid() {
    var lines = [], a, lat, lon;
    for (lat = -60; lat <= 60; lat += 20) { a = []; for (lon = -180; lon <= 180; lon += 5) a.push.apply(a, vec(lat * D2R, lon * D2R)); lines.push(new Float32Array(a)); }
    for (lon = -180; lon < 180; lon += 20) { a = []; for (lat = -80; lat <= 80; lat += 5) a.push.apply(a, vec(lat * D2R, lon * D2R)); lines.push(new Float32Array(a)); }
    return lines;
  }
  var LAND = dots(GLOBE_DOTS.land, small ? 2 : 1), HI = dots(GLOBE_DOTS.hi, 1), COAST = coast(GLOBE_DOTS.coast), GRID = grid();

  // Флаги: страна, широта и долгота булавки (над самой страной), сдвиг флага от точки (в радиусах сферы), размер,
  // 1 — не показывать на телефоне (там меньше флагов, чтобы были видны материки). Ширина флага — по его настоящим
  // пропорциям (США 19:10, Канада 2:1, Бразилия 10:7…), высота у всех одинаковая.
  var FLAGS = [
    ['ru', 61, 96, 0, -0.17, 1.55],
    ['kz', 48.5, 68, 0.02, -0.10, 1],
    ['uz', 41.5, 63.5, -0.11, -0.03, 1],
    ['kg', 41.4, 75, 0.12, -0.03, 1],
    ['tj', 38.6, 71, 0.01, 0.13, 1],
    ['az', 40.3, 48, -0.16, -0.10, 1],
    ['am', 40.2, 44.8, -0.20, 0.06, 1],
    ['tr', 39, 34, -0.12, -0.16, 1],
    ['md', 47.2, 28.6, 0.07, -0.17, 1],
    ['de', 51, 10.5, -0.12, -0.10, 1],
    ['ae', 24, 54.3, -0.05, 0.15, 1],
    ['cn', 36, 103, 0.14, 0.02, 1],
    ['in', 22, 79, 0.05, 0.14, 1],
    ['se', 62, 15.5, 0.05, -0.16, 1, 1],
    ['eg', 26.8, 30.8, -0.11, 0.10, 1, 1],
    ['ng', 9, 8, -0.07, 0.04, 1],
    ['ke', 0.5, 38, 0.07, 0.07, 1, 1],
    ['za', -29, 25, 0, 0.07, 1],
    ['us', 39.5, -98, 0, 0.09, 1],
    ['ca', 58, -101, 0.02, -0.13, 1],
    ['br', -10.5, -52, 0, 0.05, 1],
    ['nz', -41.5, 173, 0, -0.08, 1]
  ].filter(function (f) { return !(small && f[6]) && !(small && (f[0] === 'am' || f[0] === 'de')); }).map(function (f, n) {
    var img = new Image();
    var o = { v: vec(f[1] * D2R, f[2] * D2R), ox: f[3], oy: f[4], k: f[5], img: img, ok: false, ar: 1.5, n: n, fade: 1, x: 0, y: 0, z: 0, s: 1 };
    img.onload = function () { o.ok = true; o.ar = img.naturalWidth / img.naturalHeight || 1.5; if (!raf) draw(now()); };
    img.src = '/media/fl-' + f[0] + '.webp';
    return o;
  });

  // Орбиты: радиус (в радиусах сферы), наклон плоскости, поворот узла, цвет, период искры (мс), начальная фаза.
  var ORBITS = [
    { r: 1.22, inc: 1.34, node: 0.42, col: GOLD, period: 15000, ph: 0.1, w: 1.1 },
    { r: 1.30, inc: 1.22, node: -0.50, col: TEAL, period: 21000, ph: 0.55, w: 1.2 },
    { r: 1.38, inc: 1.45, node: -1.05, col: GOLD, period: 27000, ph: 0.8, w: 0.8 }
  ];
  var OSEG = small ? 96 : 160;

  /* ---------- Размер и заранее нарисованные слои ---------- */
  var W = 0, R = 0, C = 0, dpr = 1, u = 1, base = null, shade = null, spark = {};
  function layer(w) { var c = document.createElement('canvas'); c.width = c.height = Math.max(1, Math.round(w * dpr)); var x = c.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); return [c, x]; }
  function size() {
    var r = cv.getBoundingClientRect();
    W = Math.max(1, Math.round(r.width));
    dpr = Math.min(window.devicePixelRatio || 1, lite ? (small ? 1.5 : 1.25) : 2, 1700 / W);
    cv.width = cv.height = Math.round(W * dpr);
    R = W * KR; C = W / 2; u = W / 760;
    var g, l, x;
    // Тело сферы: ореол, тёмное «стекло» со светом сверху-слева, блик.
    l = layer(W); base = l[0]; x = l[1];
    g = x.createRadialGradient(C, C, R * 0.9, C, C, R * 1.36);
    g.addColorStop(0, 'rgba(226,184,101,.20)'); g.addColorStop(0.35, 'rgba(226,184,101,.07)'); g.addColorStop(1, 'rgba(226,184,101,0)');
    x.fillStyle = g; x.beginPath(); x.arc(C, C, R * 1.36, 0, TAU); x.fill();
    g = x.createRadialGradient(C - R * 0.38, C - R * 0.42, R * 0.05, C, C, R);
    g.addColorStop(0, '#2A2B2C'); g.addColorStop(0.45, '#141516'); g.addColorStop(0.85, '#08090A'); g.addColorStop(1, '#040506');
    x.fillStyle = g; x.beginPath(); x.arc(C, C, R, 0, TAU); x.fill();
    g = x.createRadialGradient(C - R * 0.45, C - R * 0.55, 0, C - R * 0.45, C - R * 0.55, R * 0.75);
    g.addColorStop(0, 'rgba(255,240,205,.13)'); g.addColorStop(1, 'rgba(255,240,205,0)');
    x.save(); x.beginPath(); x.arc(C, C, R, 0, TAU); x.clip(); x.fillStyle = g; x.fillRect(0, 0, W, W); x.restore();
    // Тень и кромки поверх материков: затемнение к правому нижнему краю, золотая кромка слева-сверху, бирюзовая — справа-снизу.
    l = layer(W); shade = l[0]; x = l[1];
    x.save(); x.beginPath(); x.arc(C, C, R, 0, TAU); x.clip();
    g = x.createRadialGradient(C - R * 0.5, C - R * 0.55, R * 0.5, C - R * 0.2, C - R * 0.2, R * 1.75);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.55, 'rgba(0,0,0,.20)'); g.addColorStop(1, 'rgba(0,0,0,.68)');
    x.fillStyle = g; x.fillRect(0, 0, W, W);
    g = x.createRadialGradient(C, C, R * 0.80, C, C, R);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.40)');
    x.fillStyle = g; x.fillRect(0, 0, W, W);
    x.restore();
    // Кромка: кольцо света у края, видимое только с одной стороны (dx, dy — куда светит).
    var rim = function (col, a, dx, dy, from) {
      var t = layer(W), tx = t[1], rg = tx.createRadialGradient(C, C, R * from, C, C, R);
      rg.addColorStop(0, 'rgba(' + col + ',0)'); rg.addColorStop(0.7, 'rgba(' + col + ',' + a * 0.3 + ')'); rg.addColorStop(1, 'rgba(' + col + ',' + a + ')');
      tx.fillStyle = rg; tx.beginPath(); tx.arc(C, C, R, 0, TAU); tx.fill();
      tx.globalCompositeOperation = 'destination-in';
      var lg = tx.createLinearGradient(C - dx * R, C - dy * R, C + dx * R, C + dy * R);
      lg.addColorStop(0, 'rgba(0,0,0,0)'); lg.addColorStop(0.42, 'rgba(0,0,0,0)'); lg.addColorStop(1, 'rgba(0,0,0,1)');
      tx.fillStyle = lg; tx.fillRect(0, 0, W, W);
      x.drawImage(t[0], 0, 0, W, W);
    };
    rim(GOLD, 0.62, -0.72, -0.69, 0.84);
    rim(TEAL, 0.60, 0.78, 0.62, 0.80);
    x.lineWidth = 1; x.strokeStyle = 'rgba(' + GOLD + ',.30)'; x.beginPath(); x.arc(C, C, R, 0, TAU); x.stroke();
    // Искры орбит.
    [GOLD, TEAL].forEach(function (col) {
      var s = 44 * Math.max(u, 0.6), sl = layer(s), sx = sl[1], sg = sx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
      sg.addColorStop(0, 'rgba(255,255,255,1)'); sg.addColorStop(0.12, 'rgba(' + col + ',.95)'); sg.addColorStop(0.45, 'rgba(' + col + ',.22)'); sg.addColorStop(1, 'rgba(' + col + ',0)');
      sx.fillStyle = sg; sx.fillRect(0, 0, s, s);
      spark[col] = [sl[0], s];
    });
  }

  /* ---------- Проекция ---------- */
  var m = new Float32Array(9), KP = Math.sqrt(CAM * CAM - 1) / CAM, ZLIM = 1 / CAM;
  var px = 0, py = 0, pxT = 0, pyT = 0; // лёгкий параллакс за курсором
  function setRot(rot) {
    var tilt = TILT + py * 0.07, roll = ROLL + px * 0.05;
    var cy = Math.cos(rot), sy = Math.sin(rot), ct = Math.cos(tilt), st = Math.sin(tilt), cr = Math.cos(roll), sr = Math.sin(roll);
    // M = Rz(roll) · Rx(tilt) · Ry(rot)
    var a0 = cy, a1 = 0, a2 = sy, b0 = st * sy, b1 = ct, b2 = -st * cy, c0 = -ct * sy, c1 = st, c2 = ct * cy;
    m[0] = cr * a0 - sr * b0; m[1] = cr * a1 - sr * b1; m[2] = cr * a2 - sr * b2;
    m[3] = sr * a0 + cr * b0; m[4] = sr * a1 + cr * b1; m[5] = sr * a2 + cr * b2;
    m[6] = c0; m[7] = c1; m[8] = c2;
  }
  // Точка в системе зрителя → экран (перспектива; силуэт сферы остаётся радиуса R).
  var P = [0, 0, 0];
  function proj(x, y, z) {
    var s = CAM / (CAM - z) * KP;
    P[0] = C + x * R * s; P[1] = C - y * R * s; P[2] = z;
  }
  function rotProj(a, i) {
    var x = a[i], y = a[i + 1], z = a[i + 2];
    proj(m[0] * x + m[1] * y + m[2] * z, m[3] * x + m[4] * y + m[5] * z, m[6] * x + m[7] * y + m[8] * z);
  }

  /* ---------- Рисование ---------- */
  var BUCKETS = 4;
  function drawDots(arr, col, rad, backA) {
    var paths = [], i, b, n = arr.length, back = backA > 0 ? new Path2D() : null;
    for (b = 0; b < BUCKETS; b++) paths.push(new Path2D());
    for (i = 0; i < n; i += 3) {
      rotProj(arr, i);
      var z = P[2];
      if (z < ZLIM) { if (back && z < -0.05) { back.rect(P[0] - rad * 0.4, P[1] - rad * 0.4, rad * 0.8, rad * 0.8); } continue; }
      var f = (z - ZLIM) / (1 - ZLIM);            // 0 у края … 1 в центре
      b = Math.min(BUCKETS - 1, (f * BUCKETS) | 0);
      var s = rad * (0.62 + 0.5 * f);
      if (lite || s * dpr < 1.6) paths[b].rect(P[0] - s, P[1] - s, s * 2, s * 2);
      else { paths[b].moveTo(P[0] + s, P[1]); paths[b].arc(P[0], P[1], s, 0, TAU); }
    }
    if (back && !lite) { ctx.fillStyle = 'rgba(' + col + ',' + backA + ')'; ctx.fill(back); }
    for (b = 0; b < BUCKETS; b++) { ctx.fillStyle = 'rgba(' + col + ',' + (0.30 + 0.70 * (b + 0.5) / BUCKETS).toFixed(2) + ')'; ctx.fill(paths[b]); }
  }
  function linePath(lines) {
    var p = new Path2D();
    for (var k = 0; k < lines.length; k++) {
      var a = lines[k], pen = false;
      for (var i = 0; i < a.length; i += 3) {
        rotProj(a, i);
        if (P[2] < ZLIM + 0.02) { pen = false; continue; }
        if (pen) p.lineTo(P[0], P[1]); else { p.moveTo(P[0], P[1]); pen = true; }
      }
    }
    return p;
  }
  // Орбита: front=false — дальняя половина (рисуется до сферы), true — ближняя (после).
  function drawOrbit(o, t, front) {
    var ci = Math.cos(o.inc), si = Math.sin(o.inc), node = o.node + t / 90000, cn = Math.cos(node), sn = Math.sin(node);
    var head = (t / o.period + o.ph) % 1, i, th, x, y, z, x0, y0, prev = null, tailLen = 0.16;
    ctx.lineCap = 'round';
    var ring = new Path2D(), pen = false, tail = [];
    for (i = 0; i <= OSEG; i++) {
      th = i / OSEG * TAU;
      x0 = Math.cos(th) * o.r; y0 = Math.sin(th) * o.r;
      // круг в плоскости XZ, наклонённой на inc вокруг X и повёрнутой на node вокруг Z
      x = x0; y = y0 * ci; z = y0 * si;
      proj(x * cn - y * sn, x * sn + y * cn, z);
      var cur = [P[0], P[1], z];
      var show = prev && (z >= 0) === front && (front || Math.pow(P[0] - C, 2) + Math.pow(P[1] - C, 2) >= R * R * 0.985);
      if (show) {
        if (!pen) ring.moveTo(prev[0], prev[1]);
        ring.lineTo(cur[0], cur[1]); pen = true;
        var d = (head - i / OSEG + 1) % 1;         // расстояние позади искры, 0…1
        if (d < tailLen) tail.push(prev[0], prev[1], cur[0], cur[1], 1 - d / tailLen);
      } else pen = false;
      prev = cur;
    }
    var w0 = Math.max(u, 0.7);
    ctx.strokeStyle = 'rgba(' + o.col + ',' + (front ? 0.36 : 0.15) + ')'; ctx.lineWidth = o.w * w0; ctx.stroke(ring);
    for (i = 0; i < tail.length; i += 5) {
      var glow = tail[i + 4];
      ctx.strokeStyle = 'rgba(' + o.col + ',' + (glow * glow * (front ? 0.75 : 0.35)).toFixed(3) + ')';
      ctx.lineWidth = (o.w + 1.6 * glow) * w0;
      ctx.beginPath(); ctx.moveTo(tail[i], tail[i + 1]); ctx.lineTo(tail[i + 2], tail[i + 3]); ctx.stroke();
    }
    // Искра
    th = head * TAU; x0 = Math.cos(th) * o.r; y0 = Math.sin(th) * o.r;
    x = x0; y = y0 * ci; z = y0 * si;
    proj(x * cn - y * sn, x * sn + y * cn, z);
    if ((z >= 0) === front && (front || Math.pow(P[0] - C, 2) + Math.pow(P[1] - C, 2) > R * R)) {
      var sp = spark[o.col], s = sp[1] * (front ? 1 : 0.7);
      ctx.globalAlpha = front ? 1 : 0.6;
      ctx.drawImage(sp[0], P[0] - s / 2, P[1] - s / 2, s, s);
      ctx.globalAlpha = 1;
    }
  }
  function rr(x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function drawFlags(t) {
    var i, f, list = [];
    for (i = 0; i < FLAGS.length; i++) {
      f = FLAGS[i];
      rotProj(f.v, 0);
      f.x = P[0]; f.y = P[1]; f.z = P[2];
      f.s = Math.max(0, Math.min(1, (P[2] - 0.16) / 0.26));   // плавно гаснет у края сферы
      if (f.s > 0.01 && f.ok) list.push(f);
    }
    list.sort(function (a, b) { return a.z - b.z; });
    // Размеры и положение флагов на экране.
    for (i = 0; i < list.length; i++) {
      f = list[i];
      f.e = f.s * f.s * (3 - 2 * f.s); f.kk = (0.80 + 0.20 * f.z) * f.k;
      f.fh = W * (small ? 0.074 : 0.062) * f.kk * 2 / 3; f.fw = f.fh * f.ar;
      var bob = reduce ? 0 : Math.sin(t / 1700 + f.n * 1.7) * 2.2 * u;
      f.fx = f.x + f.ox * R * (0.55 + 0.45 * f.e); f.fy = f.y + f.oy * R * (0.55 + 0.45 * f.e) - f.fh * 0.5 + bob;
    }
    // Если флаг сильно перекрыт более близким, он плавно становится полупрозрачным (место на карте не меняется).
    for (i = 0; i < list.length; i++) {
      f = list[i];
      var cover = 0;
      for (var j = i + 1; j < list.length; j++) {
        var q = list[j];
        var ox = Math.min(f.fx + f.fw / 2, q.fx + q.fw / 2) - Math.max(f.fx - f.fw / 2, q.fx - q.fw / 2);
        var oy = Math.min(f.fy + f.fh / 2, q.fy + q.fh / 2) - Math.max(f.fy - f.fh / 2, q.fy - q.fh / 2);
        if (ox > 0 && oy > 0) cover = Math.max(cover, ox * oy / (f.fw * f.fh) * q.e);
      }
      var target = 1 - 0.8 * Math.min(1, cover * 1.6);
      f.fade += (target - f.fade) * (reduce ? 1 : 0.18);
    }
    for (i = 0; i < list.length; i++) {
      f = list[i];
      var e = f.e * f.fade, k = f.kk, fh = f.fh, fw = f.fw, rad = fh * 0.2, fx = f.fx, fy = f.fy;
      ctx.globalAlpha = e;
      // точка на карте и ножка булавки
      var teal = f.n % 2 === 1, col = teal ? TEAL : GOLD;
      var g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, 9 * u * k);
      g.addColorStop(0, 'rgba(255,255,255,.95)'); g.addColorStop(0.25, 'rgba(' + col + ',.9)'); g.addColorStop(1, 'rgba(' + col + ',0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(f.x, f.y, 9 * u * k, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(' + col + ',.85)'; ctx.lineWidth = Math.max(1, 1.4 * u);
      ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(fx, fy + fh / 2); ctx.stroke();
      // флаг: тень, изображение со скруглением, тонкая светлая кромка и блик
      rr(fx - fw / 2 - 1.5 * u, fy - fh / 2 + 3 * u, fw + 3 * u, fh + 2 * u, rad * 1.2); ctx.fillStyle = 'rgba(0,0,0,.42)'; ctx.fill();
      ctx.save();
      rr(fx - fw / 2, fy - fh / 2, fw, fh, rad); ctx.clip();
      ctx.drawImage(f.img, fx - fw / 2, fy - fh / 2, fw, fh);
      var gl = ctx.createLinearGradient(fx - fw / 2, fy - fh / 2, fx + fw / 2, fy + fh / 2);
      gl.addColorStop(0, 'rgba(255,255,255,.28)'); gl.addColorStop(0.45, 'rgba(255,255,255,0)'); gl.addColorStop(1, 'rgba(0,0,0,.22)');
      ctx.fillStyle = gl; ctx.fillRect(fx - fw / 2, fy - fh / 2, fw, fh);
      ctx.restore();
      rr(fx - fw / 2, fy - fh / 2, fw, fh, rad); ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = Math.max(1, 1.1 * u); ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
  // Угол поворота: полный оборот за PERIOD, но у долготы CENTER вращение медленнее (без остановок и рывков).
  function angle(t) {
    var p = (t % PERIOD) / PERIOD * TAU;
    return -CENTER * D2R + p - SLOW * Math.sin(p);
  }
  function draw(t) {
    if (!W) return;
    px += (pxT - px) * 0.06; py += (pyT - py) * 0.06;
    setRot(angle(t));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, W);
    var i;
    for (i = 0; i < ORBITS.length; i++) drawOrbit(ORBITS[i], t, false);
    ctx.drawImage(base, 0, 0, W, W);
    ctx.save(); ctx.beginPath(); ctx.arc(C, C, R, 0, TAU); ctx.clip();
    ctx.lineWidth = Math.max(0.6, 0.7 * u); ctx.strokeStyle = 'rgba(' + GOLD + ',.10)'; ctx.stroke(linePath(GRID));
    drawDots(LAND, '226,178,96', 1.45 * u, lite ? 0 : 0.07);
    drawDots(HI, '255,226,160', 1.75 * u, lite ? 0 : 0.09);
    var cp = linePath(COAST);
    ctx.lineJoin = 'round';
    if (!lite) { ctx.lineWidth = 4.5 * u; ctx.strokeStyle = 'rgba(' + GOLD + ',.10)'; ctx.stroke(cp); }
    ctx.lineWidth = Math.max(0.8, 1.15 * u); ctx.strokeStyle = 'rgba(255,224,160,.78)'; ctx.stroke(cp);
    ctx.restore();
    ctx.drawImage(shade, 0, 0, W, W);
    drawFlags(t);
    for (i = 0; i < ORBITS.length; i++) drawOrbit(ORBITS[i], t, true);
  }

  /* ---------- Цикл ---------- */
  var visible = true, raf = 0, last = 0, t0 = performance.now(), cost = 0, frames = 0;
  function now() { return reduce ? 0 : performance.now() - t0; }
  function loop(ts) {
    raf = 0;
    if (!visible || document.hidden) return;
    if (!lite || ts - last > 30) {
      last = ts;
      var s0 = performance.now(); draw(ts - t0);
      // Если кадр в среднем рисуется дольше 12 мс — устройство слабое: включаем облегчённый режим (как на телефоне).
      if (!lite && frames < 40) { cost += performance.now() - s0; if (++frames === 40 && cost / 40 > 12) { lite = true; dpr = Math.min(dpr, 1.25); size(); } }
    }
    raf = requestAnimationFrame(loop);
  }
  function kick() { if (!reduce && !raf && visible && !document.hidden) raf = requestAnimationFrame(loop); }

  size(); draw(now());
  var rt = 0;
  window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(function () { small = mq('(max-width: 760px)'); if (small) lite = true; size(); draw(now()); }, 80); });
  document.addEventListener('visibilitychange', kick);
  if ('IntersectionObserver' in window) new IntersectionObserver(function (es) { visible = es[0].isIntersecting; kick(); }).observe(cv);
  // Параллакс: глобус чуть наклоняется вслед за курсором (только мышь, не на телефоне).
  if (!reduce && !small) window.addEventListener('pointermove', function (e) {
    if (e.pointerType !== 'mouse') return;
    pxT = e.clientX / window.innerWidth * 2 - 1; pyT = e.clientY / window.innerHeight * 2 - 1;
  }, { passive: true });
  kick();
})();
