// Настройки интеграций, заданные в админ-панели (DATA_DIR/settings.json, права 600), поверх /etc/sverify/leads.env.
// Модуль импортируется в lead-server.mjs первым: остальные читают process.env при загрузке, поэтому
// применение новых значений требует перезапуска сервиса (панель делает его кнопкой).
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

export const SETTING_KEYS = {
  TELEGRAM_BOT_TOKEN: { secret: true }, TELEGRAM_CHAT_ID: { secret: false },
  YK_SHOP_ID: { secret: false }, YK_SECRET_KEY: { secret: true }, YK_VAT_CODE: { secret: false },
  AI_KEY: { secret: true }, AI_MODEL: { secret: false }
};
export const SETTINGS_FILE = join(process.env.DATA_DIR || '/var/lib/sverify', 'settings.json');

export function panelSettings() {
  try { return JSON.parse(readFileSync(SETTINGS_FILE, 'utf8')); }
  catch (e) { if (e.code === 'ENOENT') return {}; throw e; }
}
for (const [k, v] of Object.entries(panelSettings())) if (k in SETTING_KEYS && v) process.env[k] = v;
