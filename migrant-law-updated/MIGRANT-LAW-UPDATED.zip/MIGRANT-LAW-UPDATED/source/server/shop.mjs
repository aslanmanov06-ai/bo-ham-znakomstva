// Раздел «Оформите документы самостоятельно»: продажа PDF-инструкций через ЮKassa.
//   GET  /api/shop/products        — товары (цены и тексты из SHOP_DIR/products.json; файлы есть / оплата включена)
//   POST /api/shop/order           — заказ: e-mail для чека, согласие, оферта → ссылка на оплату ЮKassa
//   POST /api/shop/webhook         — уведомление ЮKassa; статус ВСЕГДА перепроверяется запросом к API ЮKassa
//   GET  /api/shop/status?t=…      — статус заказа по секретному токену; после оплаты — список файлов
//   GET  /api/shop/file?t=…&f=…    — выдача файла только оплаченному заказу (срок и число скачиваний ограничены)
// Администратор меняет цены, тексты и PDF без правки кода: SHOP_DIR/products.json и SHOP_DIR/files/<id>/
// (удобнее — scripts/shop-admin.mjs). Файлы лежат вне сайта, по прямой ссылке их не скачать.
// Окружение: SHOP_DIR, YK_SHOP_ID, YK_SECRET_KEY, YK_VAT_CODE (1 — без НДС), YK_API (для проверки), SITE_URL.
import { readFile, writeFile, rename, mkdir, readdir, stat, copyFile } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { join, basename } from 'node:path';
import { randomBytes, createHash, randomUUID } from 'node:crypto';

const SHOP_DIR = process.env.SHOP_DIR || '/var/lib/sverify/shop';
export const PRODUCTS = join(SHOP_DIR, 'products.json');
export const ORDERS = join(SHOP_DIR, 'orders.json');
export const FILES = join(SHOP_DIR, 'files');
const DEFAULTS = process.env.SHOP_DEFAULTS || new URL('./shop-products.json', import.meta.url).pathname;
const YK_ID = process.env.YK_SHOP_ID || '';
const YK_KEY = process.env.YK_SECRET_KEY || '';
const YK_API = process.env.YK_API || 'https://api.yookassa.ru/v3';
const VAT = Number(process.env.YK_VAT_CODE || 1);
const SITE = process.env.SITE_URL || 'https://sverify.online';
const ACCESS_DAYS = 30;
const MAX_DOWNLOADS = 50;
const LANGS = ['ru', 'tg', 'kk', 'ky', 'uz'];
export const payEnabled = () => Boolean(YK_ID && YK_KEY);

await mkdir(FILES, { recursive: true, mode: 0o700 });
// Первый запуск: товары по умолчанию из репозитория. Дальше файл правит администратор.
try { await stat(PRODUCTS); } catch { try { await copyFile(DEFAULTS, PRODUCTS); } catch (e) { console.error('shop: нет товаров по умолчанию', e.message); } }

// Не больше 10 заказов за 10 минут с одного IP (свой счётчик — не мешает заявкам на консультацию).
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 600e3);
  list.push(now);
  hits.set(ip, list);
  if (hits.size > 5000) for (const [k, v] of hits) if (now - v[v.length - 1] > 600e3) hits.delete(k);
  return list.length > 10;
}
const sha = (s) => createHash('sha256').update(s).digest('hex');
const clean = (v, max) => String(v ?? '').replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, max);
let queue = Promise.resolve();
const serial = (fn) => (queue = queue.then(fn, fn));

async function products() {
  const p = JSON.parse(await readFile(PRODUCTS, 'utf8'));
  return (p.products || []).filter((x) => x && x.id && x.active !== false && Number(x.price) > 0);
}
export async function filesOf(id) {
  if (!/^[a-z0-9-]+$/.test(id)) return [];
  try { return (await readdir(join(FILES, id))).filter((f) => !f.startsWith('.')).sort(); } catch { return []; }
}
const text = (p, lang) => Object.assign({}, p.t?.ru, p.t?.[lang]);

export async function readOrders() { try { return JSON.parse(await readFile(ORDERS, 'utf8')); } catch (e) { if (e.code === 'ENOENT') return []; throw e; } }
async function writeOrders(list) { const tmp = ORDERS + '.tmp'; await writeFile(tmp, JSON.stringify(list, null, 1), { mode: 0o600 }); await rename(tmp, ORDERS); }
export async function updateOrder(match, fn) {
  return serial(async () => {
    const list = await readOrders();
    const o = list.find(match);
    if (!o) return null;
    fn(o);
    await writeOrders(list);
    return o;
  });
}

async function yk(path, opts = {}) {
  const r = await fetch(YK_API + path, {
    ...opts,
    headers: { Authorization: 'Basic ' + Buffer.from(`${YK_ID}:${YK_KEY}`).toString('base64'), 'Content-Type': 'application/json', ...(opts.headers || {}) },
    signal: AbortSignal.timeout(15000)
  });
  const body = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`ЮKassa ${r.status} ${body.description || ''}`.trim());
  return body;
}

// Статус платежа берётся только из API ЮKassa (уведомления не подписаны — им не верим на слово).
async function syncPayment(o) {
  if (!o.paymentId || o.status === 'paid' || !payEnabled()) return o;
  const p = await yk(`/payments/${encodeURIComponent(o.paymentId)}`);
  const amountOk = p.amount && Number(p.amount.value) === o.price && p.amount.currency === 'RUB' && p.metadata?.order === String(o.id);
  if (p.status === 'succeeded' && amountOk) {
    return (await updateOrder((x) => x.id === o.id, (x) => { if (x.status !== 'paid') { x.status = 'paid'; x.paidAt = new Date().toISOString(); } })) || o;
  }
  if (p.status === 'canceled') return (await updateOrder((x) => x.id === o.id, (x) => { x.status = 'canceled'; x.cancelReason = p.cancellation_details?.reason || ''; })) || o;
  return o;
}

export async function handleShopGet(req, res, url, send) {
  if (url.pathname === '/api/shop/products') {
    const lang = LANGS.includes(url.searchParams.get('lang')) ? url.searchParams.get('lang') : 'ru';
    const list = await products();
    const out = await Promise.all(list.map(async (p) => ({ id: p.id, price: Number(p.price), ready: (await filesOf(p.id)).length > 0, ...text(p, lang) })));
    return send(res, 200, { pay: payEnabled(), products: out });
  }
  const token = clean(url.searchParams.get('t'), 100);
  if (!/^[a-f0-9]{48}$/.test(token)) return send(res, 404, { error: 'not found' });
  let o = (await readOrders()).find((x) => x.tokenHash === sha(token));
  if (!o) return send(res, 404, { error: 'not found' });
  if (url.pathname === '/api/shop/status') {
    try { o = await syncPayment(o); } catch (e) { console.error('shop sync', e.message); }
    const expired = o.status === 'paid' && Date.now() - Date.parse(o.paidAt) > ACCESS_DAYS * 864e5;
    const out = { id: o.id, status: expired ? 'expired' : o.status, product: o.product, title: o.title, price: o.price };
    if (o.status === 'paid' && !expired) {
      out.files = await filesOf(o.product);
      out.until = new Date(Date.parse(o.paidAt) + ACCESS_DAYS * 864e5).toISOString();
    }
    return send(res, 200, out);
  }
  if (url.pathname === '/api/shop/file') {
    if (o.status !== 'paid') return send(res, 403, { error: 'not paid' });
    if (Date.now() - Date.parse(o.paidAt) > ACCESS_DAYS * 864e5) return send(res, 403, { error: 'expired' });
    if ((o.downloads || 0) >= MAX_DOWNLOADS) return send(res, 429, { error: 'limit' });
    const f = basename(clean(url.searchParams.get('f'), 200));
    const files = await filesOf(o.product);
    if (!files.includes(f)) return send(res, 404, { error: 'no file' });
    await updateOrder((x) => x.id === o.id, (x) => { x.downloads = (x.downloads || 0) + 1; });
    const path = join(FILES, o.product, f);
    const st = await stat(path);
    res.writeHead(200, {
      'Content-Type': f.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'application/octet-stream',
      'Content-Length': st.size,
      'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(f)}`,
      'Cache-Control': 'private, no-store',
      'X-Robots-Tag': 'noindex'
    });
    return createReadStream(path).pipe(res);
  }
  return send(res, 404, { error: 'not found' });
}

// Заказ. Данные: e-mail (для чека и связи по заказу), выбранная инструкция, факт согласия и принятия оферты.
export async function handleShopOrder(req, res, body, ip, send, { consentMeta }) {
  if (clean(body.website, 200)) return send(res, 200, { ok: true });
  if (limited(ip)) return send(res, 429, { error: 'too many' });
  const lang = LANGS.includes(body.lang) ? body.lang : 'ru';
  const email = clean(body.email, 120).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return send(res, 422, { error: 'email' });
  if (body.consent !== true && body.consent !== 'yes') return send(res, 422, { error: 'consent' });
  if (body.offer !== true && body.offer !== 'yes') return send(res, 422, { error: 'offer' });
  if (!consentMeta.version || clean(body.consent_version, 20) !== consentMeta.version) return send(res, 409, { error: 'consent version' });
  const p = (await products()).find((x) => x.id === body.product);
  if (!p) return send(res, 404, { error: 'product' });
  if (!(await filesOf(p.id)).length) return send(res, 409, { error: 'not ready' });
  if (!payEnabled()) return send(res, 503, { error: 'pay off' });
  const token = randomBytes(24).toString('hex');
  const now = new Date().toISOString();
  const price = Number(p.price);
  const title = text(p, 'ru').title;
  const order = await serial(async () => {
    const list = await readOrders();
    const o = {
      id: list.reduce((m, x) => Math.max(m, x.id || 0), 0) + 1, at: now, status: 'new', product: p.id, title, price, email, lang,
      tokenHash: sha(token),
      consent: { given: true, offer: true, at: now, version: consentMeta.version, sha256: consentMeta.sha256, ip, userAgent: clean(req.headers['user-agent'], 300) }
    };
    list.push(o);
    await writeOrders(list);
    return o;
  });
  try {
    const pay = await yk('/payments', {
      method: 'POST',
      headers: { 'Idempotence-Key': randomUUID() },
      body: JSON.stringify({
        amount: { value: price.toFixed(2), currency: 'RUB' },
        capture: true,
        confirmation: { type: 'redirect', return_url: `${SITE}/self/order/?t=${token}&l=${lang}` },
        description: `Заказ №${order.id}: инструкция «${title}»`.slice(0, 128),
        metadata: { order: String(order.id) },
        receipt: {
          customer: { email },
          items: [{ description: `Инструкция «${title}» (электронные материалы)`.slice(0, 128), quantity: '1.00', amount: { value: price.toFixed(2), currency: 'RUB' }, vat_code: VAT, payment_subject: 'service', payment_mode: 'full_payment' }]
        }
      })
    });
    await updateOrder((x) => x.id === order.id, (x) => { x.paymentId = pay.id; x.status = 'pending'; });
    console.log(`shop order #${order.id} ${p.id} ${price}`);
    return send(res, 200, { ok: true, id: order.id, url: pay.confirmation?.confirmation_url, token });
  } catch (e) {
    console.error('shop pay', e.message);
    await updateOrder((x) => x.id === order.id, (x) => { x.status = 'error'; });
    return send(res, 502, { error: 'pay' });
  }
}

export async function handleShopWebhook(req, res, body, ip, send, { notify }) {
  const id = clean(body?.object?.id, 80);
  if (!id) return send(res, 400, { error: 'bad' });
  const o = (await readOrders()).find((x) => x.paymentId === id);
  if (!o) return send(res, 200, { ok: true }); // чужой или старый платёж — ЮKassa ждёт 200
  try {
    const was = o.status;
    const n = await syncPayment(o);
    if (was !== 'paid' && n.status === 'paid') notify(`Оплачен заказ №${n.id}: инструкция «${n.title}», ${n.price} ₽.`);
  } catch (e) { console.error('shop webhook', e.message); return send(res, 500, { error: 'sync' }); }
  return send(res, 200, { ok: true });
}
