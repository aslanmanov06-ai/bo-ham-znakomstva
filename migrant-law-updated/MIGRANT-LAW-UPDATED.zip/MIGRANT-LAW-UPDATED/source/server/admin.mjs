// Админ-панель сайта sverify.online: сервер API (/api/admin/*). Страница панели — /admin/ (собирается вместе с сайтом).
// Владелец меняет тексты на всех языках, добавляет свои блоки, меняет порядок секций, загружает файлы и картинки,
// правит прайс, реквизиты и инструкции, видит заявки и заказы — и публикует сайт одной кнопкой.
// Правки хранятся отдельно от исходников (CONTENT_DIR, см. scripts/content.mjs); публикация = сборка сайта с ними
// и выкладка в WWW_DIR с резервной копией предыдущей версии (можно откатить).
//
// Пользователи с ролями (users.json), вход по логину и паролю, по желанию — код 2FA (TOTP); журнал действий (audit.jsonl).
// Права проверяются здесь, на сервере (функция permFor): интерфейс лишь прячет недоступные разделы.
//
// Безопасность: пароли — scrypt (владелец: scripts/admin-passwd.mjs), сессия в cookie HttpOnly+Secure+SameSite=Strict,
// изменяющие запросы — только с заголовком X-Admin и своего сайта (Origin), ограничение попыток входа.
// Данные заявок и инструкций — только через внутренний API сервера заявок (server/internal.mjs).
//
// Окружение: ADMIN_PORT (3120), ADMIN_HOME (/var/lib/sverify-admin), SITE_DIR, CONTENT_DIR, RELEASES_DIR, AUTH_FILE,
//            WWW_DIR (/var/www/sverify.online), SITE_URL, INTERNAL_URL, INTERNAL_TOKEN, COOKIE_SECURE (0 — только для проверки).
import { createServer } from 'node:http';
import { readFile, writeFile, rename, mkdir, readdir, stat, unlink, rm, appendFile, statfs } from 'node:fs/promises';
import { createReadStream, createWriteStream } from 'node:fs';
import { join, extname, basename, normalize, dirname } from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { randomBytes, scrypt as scryptCb, timingSafeEqual, createHash, createHmac } from 'node:crypto';
import { promisify } from 'node:util';

const scrypt = promisify(scryptCb);
const PORT = Number(process.env.ADMIN_PORT || 3120);
const HOME = process.env.ADMIN_HOME || '/var/lib/sverify-admin';
const SITE_DIR = process.env.SITE_DIR || join(HOME, 'site');
const CONTENT = process.env.CONTENT_DIR || join(HOME, 'content');
const RELEASES = process.env.RELEASES_DIR || join(HOME, 'releases');
const AUTH_FILE = process.env.AUTH_FILE || join(HOME, 'auth.json');
const WWW = process.env.WWW_DIR || '/var/www/sverify.online';
const SITE_URL = process.env.SITE_URL || 'https://sverify.online';
const INTERNAL = process.env.INTERNAL_URL || 'http://127.0.0.1:3111';
const ITOKEN = process.env.INTERNAL_TOKEN || '';
const SECURE = process.env.COOKIE_SECURE !== '0';
const COOKIE = SECURE ? '__Host-sva' : 'sva';
const SESSION_H = 12;
const MAX_UPLOAD = 60 * 1024 * 1024;
const KEEP_RELEASES = 5;
const KEEP_SNAPSHOTS = 30;
const AUDIT_KEEP = 20000;
const USERS_FILE = join(dirname(AUTH_FILE), 'users.json');
const AUDIT_FILE = join(HOME, 'audit.jsonl');
const SNAPSHOTS = join(HOME, 'snapshots');
const PREVIEW_DIR = join(HOME, 'preview');
const PREVIEW_PREFIX = '/api/admin/preview';
const ALL = '*';
const ROLES = {
  superadmin: { label: 'Суперадмин', perms: [ALL] },
  admin: { label: 'Администратор', perms: ['content', 'design', 'files', 'prices', 'shop', 'legal', 'publish', 'leads', 'pd', 'orders', 'audit'] },
  editor: { label: 'Редактор сайта', perms: ['content', 'files', 'prices', 'shop', 'publish'] },
  manager: { label: 'Менеджер заявок', perms: ['leads', 'orders'] }
};

const C = await import(join(SITE_DIR, 'scripts/content.mjs'));
await mkdir(join(CONTENT, 'files'), { recursive: true });
await mkdir(RELEASES, { recursive: true });
await mkdir(SNAPSHOTS, { recursive: true });

/* ---------- утилиты ---------- */
const send = (res, status, obj, headers = {}) => {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Robots-Tag': 'noindex', ...headers });
  res.end(obj === undefined ? '' : JSON.stringify(obj));
};
const readJson = async (f, d) => { try { return JSON.parse(await readFile(f, 'utf8')); } catch (e) { if (e.code === 'ENOENT') return d; throw e; } };
async function saveJson(f, obj, mode = 0o644) { const tmp = `${f}.${randomBytes(4).toString('hex')}.tmp`; await writeFile(tmp, JSON.stringify(obj, null, 1) + '\n', { mode }); await rename(tmp, f); }
async function body(req, max = 2 * 1024 * 1024) {
  const parts = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > max) throw Object.assign(new Error('too big'), { status: 413 }); parts.push(c); }
  const raw = Buffer.concat(parts).toString('utf8');
  try { return JSON.parse(raw || '{}'); } catch { throw Object.assign(new Error('не JSON'), { status: 400 }); }
}
const fail = (status, msg) => Object.assign(new Error(msg), { status });
const ipOf = (req) => String(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
const cleanName = (name) => {
  const n = basename(String(name || '')).replace(/[\u0000-\u001F\u007F"\\/:*?<>|#%&]/g, '').replace(/\s+/g, '-').trim().slice(0, 120);
  return n && !n.startsWith('.') ? n : '';
};
async function internal(path, opts = {}) {
  if (!ITOKEN) throw fail(503, 'нет связи с сервером заявок (INTERNAL_TOKEN)');
  const r = await fetch(INTERNAL + path, { ...opts, headers: { 'X-Internal-Token': ITOKEN, ...(opts.headers || {}) }, duplex: opts.body ? 'half' : undefined, signal: AbortSignal.timeout(120000) });
  const b = await r.json().catch(() => ({}));
  if (!r.ok) throw fail(r.status, b.error || `сервер заявок: ${r.status}`);
  return b;
}

/* ---------- пользователи и вход ---------- */
const SCRYPT = { N: 32768, r: 8, p: 1 };
async function hashPassword(pw) {
  const salt = randomBytes(16);
  const h = await scrypt(pw, salt, 32, { ...SCRYPT, maxmem: 128 * 1024 * 1024 });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${h.toString('base64')}`;
}
const DUMMY_HASH = await hashPassword(randomBytes(16).toString('hex')); // неизвестный логин проверяется столько же, сколько известный
async function verifyHash(stored, pw) {
  const [alg, N, r, p, salt, hash] = stored.split('$');
  if (alg !== 'scrypt') return false;
  const want = Buffer.from(hash, 'base64');
  const got = await scrypt(String(pw), Buffer.from(salt, 'base64'), want.length, { N: Number(N), r: Number(r), p: Number(p), maxmem: 128 * 1024 * 1024 });
  return got.length === want.length && timingSafeEqual(got, want);
}
// Первый запуск с пользователями: прежний единственный пароль становится учётной записью суперадмина admin.
let users = (await readJson(USERS_FILE, null))?.users;
if (!users) {
  const old = await readJson(AUTH_FILE, null);
  users = old?.hash ? [{ id: 'u1', login: 'admin', name: 'Владелец', role: 'superadmin', hash: old.hash, createdAt: new Date().toISOString() }] : [];
  if (users.length) await saveJson(USERS_FILE, { users }, 0o600);
}
const saveUsers = () => saveJson(USERS_FILE, { users }, 0o600);
const permsOf = (u) => ROLES[u.role]?.perms || [];
const can = (u, perm) => perm === null || permsOf(u).includes(ALL) || permsOf(u).includes(perm);
const activeSupers = () => users.filter((u) => u.role === 'superadmin' && !u.disabled);
// Владелец — единственный, кто управляет суперадминами и администраторами; его собственный доступ изменить нельзя.
const PRIVILEGED = new Set(['superadmin', 'admin']);
const canManage = (actor, target) => !!actor.owner || !PRIVILEGED.has(target.role);
const ONLY_OWNER = 'Суперадминов и администраторов может менять только владелец';
if (users.length && !users.some((u) => u.owner)) {
  const first = users.find((u) => u.id === 'u1' && u.role === 'superadmin') || users.find((u) => u.role === 'superadmin');
  if (first) { first.owner = true; await saveUsers(); }
}
const publicUser = (u) => ({ id: u.id, login: u.login, name: u.name, role: u.role, owner: !!u.owner, disabled: !!u.disabled, totp: !!u.totp, createdAt: u.createdAt, lastLogin: u.lastLogin || null });
const validLogin = (s) => typeof s === 'string' && /^[a-z0-9._-]{3,32}$/.test(s);
function checkNewPassword(pw) { if (typeof pw !== 'string' || pw.length < 12 || pw.length > 200) throw fail(422, 'Пароль — от 12 до 200 символов'); }

/* 2FA: TOTP (RFC 6238), код из приложения вроде Google Authenticator. */
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32encode(buf) {
  let bits = '', out = '';
  for (const b of buf) bits += b.toString(2).padStart(8, '0');
  for (let i = 0; i + 5 <= bits.length; i += 5) out += B32[parseInt(bits.slice(i, i + 5), 2)];
  return out;
}
function b32decode(s) {
  let bits = '';
  for (const c of s) bits += B32.indexOf(c).toString(2).padStart(5, '0');
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(bytes);
}
function totpAt(secret, step) {
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(step));
  const mac = createHmac('sha1', b32decode(secret)).update(msg).digest();
  const o = mac[19] & 15;
  return String((mac.readUInt32BE(o) & 0x7fffffff) % 1000000).padStart(6, '0');
}
// Возвращает шаг времени подошедшего кода или 0; шаг не больше lastStep отклоняется — код нельзя использовать повторно.
function checkTotp(secret, code, lastStep = 0) {
  if (typeof code !== 'string' || !/^\d{6}$/.test(code)) return 0;
  const step = Math.floor(Date.now() / 30000);
  for (const w of [-1, 0, 1]) if (step + w > lastStep && timingSafeEqual(Buffer.from(totpAt(secret, step + w)), Buffer.from(code))) return step + w;
  return 0;
}

// Сессии переживают перезапуск сервиса; на диске только хэши токенов (права 600).
const SESSIONS_FILE = join(HOME, 'sessions.json');
const tokenHash = (t) => createHash('sha256').update(t).digest('hex');
const sessions = new Map(Object.entries(await readJson(SESSIONS_FILE, {}))); // хэш токена → { exp, uid, ip, ua, at }
const saveSessions = () => saveJson(SESSIONS_FILE, Object.fromEntries(sessions), 0o600);
const tries = new Map(); // ip → [время]
let globalTries = [];
const sessionKey = (key) => key.slice(0, 16);
function cookieOf(req) {
  const m = String(req.headers.cookie || '').split(/;\s*/).find((c) => c.startsWith(COOKIE + '='));
  return m ? m.slice(COOKIE.length + 1) : '';
}
function session(req) {
  const raw = cookieOf(req);
  const t = raw && tokenHash(raw);
  const s = t && sessions.get(t);
  if (!s) return null;
  if (s.exp < Date.now()) { sessions.delete(t); return null; }
  const user = users.find((u) => u.id === s.uid && !u.disabled);
  return user ? { token: t, user } : null;
}
function dropSessions(uid, except) { for (const [t, s] of sessions) if (s.uid === uid && t !== except) sessions.delete(t); saveSessions().catch((e) => console.error('sessions', e.message)); }
const setCookie = (val, maxAge) => `${COOKIE}=${val}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${SECURE ? '; Secure' : ''}`;

/* журнал: без персональных данных клиентов — только кто, откуда и какое действие */
async function audit(req, user, action) {
  await appendFile(AUDIT_FILE, JSON.stringify({ at: new Date().toISOString(), user: user || '—', ip: ipOf(req), action }) + '\n', { mode: 0o600 });
}
async function trimAudit() {
  const lines = (await readFile(AUDIT_FILE, 'utf8').catch(() => '')).split('\n').filter(Boolean);
  if (lines.length > AUDIT_KEEP) await writeFile(AUDIT_FILE, lines.slice(-AUDIT_KEEP).join('\n') + '\n', { mode: 0o600 });
}
await trimAudit();

async function login(req, res) {
  const ip = ipOf(req);
  const now = Date.now();
  const mine = (tries.get(ip) || []).filter((t) => now - t < 15 * 60e3);
  globalTries = globalTries.filter((t) => now - t < 15 * 60e3);
  if (mine.length >= 8 || globalTries.length >= 40) return send(res, 429, { error: 'Слишком много попыток. Подождите 15 минут.' });
  const b = await body(req, 4096);
  const name = typeof b.login === 'string' && b.login.trim() ? b.login.trim().toLowerCase().slice(0, 40) : ''; // без логина вход невозможен: пустое имя не совпадёт ни с кем
  const user = users.find((u) => u.login === name && !u.disabled);
  const passOk = typeof b.password === 'string' && b.password.length <= 200 && (await verifyHash(user?.hash || DUMMY_HASH, b.password)) && !!user;
  const reject = async (msg, extra) => {
    mine.push(now); tries.set(ip, mine); globalTries.push(now);
    await new Promise((r) => setTimeout(r, 600));
    await audit(req, name, 'неудачный вход');
    return send(res, 401, { error: msg, ...extra });
  };
  if (!passOk) return reject('Неверный логин или пароль');
  if (user.totp && !b.code) return send(res, 401, { error: 'Введите код из приложения', need2fa: true });
  if (user.totp) {
    const step = checkTotp(user.totp, b.code, user.totpStep || 0);
    if (!step) return reject('Неверный код', { need2fa: true });
    user.totpStep = step;
  }
  tries.delete(ip);
  const token = randomBytes(32).toString('hex');
  sessions.set(tokenHash(token), { exp: now + SESSION_H * 3600e3, uid: user.id, ip, ua: String(req.headers['user-agent'] || '').slice(0, 160), at: now });
  await saveSessions();
  user.lastLogin = new Date().toISOString();
  await saveUsers();
  await audit(req, user.login, 'вход');
  return send(res, 200, { ok: true }, { 'Set-Cookie': setCookie(token, SESSION_H * 3600) });
}

async function profile(req, res, p, sess) {
  const u = sess.user;
  if (p === '/me/password' && req.method === 'POST') {
    const b = await body(req, 4096);
    if (!(await verifyHash(u.hash, String(b.current || '')))) throw fail(422, 'Текущий пароль неверный');
    checkNewPassword(b.password);
    u.hash = await hashPassword(b.password);
    dropSessions(u.id, sess.token);
    await saveUsers();
    return send(res, 200, { ok: true });
  }
  if (p === '/me/totp/setup' && req.method === 'POST') {
    u.totpPending = b32encode(randomBytes(20));
    await saveUsers();
    return send(res, 200, { secret: u.totpPending, uri: `otpauth://totp/${encodeURIComponent('Migrant-law:' + u.login)}?secret=${u.totpPending}&issuer=Migrant-law` });
  }
  if (p === '/me/totp/enable' && req.method === 'POST') {
    const b = await body(req, 4096);
    if (!u.totpPending || !checkTotp(u.totpPending, b.code)) throw fail(422, 'Код не подошёл — проверьте время на телефоне');
    u.totp = u.totpPending; delete u.totpPending;
    await saveUsers();
    return send(res, 200, { ok: true });
  }
  if (p === '/me/totp/disable' && req.method === 'POST') {
    const b = await body(req, 4096);
    if (!(await verifyHash(u.hash, String(b.current || '')))) throw fail(422, 'Текущий пароль неверный');
    delete u.totp; delete u.totpPending;
    await saveUsers();
    return send(res, 200, { ok: true });
  }
  throw fail(404, 'нет такого действия');
}

async function usersApi(req, res, p, sess) {
  if (p === '/users' && req.method === 'GET') return send(res, 200, { users: users.map(publicUser), roles: Object.fromEntries(Object.entries(ROLES).map(([k, v]) => [k, v.label])) });
  if (p === '/users' && req.method === 'POST') {
    const b = await body(req, 4096);
    if (!validLogin(b.login)) throw fail(422, 'Логин: 3–32 символа, латиница, цифры, . _ -');
    if (users.some((u) => u.login === b.login)) throw fail(409, 'Такой логин уже есть');
    if (!ROLES[b.role]) throw fail(422, 'роль');
    if (PRIVILEGED.has(b.role) && !sess.user.owner) throw fail(403, ONLY_OWNER);
    checkNewPassword(b.password);
    const u = { id: 'u' + randomBytes(6).toString('hex'), login: b.login, name: String(b.name || b.login).trim().slice(0, 80), role: b.role, hash: await hashPassword(b.password), createdAt: new Date().toISOString() };
    users.push(u);
    await saveUsers();
    return send(res, 200, publicUser(u));
  }
  const m = p.match(/^\/users\/(u[a-z0-9]+)$/);
  if (!m) throw fail(404, 'нет такого действия');
  const u = users.find((x) => x.id === m[1]);
  if (!u) throw fail(404, 'нет пользователя');
  if (!canManage(sess.user, u)) throw fail(403, ONLY_OWNER);
  const losesSuper = (nextRole, nextDisabled) => u.role === 'superadmin' && !u.disabled && (nextRole !== 'superadmin' || nextDisabled) && activeSupers().length === 1;
  if (req.method === 'DELETE') {
    if (u.id === sess.user.id) throw fail(422, 'Нельзя удалить самого себя');
    if (losesSuper(null, true)) throw fail(422, 'Нельзя удалить последнего суперадмина');
    users = users.filter((x) => x !== u);
    dropSessions(u.id);
    await saveUsers();
    return send(res, 200, { ok: true });
  }
  if (req.method === 'PUT') {
    const b = await body(req, 4096);
    const role = b.role ?? u.role, disabled = b.disabled ?? !!u.disabled;
    if (!ROLES[role] || typeof disabled !== 'boolean') throw fail(422, 'роль');
    if (PRIVILEGED.has(role) && !sess.user.owner) throw fail(403, ONLY_OWNER);
    if (u.owner && (role !== 'superadmin' || disabled)) throw fail(422, 'Доступ владельца нельзя понизить или отключить');
    if (losesSuper(role, disabled)) throw fail(422, 'Должен остаться хотя бы один активный суперадмин');
    if (b.password) { checkNewPassword(b.password); u.hash = await hashPassword(b.password); }
    if (b.resetTotp) { delete u.totp; delete u.totpPending; }
    if (typeof b.name === 'string') u.name = b.name.trim().slice(0, 80);
    const revoke = role !== u.role || disabled || b.password || b.resetTotp;
    u.role = role; u.disabled = disabled;
    if (revoke) dropSessions(u.id, u.id === sess.user.id ? sess.token : undefined);
    await saveUsers();
    return send(res, 200, publicUser(u));
  }
  throw fail(405, 'метод');
}
async function sessionsApi(req, res, p, sess) {
  const visible = (uid) => { const u = users.find((x) => x.id === uid); return uid === sess.user.id || !u || canManage(sess.user, u); };
  if (req.method === 'GET') {
    const list = [...sessions].filter(([, s]) => s.exp > Date.now() && visible(s.uid)).map(([t, s]) => ({ id: sessionKey(t), login: users.find((u) => u.id === s.uid)?.login || '?', ip: s.ip, ua: s.ua, at: s.at }));
    return send(res, 200, list);
  }
  const m = p.match(/^\/sessions\/([0-9a-f]{16})$/);
  if (m && req.method === 'DELETE') {
    for (const [t, s] of sessions) if (sessionKey(t) === m[1]) { if (!visible(s.uid)) throw fail(403, ONLY_OWNER); sessions.delete(t); }
    await saveSessions();
    return send(res, 200, { ok: true });
  }
  throw fail(404, 'нет такого действия');
}

/* ---------- данные панели ---------- */
const defaultsI18n = async () => JSON.parse(await readFile(join(SITE_DIR, 'src/i18n.json'), 'utf8'));
const P = (f) => join(CONTENT, f);

async function texts(req, res, url) {
  const L = await defaultsI18n();
  const patches = await readJson(P('texts.json'), {});
  if (req.method === 'GET') {
    const lang = C.LANGS.includes(url.searchParams.get('lang')) ? url.searchParams.get('lang') : 'ru';
    return send(res, 200, { def: L[lang], patch: patches[lang] || {} });
  }
  const b = await body(req);
  if (!C.LANGS.includes(b.lang) || typeof b.path !== 'string' || !/^[A-Za-z0-9_.]+$/.test(b.path)) throw fail(422, 'язык или поле');
  const def = C.getAt(L[b.lang], b.path);
  if (def === undefined || C.LOCKED.has(b.path)) throw fail(422, 'такого поля нет');
  patches[b.lang] = patches[b.lang] || {};
  if (b.reset) delete patches[b.lang][b.path];
  else {
    if (!C.sameShape(def, b.value)) throw fail(422, 'неверный формат значения');
    if (JSON.stringify(b.value).length > 200000) throw fail(413, 'слишком длинный текст');
    patches[b.lang][b.path] = b.value;
  }
  await saveJson(P('texts.json'), patches);
  return send(res, 200, { ok: true });
}

async function blocks(req, res) {
  const list = await readJson(P('blocks.json'), []);
  const layout = await readJson(P('layout.json'), null);
  if (req.method === 'GET') return send(res, 200, { blocks: list, layout: { order: C.sectionOrder({ order: layout?.order || [] }, list), hidden: layout?.hidden || [] }, sections: C.SECTIONS });
  const b = await body(req);
  if (b.blocks !== undefined) {
    if (!Array.isArray(b.blocks) || b.blocks.length > 40) throw fail(422, 'не больше 40 блоков');
    const bad = b.blocks.find((x) => !C.validBlock(x));
    if (bad) throw fail(422, `блок «${bad?.title?.ru || bad?.id}»: проверьте заголовок (на русском обязателен), ссылки кнопок (https://, /, #, tel:, mailto:) и файлы`);
    if (new Set(b.blocks.map((x) => x.id)).size !== b.blocks.length) throw fail(422, 'повтор id блока');
  }
  if (b.layout !== undefined) { // проверяется до записи: блоки и порядок сохраняются только вместе
    const ids = new Set([...C.SECTIONS, ...(b.blocks || list).map((x) => x.id)]);
    const { order, hidden } = b.layout || {};
    if (!Array.isArray(order) || !Array.isArray(hidden) || ![...order, ...hidden].every((x) => ids.has(x))) throw fail(422, 'неверный порядок секций');
  }
  if (b.blocks !== undefined) await saveJson(P('blocks.json'), b.blocks);
  if (b.layout !== undefined) await saveJson(P('layout.json'), { order: b.layout.order, hidden: b.layout.hidden });
  return send(res, 200, { ok: true });
}

async function files(req, res, url) {
  const dir = P('files');
  const m = url.pathname.match(/^\/api\/admin\/files\/(raw\/)?([^/]+)$/);
  if (req.method === 'GET' && !m) {
    const names = (await readdir(dir)).filter((f) => !f.startsWith('.'));
    const sources = await contentSources();
    const list = await Promise.all(names.map(async (n) => { const st = await stat(join(dir, n)); return { name: n, size: st.size, mtime: st.mtimeMs, url: `/files/${n}`, used: usedIn(sources, n) }; }));
    return send(res, 200, list.sort((a, b) => b.mtime - a.mtime));
  }
  if (!m) throw fail(404, 'нет');
  const name = cleanName(decodeURIComponent(m[2]));
  const ext = extname(name).slice(1).toLowerCase();
  if (!name || !C.FILE_EXT.includes(ext)) throw fail(422, `имя или тип файла (можно: ${C.FILE_EXT.join(', ')})`);
  const path = join(dir, name);
  if (req.method === 'GET' && m[1]) { // предпросмотр в панели (до публикации)
    const st = await stat(path).catch(() => null);
    if (!st) throw fail(404, 'нет файла');
    const types = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', pdf: 'application/pdf' };
    res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-store', 'Content-Disposition': types[ext] ? 'inline' : 'attachment', 'X-Content-Type-Options': 'nosniff' });
    return createReadStream(path).pipe(res);
  }
  if (req.method === 'DELETE') {
    const where = usedIn(await contentSources(), name);
    if (where.length && url.searchParams.get('force') !== '1') return send(res, 409, { error: `Файл используется: ${where.join(', ')}`, where });
    await unlink(path).catch((e) => { if (e.code !== 'ENOENT') throw e; });
    return send(res, 200, { ok: true });
  }
  if (req.method === 'PUT') {
    await upload(req, path);
    return send(res, 200, { ok: true, name, url: `/files/${name}` });
  }
  throw fail(405, 'метод');
}
// Где в содержимом сайта встречается загруженный файл (чтобы не удалить используемый).
const USAGE_FILES = [['блоки главной', 'blocks.json'], ['страницы', 'pages.json'], ['дизайн и контакты', 'settings.json'], ['тексты', 'texts.json']];
const contentSources = () => Promise.all(USAGE_FILES.map(async ([label, f]) => [label, JSON.stringify(await readJson(P(f), null))]));
const usedIn = (sources, name) => sources.filter(([, text]) => text && text.includes(`/files/${name}`)).map(([label]) => label);

async function upload(req, path) {
  if (Number(req.headers['content-length'] || 0) > MAX_UPLOAD) throw fail(413, 'файл больше 60 МБ');
  const tmp = `${path}.${randomBytes(4).toString('hex')}.up`;
  let size = 0;
  await new Promise((resolve, reject) => {
    const out = createWriteStream(tmp, { mode: 0o644 });
    req.on('data', (c) => { size += c.length; if (size > MAX_UPLOAD) { req.destroy(); out.destroy(); reject(fail(413, 'файл больше 60 МБ')); } });
    req.pipe(out); out.on('finish', resolve); out.on('error', reject); req.on('error', reject);
  }).catch(async (e) => { await unlink(tmp).catch(() => {}); throw e; });
  if (!size) { await unlink(tmp).catch(() => {}); throw fail(422, 'пустой файл'); }
  await rename(tmp, path);
}

async function prices(req, res) {
  if (req.method === 'GET') return send(res, 200, await readJson(P('prices.json'), null) || JSON.parse(await readFile(join(SITE_DIR, 'src/prices.json'), 'utf8')));
  const doc = await body(req);
  const ok = doc && Array.isArray(doc.blocks) && doc.blocks.length <= 40 && doc.blocks.every((b) => typeof b.title === 'string' && b.title.trim() && b.title.length <= 200 && Array.isArray(b.items) && b.items.length <= 100
    && b.items.every((it) => Array.isArray(it) && it.length === 3 && typeof it[1] === 'string' && it[1].trim() && it[1].length <= 300 && Number.isInteger(it[2]) && it[2] >= 0 && it[2] <= 100000000));
  if (!ok) throw fail(422, 'прайс: у каждого раздела — название, у каждой услуги — название и цена (целое число рублей)');
  let n = 0;
  for (const b of doc.blocks) for (const it of b.items) it[0] = ++n; // сквозная нумерация
  await saveJson(P('prices.json'), { _source: doc._source || 'админ-панель', blocks: doc.blocks });
  return send(res, 200, { ok: true });
}

const LEGAL_KEYS = ['operatorFullName', 'operatorShortName', 'operatorKind', 'inn', 'ogrn', 'ogrnLabel', 'registrationInfo', 'address', 'postAddress', 'email', 'phone', 'responsiblePerson', 'rknRegistryNumber', 'hostingProvider', 'hostingAddress', 'dataLocation', 'retentionDays', 'docsDate', 'consentVersion', 'privacyVersion'];
async function legal(req, res) {
  const def = JSON.parse(await readFile(join(SITE_DIR, 'src/legal.json'), 'utf8'));
  const cur = await readJson(P('legal.json'), {});
  if (req.method === 'GET') return send(res, 200, Object.fromEntries(LEGAL_KEYS.map((k) => [k, k in cur ? cur[k] : def[k]])));
  const b = await body(req);
  const out = {};
  for (const k of LEGAL_KEYS) {
    if (!(k in b)) continue;
    if (k === 'retentionDays') { if (!Number.isInteger(b[k]) || b[k] < 1 || b[k] > 3650) throw fail(422, 'срок хранения — дни'); }
    else if (typeof b[k] !== 'string' || b[k].length > 500) throw fail(422, `поле ${k}`);
    if (b[k] !== def[k]) out[k] = b[k];
  }
  await saveJson(P('legal.json'), out);
  return send(res, 200, { ok: true });
}

async function pages(req, res) {
  if (req.method === 'GET') return send(res, 200, await readJson(P('pages.json'), []));
  const list = await body(req);
  if (!Array.isArray(list) || list.length > 50) throw fail(422, 'не больше 50 страниц');
  const bad = list.find((x) => !C.validPage(x));
  if (bad) throw fail(422, `страница «${bad?.title?.ru || bad?.slug}»: проверьте заголовок, адрес (латиница, цифры, дефис; занятые: ${[...C.RESERVED_SLUGS].join(', ')}), ссылки и файлы блоков`);
  if (new Set(list.map((x) => x.slug)).size !== list.length || new Set(list.map((x) => x.id)).size !== list.length) throw fail(422, 'адрес страницы повторяется');
  await saveJson(P('pages.json'), list);
  return send(res, 200, { ok: true });
}
async function settings(req, res) {
  if (req.method === 'GET') return send(res, 200, { settings: { ...C.DEFAULT_SETTINGS, ...(await readJson(P('settings.json'), {})) }, defaultTheme: C.DEFAULT_THEME });
  const s = await body(req);
  const e = C.settingsError(s);
  if (e) throw fail(422, e);
  await saveJson(P('settings.json'), s);
  return send(res, 200, { ok: true });
}

/* ---------- версии контента ---------- */
const SNAP_FILES = ['texts.json', 'blocks.json', 'layout.json', 'legal.json', 'prices.json', 'pages.json', 'settings.json'];
const snapName = (id) => join(SNAPSHOTS, `${id}.json`);
async function makeSnapshot(by, reason) {
  const data = {};
  for (const f of SNAP_FILES) data[f] = await readJson(P(f), null);
  const id = new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 17) + randomBytes(2).toString('hex');
  await saveJson(snapName(id), { at: new Date().toISOString(), by, reason, data });
  const all = (await readdir(SNAPSHOTS)).filter((x) => x.endsWith('.json')).sort();
  for (const old of all.slice(0, Math.max(0, all.length - KEEP_SNAPSHOTS))) await unlink(join(SNAPSHOTS, old));
  return id;
}
async function snapshots(req, res, p, sess) {
  if (p === '/snapshots' && req.method === 'GET') {
    const names = (await readdir(SNAPSHOTS)).filter((x) => x.endsWith('.json')).sort().reverse();
    return send(res, 200, await Promise.all(names.map(async (n) => { const d = await readJson(join(SNAPSHOTS, n), {}); return { id: n.slice(0, -5), at: d.at, by: d.by, reason: d.reason }; })));
  }
  if (p === '/snapshots' && req.method === 'POST') {
    const b = await body(req, 4096);
    return send(res, 200, { id: await makeSnapshot(sess.user.login, String(b.reason || 'вручную').slice(0, 120)) });
  }
  const m = p.match(/^\/snapshots\/([0-9a-f]{10,30})\/restore$/);
  if (m && req.method === 'POST') {
    const d = await readJson(snapName(m[1]), null);
    if (!d) throw fail(404, 'нет такой версии');
    if (publishing) throw fail(409, 'Идёт публикация');
    await makeSnapshot(sess.user.login, 'перед восстановлением');
    for (const f of SNAP_FILES) {
      if (d.data[f] === null || d.data[f] === undefined) await unlink(P(f)).catch((e) => { if (e.code !== 'ENOENT') throw e; });
      else await saveJson(P(f), d.data[f]);
    }
    return send(res, 200, { ok: true });
  }
  throw fail(404, 'нет такого действия');
}

/* ---------- сводка и сервер ---------- */
async function dashboard(req, res, sess) {
  const u = sess.user;
  const out = {};
  const week = Date.now() - 7 * 864e5;
  if (can(u, 'leads')) {
    const [leads, reqs] = await Promise.all([internal('/leads'), internal('/requests')]);
    const live = leads.filter((l) => !l.destroyedAt);
    const days = [];
    for (let i = 29; i >= 0; i--) { const d = new Date(Date.now() - i * 864e5).toISOString().slice(0, 10); days.push({ d, n: leads.filter((l) => l.at.startsWith(d)).length }); }
    const stages = {};
    for (const l of live) if (l.stage) stages[l.stage] = (stages[l.stage] || 0) + 1;
    out.leads = { stages, total: live.length, fresh: live.filter((l) => !l.blockedAt && (!l.crm || l.crm.status === 'new')).length, week: leads.filter((l) => Date.parse(l.at) > week).length, days };
    out.requests = reqs.filter((q) => q.status !== 'done').map((q) => ({ id: q.id, at: q.at, kind: q.kind }));
  }
  if (can(u, 'orders')) {
    const orders = await internal('/orders');
    const paid = orders.filter((o) => o.status === 'paid');
    out.orders = { paid: paid.length, revenue: paid.reduce((s, o) => s + o.price, 0), week: paid.filter((o) => Date.parse(o.paidAt) > week).length };
  }
  if (can(u, 'publish')) { const pub = await readJson(join(HOME, 'published.json'), {}); out.site = { publishedAt: pub.at || null, dirty: !pub.at || (await lastChange()) > Date.parse(pub.at) }; }
  return send(res, 200, out);
}
async function systemInfo(req, res) {
  const fs = await statfs(HOME);
  const leads = await internal('/health').catch((e) => ({ error: e.message }));
  return send(res, 200, {
    node: process.version, uptime: Math.round(os.uptime()), load: os.loadavg(),
    mem: { total: os.totalmem(), free: os.freemem() },
    disk: { total: fs.blocks * fs.bsize, free: fs.bavail * fs.bsize },
    leads
  });
}

/* ---------- предпросмотр: сборка черновика в отдельный каталог; сайт не меняется ---------- */
const PREVIEW_CSP = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'none'; frame-src 'self'; frame-ancestors 'self'; base-uri 'none'; form-action 'none'; object-src 'none'"; // connect-src 'none': форма в предпросмотре не создаст настоящую заявку
const PREVIEW_TYPES = { html: 'text/html; charset=utf-8', css: 'text/css; charset=utf-8', js: 'text/javascript; charset=utf-8', json: 'application/json', woff2: 'font/woff2', webp: 'image/webp', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', mp4: 'video/mp4', pdf: 'application/pdf' };
async function draftBuild() {
  if (publishing) throw fail(409, 'Идёт публикация — повторите через минуту');
  publishing = true;
  try { return await run(process.execPath, [join(SITE_DIR, 'scripts/build.mjs')], { cwd: SITE_DIR, env: { ...process.env, CONTENT_DIR: CONTENT, DIST_DIR: PREVIEW_DIR, PREVIEW: '1' } }); }
  finally { publishing = false; }
}
async function buildPreview(req, res) {
  const b = await draftBuild();
  if (b.code !== 0) return send(res, 422, { error: 'Черновик не собрался — проверьте последние правки.', log: b.out });
  return send(res, 200, { ok: true, at: Date.now() });
}
// Проверка перед публикацией: собирается ли сайт, что изменилось, есть ли битые файлы и пропуски переводов.
const SNAP_LABELS = { 'texts.json': 'Тексты', 'blocks.json': 'Блоки главной', 'layout.json': 'Порядок секций', 'legal.json': 'Реквизиты', 'prices.json': 'Прайс', 'pages.json': 'Страницы', 'settings.json': 'Дизайн и контакты' };
async function preflight(req, res) {
  const b = await draftBuild();
  const buildError = b.code !== 0 ? (b.out.match(/Error: (.+)/)?.[1] || 'ошибка сборки') : '';
  const names = (await readdir(SNAPSHOTS)).filter((x) => x.endsWith('.json')).sort().reverse();
  let last = null;
  for (const n of names) { const d = await readJson(join(SNAPSHOTS, n), {}); if (d.reason === 'публикация') { last = d; break; } }
  const current = Object.fromEntries(await Promise.all(SNAP_FILES.map(async (f) => [f, await readJson(P(f), null)])));
  const changes = last ? SNAP_FILES.filter((f) => JSON.stringify(current[f]) !== JSON.stringify(last.data[f] ?? null)).map((f) => SNAP_LABELS[f]) : null;
  const existing = new Set(await readdir(P('files')));
  const text = JSON.stringify([current['blocks.json'], current['pages.json'], current['settings.json'], current['texts.json']]);
  const missingFiles = [...new Set([...text.matchAll(/\/files\/([^"\\/\s)]+)/g)].map((m) => m[1]))].filter((f) => !existing.has(f));
  const blocks = [...(current['blocks.json'] || []), ...(current['pages.json'] || []).flatMap((p) => p.blocks)];
  const untranslated = blocks.filter((x) => C.LANGS.some((l) => !x.title?.[l])).map((x) => x.title?.ru || x.id);
  const legalMissing = b.out.match(/не заполнено[^:]*: (.+)/)?.[1] || '';
  return send(res, 200, { buildError, changes, missingFiles, untranslated, legalMissing, lastPublish: last?.at || null });
}
async function servePreview(req, res, p) {
  let decoded;
  try { decoded = decodeURIComponent(p.slice('/preview/'.length)); } catch { throw fail(404, 'нет'); }
  const rel = normalize(decoded).replace(/^\/+/, '');
  let path = join(PREVIEW_DIR, rel);
  if (path !== PREVIEW_DIR && !path.startsWith(PREVIEW_DIR + '/')) throw fail(404, 'нет');
  let st = await stat(path).catch(() => null);
  if (st?.isDirectory()) { path = join(path, 'index.html'); st = await stat(path).catch(() => null); }
  if (!st) throw fail(404, 'нет такой страницы в предпросмотре');
  const ext = extname(path).slice(1).toLowerCase();
  const headers = { 'Content-Type': PREVIEW_TYPES[ext] || 'application/octet-stream', 'Cache-Control': 'no-store', 'Content-Security-Policy': PREVIEW_CSP, 'X-Robots-Tag': 'noindex', 'X-Content-Type-Options': 'nosniff' };
  if (ext === 'html' || ext === 'css') {
    const text = (await readFile(path, 'utf8'))
      .replace(/href="\/(?!\/|api\/)/g, `href="${PREVIEW_PREFIX}/`)
      .replace(/(["\s,(])\/(assets|fonts|media|files)\//g, `$1${PREVIEW_PREFIX}/$2/`);
    res.writeHead(200, headers);
    return res.end(text);
  }
  res.writeHead(200, { ...headers, 'Content-Length': st.size });
  createReadStream(path).pipe(res);
}

/* ---------- публикация ---------- */
let publishing = false;
const run = (cmd, args, opts = {}) => new Promise((resolve) => {
  const p = spawn(cmd, args, { ...opts, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  p.stdout.on('data', (d) => { out += d; }); p.stderr.on('data', (d) => { out += d; });
  const timer = setTimeout(() => p.kill('SIGKILL'), opts.timeout || 180000);
  p.on('close', (code) => { clearTimeout(timer); resolve({ code, out: out.slice(-20000) }); });
  p.on('error', (e) => { clearTimeout(timer); resolve({ code: 1, out: e.message }); });
});
async function lastChange() {
  let max = 0;
  const walk = async (d) => { for (const f of await readdir(d, { withFileTypes: true })) { const p = join(d, f.name); if (f.isDirectory()) await walk(p); else max = Math.max(max, (await stat(p)).mtimeMs); } };
  await walk(CONTENT);
  return max;
}
async function status(req, res) {
  const pub = await readJson(join(HOME, 'published.json'), {});
  const changed = await lastChange();
  const rel = (await readdir(RELEASES).catch(() => [])).filter((x) => /^\d{8}-\d{6}$/.test(x)).sort().reverse();
  return send(res, 200, { publishedAt: pub.at || null, dirty: !pub.at || changed > Date.parse(pub.at), releases: rel, publishing, site: SITE_URL });
}
async function publish(req, res, sess) {
  if (publishing) throw fail(409, 'Публикация уже идёт');
  publishing = true;
  const log = [];
  try {
    // Снимок товаров-инструкций: цены в HTML совпадают с живыми.
    try { const s = await internal('/shop'); await saveJson(P('shop-products.json'), s.doc); log.push('инструкции: снимок цен получен'); }
    catch (e) { log.push(`инструкции: снимок не получен (${e.message}) — цены подтянутся на странице`); }
    const b = await run(process.execPath, [join(SITE_DIR, 'scripts/build.mjs')], { cwd: SITE_DIR, env: { ...process.env, CONTENT_DIR: CONTENT } });
    log.push(b.out.trim());
    if (b.code !== 0) return send(res, 422, { error: 'Сборка не прошла — сайт не изменён. Исправьте ошибку и опубликуйте снова.', log: log.join('\n') });
    const index = await readFile(join(SITE_DIR, 'dist/index.html'), 'utf8').catch(() => '');
    if (!index.includes('id="page-data"')) return send(res, 422, { error: 'Сборка дала пустую страницу — сайт не изменён.', log: log.join('\n') });
    await makeSnapshot(sess.user.login, 'публикация');
    const id = new Date().toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15);
    const backup = await run('rsync', ['-a', '--delete', `${WWW}/`, join(RELEASES, id) + '/']);
    if (backup.code !== 0) return send(res, 500, { error: 'Не удалось сохранить резервную копию — публикация отменена.', log: log.concat(backup.out).join('\n') });
    const sync = await run('rsync', ['-a', '--delete', '--delay-updates', join(SITE_DIR, 'dist') + '/', `${WWW}/`]);
    if (sync.code !== 0) return send(res, 500, { error: 'Ошибка выкладки', log: log.concat(sync.out).join('\n') });
    const rel = (await readdir(RELEASES)).filter((x) => /^\d{8}-\d{6}$/.test(x)).sort();
    for (const old of rel.slice(0, Math.max(0, rel.length - KEEP_RELEASES))) await rm(join(RELEASES, old), { recursive: true, force: true });
    await saveJson(join(HOME, 'published.json'), { at: new Date().toISOString(), backup: id });
    console.log(`admin: опубликовано (копия ${id})`);
    return send(res, 200, { ok: true, backup: id, log: log.join('\n') });
  } finally { publishing = false; }
}
async function rollback(req, res) {
  const { id } = await body(req);
  if (!/^\d{8}-\d{6}$/.test(String(id))) throw fail(422, 'копия');
  const dir = join(RELEASES, id);
  if (!(await stat(dir).catch(() => null))) throw fail(404, 'нет такой копии');
  if (publishing) throw fail(409, 'Идёт публикация');
  publishing = true;
  try {
    const sync = await run('rsync', ['-a', '--delete', '--delay-updates', dir + '/', `${WWW}/`]);
    if (sync.code !== 0) throw fail(500, 'ошибка отката');
    await saveJson(join(HOME, 'published.json'), { at: new Date().toISOString(), rolledBackTo: id });
    console.log(`admin: откат к ${id}`);
    return send(res, 200, { ok: true });
  } finally { publishing = false; }
}

/* ---------- права ---------- */
// Какое право нужно для пути. null — любому вошедшему; неизвестный путь — только суперадмину.
function permFor(p) {
  if (['/status', '/dashboard'].includes(p)) return null;
  const rules = [[/^\/(texts|blocks|pages|preview)(\/|$)/, 'content'], [/^\/settings$/, 'design'], [/^\/files(\/|$)/, 'files'], [/^\/prices$/, 'prices'], [/^\/legal$/, 'legal'],
    [/^\/(publish|preflight|rollback|snapshots)(\/|$)/, 'publish'], [/^\/translate$/, 'content'], [/^\/shop(\/|$)/, 'shop'], [/^\/leads\/\d+\/(block|destroy)$/, 'pd'], [/^\/requests\/\d+\/done$/, 'pd'], [/^\/(leads|requests)(\/|$)/, 'leads'],
    [/^\/orders(\/|$)/, 'orders'], [/^\/audit$/, 'audit'], [/^\/(users|sessions)(\/|$)/, 'users'], [/^\/(integrations|system)(\/|$)/, 'system']];
  const r = rules.find(([re]) => re.test(p));
  return r ? r[1] : ALL;
}
const ACTION_NAMES = [[/^\/texts/, 'тексты'], [/^\/blocks/, 'конструктор главной'], [/^\/pages/, 'страницы'], [/^\/settings/, 'дизайн и контакты'], [/^\/files/, 'файлы'], [/^\/prices/, 'прайс'], [/^\/legal/, 'реквизиты'], [/^\/publish/, 'публикация'], [/^\/rollback/, 'откат сайта'], [/^\/snapshots/, 'версии контента'], [/^\/shop/, 'инструкции'], [/^\/leads/, 'заявки'], [/^\/requests/, 'обращения ПДн'], [/^\/orders/, 'заказы'], [/^\/users/, 'пользователи'], [/^\/sessions/, 'сессии'], [/^\/integrations/, 'интеграции'], [/^\/system/, 'сервер'], [/^\/me/, 'свой профиль']];
function safeDecode(s) { try { return decodeURIComponent(s); } catch { return s; } }
const actionName = (method, p) => `${(ACTION_NAMES.find(([re]) => re.test(p)) || [0, p])[1]}: ${{ GET: 'просмотр', POST: 'действие', PUT: 'изменение', DELETE: 'удаление' }[method] || method} ${safeDecode(p).slice(0, 200)}`;
const PD_READS = new Set(['/leads', '/requests', '/orders']); // просмотр персональных данных тоже попадает в журнал

async function dispatch(req, res, url, p, sess) {
  const pass = (data) => send(res, 200, data);
  const jsonOpts = async (method) => ({ method, body: JSON.stringify(await body(req)), headers: { 'Content-Type': 'application/json' } });
  if (p === '/status' && req.method === 'GET') return status(req, res);
  if (p === '/dashboard' && req.method === 'GET') return dashboard(req, res, sess);
  if (p === '/texts' && ['GET', 'PUT'].includes(req.method)) return texts(req, res, url);
  if (p === '/blocks' && ['GET', 'PUT'].includes(req.method)) return blocks(req, res);
  if (p === '/pages' && ['GET', 'PUT'].includes(req.method)) return pages(req, res);
  if (p === '/settings' && ['GET', 'PUT'].includes(req.method)) return settings(req, res);
  if (p === '/preview' && req.method === 'POST') return buildPreview(req, res);
  if (p.startsWith('/preview/') && req.method === 'GET') return servePreview(req, res, p);
  if (p === '/files' || p.startsWith('/files/')) return files(req, res, url);
  if (p === '/prices' && ['GET', 'PUT'].includes(req.method)) return prices(req, res);
  if (p === '/legal' && ['GET', 'PUT'].includes(req.method)) return legal(req, res);
  if (p === '/publish' && req.method === 'POST') return publish(req, res, sess);
  if (p === '/preflight' && req.method === 'POST') return preflight(req, res);
  if (p === '/translate' && req.method === 'POST') return pass(await internal('/translate', await jsonOpts('POST')));
  if (p === '/rollback' && req.method === 'POST') return rollback(req, res);
  if (p.startsWith('/snapshots')) return snapshots(req, res, p, sess);
  if (p.startsWith('/users')) return usersApi(req, res, p, sess);
  if (p.startsWith('/sessions')) return sessionsApi(req, res, p, sess);
  if (p === '/system' && req.method === 'GET') return systemInfo(req, res);
  if (p === '/system/restart-leads' && req.method === 'POST') return pass(await internal('/restart', { method: 'POST' }));
  if (p === '/audit' && req.method === 'GET') {
    const lines = (await readFile(AUDIT_FILE, 'utf8').catch(() => '')).split('\n').filter(Boolean);
    return pass(lines.slice(-1000).reverse().map((l) => JSON.parse(l)));
  }
  if (p === '/integrations' && req.method === 'GET') return pass(await internal('/integrations'));
  if (p === '/integrations' && req.method === 'PUT') return pass(await internal('/integrations', await jsonOpts('PUT')));
  if (p === '/integrations/test-telegram' && req.method === 'POST') return pass(await internal('/integrations/test-telegram', { method: 'POST' }));
  // Заявки, обращения, заказы — через сервер заявок.
  if (req.method === 'GET' && PD_READS.has(p)) return pass(await internal(p));
  const li = p.match(/^\/leads\/(\d+)(\/block|\/destroy)?$/);
  if (li && req.method === (li[2] ? 'POST' : 'PUT')) return pass(await internal(p, await jsonOpts(req.method)));
  if (/^\/requests\/\d+\/done$/.test(p) && req.method === 'POST') return pass(await internal(p, { method: 'POST' }));
  if (/^\/orders\/\d+\/(relink|refunded)$/.test(p) && req.method === 'POST') return pass(await internal(p, { method: 'POST' }));
  if (p === '/shop' && req.method === 'GET') return pass(await internal('/shop'));
  if (p === '/shop/products' && req.method === 'PUT') return pass(await internal('/shop/products', await jsonOpts('PUT')));
  const sf = p.match(/^\/shop\/files\/([a-z0-9-]{2,30})\/([^/]+)$/);
  if (sf && req.method === 'DELETE') return pass(await internal(`/shop/files/${sf[1]}/${encodeURIComponent(cleanName(decodeURIComponent(sf[2])))}`, { method: 'DELETE' }));
  if (sf && req.method === 'PUT') {
    if (Number(req.headers['content-length'] || 0) > MAX_UPLOAD) throw fail(413, 'файл больше 60 МБ');
    return pass(await internal(`/shop/files/${sf[1]}/${encodeURIComponent(cleanName(decodeURIComponent(sf[2])))}`, { method: 'PUT', body: req }));
  }
  throw fail(404, 'нет такого действия');
}

/* ---------- маршруты ---------- */
const ORIGIN = new URL(SITE_URL).origin;
createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (!url.pathname.startsWith('/api/admin/')) throw fail(404, 'нет');
    const mutating = req.method !== 'GET' && req.method !== 'HEAD';
    // Защита от CSRF: свой заголовок (обычная форма или чужой сайт его не пришлёт) и Origin своего сайта.
    if (mutating) {
      if (req.headers['x-admin'] !== '1') throw fail(403, 'нет заголовка X-Admin');
      if (req.headers.origin && req.headers.origin !== ORIGIN) throw fail(403, 'чужой сайт');
    }
    const p = url.pathname.slice('/api/admin'.length);
    if (p === '/login' && req.method === 'POST') return await login(req, res);
    const sess = session(req);
    if (p === '/logout' && req.method === 'POST') {
      if (sess) { sessions.delete(sess.token); await saveSessions(); await audit(req, sess.user.login, 'выход'); }
      return send(res, 200, { ok: true }, { 'Set-Cookie': setCookie('', 0) });
    }
    if (p === '/me' && req.method === 'GET') return sess ? send(res, 200, { ok: true, user: { ...publicUser(sess.user), roleLabel: ROLES[sess.user.role]?.label, perms: permsOf(sess.user) } }) : send(res, 401, { ok: false });
    if (!sess) throw fail(401, 'Войдите в панель');
    if (p.startsWith('/me/')) {
      await profile(req, res, p, sess);
      if (res.statusCode < 400) await audit(req, sess.user.login, actionName(req.method, p));
      return;
    }
    if (!can(sess.user, permFor(p))) throw fail(403, 'Недостаточно прав');
    await dispatch(req, res, url, p, sess);
    if (res.statusCode < 400 && (mutating || PD_READS.has(p)) && !['/preview', '/preflight', '/translate'].includes(p)) await audit(req, sess.user.login, actionName(req.method, p));
  } catch (e) {
    const st = e.status || 500;
    if (st >= 500) console.error('admin', e.message);
    if (!res.headersSent) send(res, st, { error: st >= 500 && !e.status ? 'Ошибка сервера' : e.message });
  }
}).listen(PORT, '127.0.0.1', () => console.log(`sverify-admin на 127.0.0.1:${PORT}; сайт: ${SITE_DIR}; правки: ${CONTENT}; публикация в ${WWW}`));
