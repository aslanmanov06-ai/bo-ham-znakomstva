// Migrant AI: ответы языковой модели через внешний API в формате OpenAI (/v1/chat/completions).
// Вопросы не записываются ни в файлы, ни в журнал; на сайте посетителя просят не указывать личные данные.
// Модель отвечает только по справке build/ai-knowledge.txt (этапы, услуги и цены с сайта).
//   POST /api/ai {q, lang} → поток text/event-stream: data: {"t":"…"} … data: {"done":true}
// Окружение (/etc/sverify/leads.env): AI_URL, AI_MODEL, AI_KEY — без них /api/ai отвечает 503,
//            а сайт показывает готовые ответы на частые вопросы.
//            AI_KNOWLEDGE (путь к справке), AI_PARALLEL (одновременных ответов), AI_QUEUE (ждущих).
import { readFile, stat } from 'node:fs/promises';

const URL_ = process.env.AI_URL || '';
const MODEL = process.env.AI_MODEL || '';
const KEY = process.env.AI_KEY || '';
// Дополнительные поля запроса (JSON), например для моделей с рассуждениями на OpenRouter:
// AI_EXTRA={"reasoning":{"effort":"medium","exclude":true}} — рассуждения умеренные и не попадают в ответ.
let EXTRA = {};
try { EXTRA = JSON.parse(process.env.AI_EXTRA || '{}'); } catch { console.error('ai: AI_EXTRA — не JSON'); }
const MAX_TOKENS = Number(process.env.AI_MAX_TOKENS || 1500); // у моделей с рассуждениями сюда входят и они
const PARALLEL = Number(process.env.AI_PARALLEL || 3);
const QUEUE = Number(process.env.AI_QUEUE || 6);
const KNOWLEDGE_FILE = process.env.AI_KNOWLEDGE || new URL('./ai-knowledge.txt', import.meta.url).pathname;
const LANG_NAMES = { ru: 'русском', tg: 'таджикском (кириллица)', kk: 'казахском', ky: 'кыргызском', uz: 'узбекском (латиница)' };

// Справка перечитывается, когда файл меняется (после публикации из админ-панели).
let knowledge = '';
let knowMtime = 0;
async function refreshKnowledge() {
  try {
    const m = (await stat(KNOWLEDGE_FILE)).mtimeMs;
    if (m !== knowMtime) { knowledge = (await readFile(KNOWLEDGE_FILE, 'utf8')).trim(); knowMtime = m; }
  } catch (e) { if (!knowMtime) console.error('ai: нет справки', KNOWLEDGE_FILE, e.message); }
}
await refreshKnowledge();

// Системная инструкция одна и та же для всех запросов (язык — в сообщении пользователя),
// поэтому у провайдеров с кэшем префикса она обрабатывается быстрее и дешевле.
const system = () => `Ты — Migrant AI, помощник на сайте миграционного юриста (Россия). Ты помогаешь иностранным гражданам понять, с чего начать, и подобрать услугу.

Правила:
1. Отвечай кратко: 2–5 предложений простым языком, без заголовков, таблиц и списков длиннее 3 пунктов.
2. Опирайся только на СПРАВКУ ниже. Никогда не называй сроки в днях, месяцах или годах, статьи законов, суммы штрафов и госпошлин, номера форм и адреса — даже если уверен (например, нельзя писать «в течение 30 дней» или «за 7 рабочих дней»). Вместо этого скажи, что точные сроки и суммы юрист уточнит на консультации.
3. Ничего не обещай и не гарантируй результат. Не советуй нарушать закон или обманывать органы власти.
4. Если в справке есть подходящая услуга, назови её и цену «от» из справки. Цены — только в российских рублях: всегда пиши знак «₽» и не заменяй его на сом, сум, сомони, тенге или другую валюту.
5. Если вопрос не о миграции, документах иностранца в России или услугах юриста — вежливо ответь, что помогаешь только с миграционными вопросами.
6. Не проси имя, телефон, номера документов и другие личные данные. Для разбора ситуации предложи записаться на консультацию через форму «Консультация» на этой странице или написать в WhatsApp/Telegram.
7. Ты не юрист и не заменяешь консультацию — при сложной или срочной ситуации (задержание, выдворение, запрет въезда, суд) прямо советуй срочно обратиться к юристу.
8. Отвечай на том языке, который указан в сообщении пользователя, грамотно и без вставок русских слов (кроме названий услуг из справки).

СПРАВКА:
${knowledge}`;

const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 600e3);
  list.push(now);
  hits.set(ip, list);
  if (hits.size > 5000) for (const [k, v] of hits) if (now - v[v.length - 1] > 600e3) hits.delete(k);
  return list.length > 15; // не больше 15 вопросов за 10 минут с одного адреса
}

let active = 0;
const waiting = [];
function acquire() {
  if (active < PARALLEL) { active++; return Promise.resolve(); }
  if (waiting.length >= QUEUE) return null;
  return new Promise((resolve) => waiting.push(resolve));
}
function release() {
  const next = waiting.shift();
  if (next) next(); else active--;
}

export async function handleAi(req, res, body, ip, send) {
  const q = String(body.q ?? '').replace(/[\u0000-\u001F\u007F]/g, ' ').trim().slice(0, 300);
  const lang = LANG_NAMES[body.lang] ? body.lang : 'ru';
  if (q.length < 2) return send(res, 422, { error: 'empty' });
  await refreshKnowledge();
  if (!knowledge || !URL_ || !MODEL) return send(res, 503, { error: 'off' });
  if (limited(ip)) return send(res, 429, { error: 'too many' });
  const slot = acquire();
  if (!slot) return send(res, 503, { error: 'busy' });

  const ctrl = new AbortController();
  let closed = false;
  res.on('close', () => { closed = true; ctrl.abort(); });
  await slot;
  const timer = setTimeout(() => ctrl.abort(), 90e3);
  let started = false;
  try {
    if (closed) return;
    const r = await fetch(URL_, {
      method: 'POST',
      headers: Object.assign({ 'Content-Type': 'application/json', 'HTTP-Referer': 'https://sverify.online', 'X-Title': 'Migrant AI' }, KEY ? { Authorization: `Bearer ${KEY}` } : {}),
      body: JSON.stringify({
        ...EXTRA, model: MODEL, stream: true, temperature: 0.3, max_tokens: MAX_TOKENS,
        messages: [{ role: 'system', content: system() }, { role: 'user', content: `Ответь на ${LANG_NAMES[lang]} языке. Вопрос: ${q}` }]
      }),
      signal: ctrl.signal
    });
    if (!r.ok || !r.body) { console.error('ai: модель ответила', r.status); return send(res, 503, { error: 'model' }); }
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store, no-transform', 'X-Accel-Buffering': 'no' });
    started = true;
    const dec = new TextDecoder();
    let buf = '';
    for await (const chunk of r.body) {
      buf += dec.decode(chunk, { stream: true });
      let i;
      while ((i = buf.indexOf('\n')) > -1) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim();
        if (data === '[DONE]') continue;
        let t = '';
        try { t = JSON.parse(data).choices?.[0]?.delta?.content || ''; } catch { continue; }
        if (t) res.write(`data: ${JSON.stringify({ t })}\n\n`);
      }
    }
    res.end('data: {"done":true}\n\n');
  } catch (e) {
    if (!closed) console.error('ai:', e.name === 'AbortError' ? 'таймаут' : e.message);
    if (!started) { if (!closed) send(res, 503, { error: 'model' }); } else res.end(`data: ${JSON.stringify({ error: true })}\n\n`);
  } finally {
    clearTimeout(timer);
    release();
  }
}
