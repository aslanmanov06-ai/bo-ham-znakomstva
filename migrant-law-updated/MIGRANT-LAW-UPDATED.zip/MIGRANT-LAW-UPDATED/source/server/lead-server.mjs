// Приём заявок с сайта sverify.online. Без зависимостей.
//   POST /api/lead     — заявка (только с отмеченным согласием; факт согласия записывается вместе с заявкой)
//   POST /api/ai       — вопрос к Migrant AI (локальная модель, см. ai.mjs; вопросы не сохраняются)
//   POST /api/withdraw — обращение субъекта ПДн: отзыв согласия / запрос сведений / уточнение
//   /api/shop/*        — продажа PDF-инструкций через ЮKassa (см. shop.mjs)
// Данные: DATA_DIR/leads.jsonl, DATA_DIR/requests.jsonl (права 600, каталог 700).
// Уведомление в Telegram (если задано) — БЕЗ персональных данных: только номер и этап заявки,
// чтобы не было трансграничной передачи ПДн. Сами заявки читаются на сервере (scripts/pd-admin.mjs).
// Окружение: PORT, DATA_DIR, CONSENT_FILE (версия и хэш текста согласия), RETENTION_DAYS,
//            TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID (через запятую).
import './settings-env.mjs'; // первым: настройки из панели попадают в process.env до чтения его остальными модулями
import { createServer } from 'node:http';
import { readFile, writeFile, appendFile, rename, mkdir, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { handleAi } from './ai.mjs';
import { handleShopGet, handleShopOrder, handleShopWebhook, payEnabled } from './shop.mjs';
import { startInternal } from './internal.mjs';

const PORT = Number(process.env.PORT || 3110);
const DATA_DIR = process.env.DATA_DIR || '/var/lib/sverify';
const LEADS = join(DATA_DIR, 'leads.jsonl');
const REQUESTS = join(DATA_DIR, 'requests.jsonl');
const CONSENT_FILE = process.env.CONSENT_FILE || new URL('./consent.json', import.meta.url).pathname;
const RETENTION_DAYS = Number(process.env.RETENTION_DAYS || 365);
const BOT = process.env.TELEGRAM_BOT_TOKEN || '';
const CHATS = (process.env.TELEGRAM_CHAT_ID || '').split(',').map((s) => s.trim()).filter(Boolean);
const STAGES = { uchet: 'Регистрация и учёт', patent: 'Патент', eaeu: 'Работа по договору (ЕАЭС)', rvp: 'РВП', vnzh: 'ВНЖ', grazh: 'Гражданство', problem: 'Отказ, запрет въезда, РКЛ', urgent: 'СРОЧНО: задержание или проверка', help: 'Не знает, с чего начать' };
const COUNTRIES = { tj: 'Таджикистан', uz: 'Узбекистан', kg: 'Кыргызстан', kz: 'Казахстан', md: 'Молдова', other: 'другая страна' };
const LANGS = { ru: 'русский', tg: 'таджикский', kk: 'казахский', ky: 'кыргызский', uz: 'узбекский' };
const PATHS = { ru: '/', tg: '/tj/', kk: '/kz/', ky: '/kg/', uz: '/uz/' };
const KINDS = { withdraw: 'отзыв согласия', info: 'запрос сведений', correct: 'уточнение данных' };

await mkdir(DATA_DIR, { recursive: true, mode: 0o700 });
// Версия согласия перечитывается при изменении файла: после публикации из админ-панели перезапуск не нужен.
let consentMeta = { version: '', sha256: '' };
let consentMtime = 0;
async function refreshConsent() {
  try {
    const m = (await stat(CONSENT_FILE)).mtimeMs;
    if (m !== consentMtime) { consentMeta = JSON.parse(await readFile(CONSENT_FILE, 'utf8')); consentMtime = m; }
  } catch (e) { if (!consentMtime) console.error('нет файла версии согласия', CONSENT_FILE, e.message); }
}
await refreshConsent();

// Последовательная очередь для операций с файлом заявок (запись, блокировка, очистка).
let queue = Promise.resolve();
const serial = (fn) => (queue = queue.then(fn, fn));

async function readLeads() {
  try { return (await readFile(LEADS, 'utf8')).split('\n').filter(Boolean).map((l) => JSON.parse(l)); }
  catch (e) { if (e.code === 'ENOENT') return []; throw e; }
}
async function writeLeads(list) {
  const tmp = LEADS + '.tmp';
  await writeFile(tmp, list.map((x) => JSON.stringify(x)).join('\n') + (list.length ? '\n' : ''), { mode: 0o600 });
  await rename(tmp, LEADS);
}
let counter = (await readLeads()).reduce((m, x) => Math.max(m, x.id || 0), 0);

const digits = (s) => String(s || '').replace(/\D/g, '');
const norm = (s) => String(s || '').toLowerCase().replace(/[\s@+()\-]/g, '');
function sameContact(a, b) {
  const da = digits(a), db = digits(b);
  if (da.length >= 7 && db.length >= 7) return da.slice(-10) === db.slice(-10);
  return norm(a) && norm(a) === norm(b);
}

// Уничтожение ПДн: остаётся только обезличенная запись (номер, даты, версия согласия) — для учёта.
function destroy(lead, reason) {
  return { id: lead.id, at: lead.at, destroyedAt: new Date().toISOString(), destroyReason: reason, consent: lead.consent ? { version: lead.consent.version, at: lead.consent.at } : undefined };
}

// Срок хранения: заявки старше RETENTION_DAYS и заблокированные дольше 30 дней уничтожаются раз в сутки.
async function purge() {
  return serial(async () => {
    const now = Date.now();
    let changed = 0;
    const list = (await readLeads()).map((l) => {
      if (l.destroyedAt) return l;
      if (l.blockedAt && now - Date.parse(l.blockedAt) > 30 * 864e5) { changed++; return destroy(l, 'отзыв согласия'); }
      if (now - Date.parse(l.at) > RETENTION_DAYS * 864e5) { changed++; return destroy(l, 'истёк срок хранения'); }
      return l;
    });
    if (changed) { await writeLeads(list); console.log(`очистка: уничтожено ${changed}`); }
  });
}
await purge();
setInterval(() => purge().catch((e) => console.error('purge', e.message)), 6 * 3600e3).unref();

// Не больше 5 отправок за 10 минут с одного IP.
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 600e3);
  list.push(now);
  hits.set(ip, list);
  if (hits.size > 5000) for (const [k, v] of hits) if (now - v[v.length - 1] > 600e3) hits.delete(k);
  return list.length > 5;
}

const clean = (v, max) => String(v ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, max);

async function notify(text) {
  if (!BOT || !CHATS.length) return;
  await Promise.all(CHATS.map(async (chat) => {
    try {
      const r = await fetch(`https://api.telegram.org/bot${BOT}/sendMessage`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chat, text, disable_web_page_preview: true }),
        signal: AbortSignal.timeout(8000)
      });
      if (!r.ok) console.error('telegram', r.status);
    } catch (e) { console.error('telegram', e.message); }
  }));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const parts = [];
    req.on('data', (c) => { size += c.length; if (size > 16 * 1024) { reject(new Error('too big')); req.destroy(); } else parts.push(c); });
    req.on('end', () => resolve(Buffer.concat(parts).toString('utf8')));
    req.on('error', reject);
  });
}
function send(res, status, obj, headers = {}) {
  res.writeHead(status, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers));
  res.end(obj ? JSON.stringify(obj) : '');
}

async function handleLead(req, res, body, isForm, ip) {
  const lang = LANGS[body.lang] ? body.lang : 'ru';
  const back = (ok) => send(res, 303, null, { Location: `${PATHS[lang]}?lead=${ok ? 'ok' : 'error'}#consultation` });
  if (clean(body.website, 200)) return isForm ? back(true) : send(res, 200, { ok: true, id: 0 });
  if (limited(ip)) return isForm ? back(false) : send(res, 429, { error: 'too many' });
  const name = clean(body.name, 80);
  const contact = clean(body.contact, 80);
  if (!name || !contact) return isForm ? back(false) : send(res, 422, { error: 'required' });
  // Согласие — отдельное, явное и на действующий текст. Без него данные не сохраняются.
  if (body.consent !== 'yes' && body.consent !== true && body.consent !== 'on') return isForm ? back(false) : send(res, 422, { error: 'consent' });
  if (!consentMeta.version || clean(body.consent_version, 20) !== consentMeta.version) return isForm ? back(false) : send(res, 409, { error: 'consent version' });
  const now = new Date().toISOString();
  const lead = await serial(async () => {
    const l = {
      id: ++counter, at: now, name, contact,
      message: clean(body.message, 2000),
      stage: STAGES[body.stage] ? body.stage : '',
      country: COUNTRIES[body.country] ? body.country : '',
      lang,
      consent: {
        given: true, at: now, form: 'consultation', page: clean(body.page, 40) || PATHS[lang],
        version: consentMeta.version, sha256: consentMeta.sha256, docDate: consentMeta.date,
        ip, userAgent: clean(req.headers['user-agent'], 300)
      }
    };
    try { await appendFile(LEADS, JSON.stringify(l) + '\n', { mode: 0o600 }); }
    catch (e) { counter--; throw e; }
    return l;
  }).catch((e) => { console.error('save', e.message); return null; });
  if (!lead) return isForm ? back(false) : send(res, 500, { error: 'save' });
  notify(`Новая заявка №${lead.id} с сайта${lead.stage ? ` · ${STAGES[lead.stage]}` : ''}${lead.country ? ` · страна: ${COUNTRIES[lead.country]}` : ''} · язык: ${LANGS[lang]}. Данные заявки — на сервере.`);
  console.log(`lead #${lead.id} ${lang} ${lead.stage || '-'}`);
  return isForm ? back(true) : send(res, 200, { ok: true, id: lead.id });
}

async function handleWithdraw(req, res, body, isForm, ip) {
  const back = (ok) => send(res, 303, null, { Location: `/legal/withdraw/?sent=${ok ? 'ok' : 'error'}` });
  if (clean(body.website, 200)) return isForm ? back(true) : send(res, 200, { ok: true });
  if (limited(ip)) return isForm ? back(false) : send(res, 429, { error: 'too many' });
  const contact = clean(body.contact, 80);
  if (!contact) return isForm ? back(false) : send(res, 422, { error: 'required' });
  const kind = KINDS[body.kind] ? body.kind : 'withdraw';
  const now = new Date().toISOString();
  let matched = [];
  try {
    await serial(async () => {
      const list = await readLeads();
      for (const l of list) {
        if (l.destroyedAt || !sameContact(l.contact, contact)) continue;
        matched.push(l.id);
        // Отзыв: обработка прекращается сразу (блокировка), уничтожение — в течение 30 дней (purge или pd-admin).
        if (kind === 'withdraw' && !l.blockedAt) { l.blockedAt = now; l.blockReason = 'отзыв согласия'; }
      }
      if (kind === 'withdraw' && matched.length) await writeLeads(list);
      const reqId = (await readFile(REQUESTS, 'utf8').catch(() => '')).split('\n').filter(Boolean).length + 1;
      await appendFile(REQUESTS, JSON.stringify({ id: reqId, at: now, kind, contact, name: clean(body.name, 80), comment: clean(body.comment, 1000), leads: matched, ip, status: 'new' }) + '\n', { mode: 0o600 });
    });
  } catch (e) {
    console.error('withdraw', e.message);
    return isForm ? back(false) : send(res, 500, { error: 'save' });
  }
  notify(`Обращение по персональным данным: ${KINDS[kind]}. Найдено заявок: ${matched.length}. Ответить в течение 10 рабочих дней — подробности на сервере.`);
  console.log(`request ${kind} matched=${matched.length}`);
  return isForm ? back(true) : send(res, 200, { ok: true });
}

createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  await refreshConsent();
  if (url.pathname === '/api/health') return send(res, 200, { ok: true, consent: consentMeta.version });
  if (req.method === 'GET' && url.pathname.startsWith('/api/shop/')) {
    return handleShopGet(req, res, url, send).catch((e) => { console.error('shop', e.message); if (!res.headersSent) send(res, 500, { error: 'shop' }); });
  }
  const route = { '/api/lead': handleLead, '/api/withdraw': handleWithdraw, '/api/ai': handleAi, '/api/shop/order': handleShopOrder, '/api/shop/webhook': handleShopWebhook }[url.pathname];
  if (!route) return send(res, 404, { error: 'not found' });
  if (req.method !== 'POST') return send(res, 405, { error: 'method' }, { Allow: 'POST' });
  const ip = String(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const isForm = String(req.headers['content-type'] || '').startsWith('application/x-www-form-urlencoded');
  let raw;
  try { raw = await readBody(req); } catch { return send(res, 413, { error: 'too big' }); }
  let body;
  try { body = isForm ? Object.fromEntries(new URLSearchParams(raw)) : JSON.parse(raw); } catch { return send(res, 400, { error: 'bad json' }); }
  if (!body || typeof body !== 'object') return send(res, 400, { error: 'bad body' });
  if (route === handleAi) return handleAi(req, res, body, ip, send);
  if (route === handleShopOrder) return handleShopOrder(req, res, body, ip, send, { consentMeta }).catch((e) => { console.error('shop order', e.message); send(res, 500, { error: 'shop' }); });
  if (route === handleShopWebhook) return handleShopWebhook(req, res, body, ip, send, { notify }).catch((e) => { console.error('shop webhook', e.message); send(res, 500, { error: 'shop' }); });
  return route(req, res, body, isForm, ip);
}).listen(PORT, '127.0.0.1', () => console.log(`sverify-leads на 127.0.0.1:${PORT}; согласие v${consentMeta.version || '?'}; telegram: ${BOT && CHATS.length ? 'вкл (без ПДн)' : 'выкл'}; оплата ЮKassa: ${payEnabled() ? 'вкл' : 'выкл (нет ключей)'}`));
startInternal({ leadsFile: LEADS, requestsFile: REQUESTS, serial, readLeads, writeLeads, destroy, status: () => ({ uptime: Math.round(process.uptime()), consent: consentMeta.version, telegram: Boolean(BOT && CHATS.length), pay: payEnabled(), ai: Boolean(process.env.AI_KEY) }) });
