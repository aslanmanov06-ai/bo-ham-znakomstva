// Данные глобуса первого экрана → src/globe-dots.json (запускать вручную при смене данных).
// Нужны world-atlas@2.0.2 и topojson-client@3.1.0: `npm i world-atlas@2.0.2 topojson-client@3.1.0` во временной папке
// и запуск ИЗ НЕЁ: `node /путь/к/source/scripts/make-globe.mjs` (данные Natural Earth, public domain).
// В файле: n — число точек сферы Фибоначчи; land и hi — номера точек, попавших на сушу (hi — Россия, Казахстан,
// Кыргызстан, Таджикистан, Узбекистан: рисуются ярче); coast — контуры материков (широта, долгота ×10, дальше приращения).
// Номера записаны приращениями в 36-ричной системе: так файл в несколько раз меньше, а точки src/globe.js считает сам.
import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(process.cwd() + '/');
const { feature } = require('topojson-client');
const land = require('world-atlas/land-110m.json');
const cs = require('world-atlas/countries-110m.json');
const L = feature(land, land.objects.land);
const C = feature(cs, cs.objects.countries);
const HI = new Set(['643', '398', '417', '762', '860']);
const polys = (g) => g.type === 'Polygon' ? [g.coordinates] : g.coordinates;
const inRing = (x, y, r) => { let c = false; for (let i = 0, j = r.length - 1; i < r.length; j = i++) { const [xi, yi] = r[i], [xj, yj] = r[j]; if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c; } return c; };
const inGeom = (x, y, g) => polys(g).some((p) => inRing(x, y, p[0]) && !p.slice(1).some((h) => inRing(x, y, h)));
const landGeoms = L.features.map((f) => f.geometry);
const hiGeoms = C.features.filter((f) => HI.has(String(f.id))).map((f) => f.geometry);
const N = 15000, out = [], hi = [];
const ga = Math.PI * (3 - Math.sqrt(5));
for (let i = 0; i < N; i++) {
  const y = 1 - (i / (N - 1)) * 2, lat = Math.asin(y) * 180 / Math.PI;
  let lon = ((i * ga) * 180 / Math.PI) % 360; if (lon > 180) lon -= 360;
  if (lat < -58) continue;
  if (landGeoms.some((g) => inGeom(lon, lat, g))) (hiGeoms.some((g) => inGeom(lon, lat, g)) ? hi : out).push(i);
}
const delta = (a) => a.map((v, i) => (i ? v - a[i - 1] : v).toString(36)).join(',');
// Контуры: без Антарктиды и без мелких островов (меньше 6 вершин).
const rings = [];
for (const g of landGeoms) for (const p of polys(g)) {
  const r = p[0].map(([lon, lat]) => [Math.round(lat * 10), Math.round(lon * 10)]);
  if (r.length < 6 || r.every(([la]) => la < -600)) continue;
  const flat = [];
  r.forEach(([la, lo], i) => { if (i) flat.push(la - r[i - 1][0], lo - r[i - 1][1]); else flat.push(la, lo); });
  rings.push(flat.join(','));
}
fs.writeFileSync(new URL('../src/globe-dots.json', import.meta.url), JSON.stringify({ n: N, land: delta(out), hi: delta(hi), coast: rings.join(';') }) + '\n');
console.log('land', out.length, 'hi', hi.length, 'rings', rings.length);
