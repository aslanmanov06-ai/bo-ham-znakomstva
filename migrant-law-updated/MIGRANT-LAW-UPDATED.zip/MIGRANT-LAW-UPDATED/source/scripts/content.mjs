// Правки сайта из админ-панели (/admin/). Исходники в src/ не меняются: правки лежат в CONTENT_DIR
// (на сервере /var/lib/sverify-admin/content) и накладываются при сборке. Так обновления кода
// не затирают правки владельца, а правки не ломают обновления кода.
//   texts.json   — { "ru": { "k.h1": [...], "j.faq": [...] }, "tg": {...} } — замена текстов по пути
//   blocks.json  — новые блоки на главной: [{ id, eyebrow, title, text, image, buttons, files }]
//   layout.json  — { order: [...id секций и блоков], hidden: [...] } — порядок и скрытые секции
//   legal.json   — сведения о владельце (поверх src/legal.json)
//   prices.json  — полный прайс (вместо src/prices.json)
//   shop-products.json — снимок товаров-инструкций с сервера заявок (цены в HTML совпадают с живыми)
//   pages.json   — свои страницы: [{ id, slug, title, desc, blocks, inMenu, hidden, noindex }]
//   settings.json — контакты, цвета, своё CSS, объявление над шапкой, дополнительные пункты меню
//   files/       — загруженные файлы и картинки, публикуются как /files/<имя>
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';

export const LANGS = ['ru', 'tg', 'kk', 'ky', 'uz'];
// Секции главной по умолчанию (первый экран всегда сверху).
// Порядок по умолчанию: выбор страны и ситуации сразу после первого экрана, заявка — ближе к концу.
// (Три действия первого экрана — часть самого экрана, отдельной секции «services» больше нет.)
export const SECTIONS = ['stage', 'how', 'about', 'self', 'contact', 'faq'];
export const FILE_EXT = ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'gif', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'rtf', 'odt', 'zip', 'mp4'];
export const BLOCK_ID = /^b-[a-z0-9]{4,20}$/;
export const PAGE_ID = /^p-[a-z0-9]{4,20}$/;
export const BLOCK_TYPES = ['text', 'cards', 'steps', 'faq', 'gallery', 'video', 'cta', 'table'];
// Адреса, занятые сайтом: своя страница не должна их перекрыть.
export const RESERVED_SLUGS = new Set(['admin', 'api', 'assets', 'fonts', 'media', 'files', 'legal', 'prices', 'robot', 'self', 'tj', 'kz', 'kg', 'uz']);
export const DEFAULT_THEME = { gold: '#E8C27A', goldHi: '#F3D58F', bg: '#060606', text: '#F5F2EC', muted: '#B8B3A9' };
export const DEFAULT_SETTINGS = { phone: '+7 977 123-88-98', telegram: 'https://t.me/Lawyer_RVP', whatsapp: 'https://wa.me/79771238898', max: '', theme: {}, customCss: '', menu: [], announce: { enabled: false, text: {}, href: '' }, noindex: false };

const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
export function getAt(obj, path) {
  return path.split('.').reduce((o, k) => (o == null ? undefined : o[/^\d+$/.test(k) && Array.isArray(o) ? Number(k) : k]), obj);
}
export function setAt(obj, path, value) {
  const keys = path.split('.');
  let o = obj;
  for (const k of keys.slice(0, -1)) { if (o[k] == null) return false; o = o[k]; }
  o[keys[keys.length - 1]] = value;
  return true;
}
// Тип значения совпадает с исходным: строка → строка, список → список (длина может меняться), число → число.
export function sameShape(def, val) {
  if (typeof def === 'string') return typeof val === 'string';
  if (typeof def === 'number') return typeof val === 'number' && Number.isFinite(val);
  if (Array.isArray(def)) {
    if (!Array.isArray(val)) return false;
    const sample = def[0];
    return sample === undefined ? val.every((x) => typeof x === 'string') : val.every((x) => sameShape(sample, x));
  }
  if (isObj(def)) return isObj(val) && Object.keys(def).every((k) => k in val && sameShape(def[k], val[k]));
  return false;
}
// Пути, которые нельзя менять из панели: служебные (адрес страницы, код языка).
export const LOCKED = new Set(['code', 'path']);

export function applyTexts(L, patches) {
  const skipped = [];
  for (const lang of LANGS) {
    for (const [path, val] of Object.entries(patches?.[lang] || {})) {
      const def = getAt(L[lang], path);
      if (LOCKED.has(path) || def === undefined || !sameShape(def, val)) { skipped.push(`${lang}:${path}`); continue; }
      setAt(L[lang], path, val);
    }
  }
  return skipped;
}

async function json(file, dflt) {
  try { return JSON.parse(await readFile(file, 'utf8')); } catch (e) { if (e.code === 'ENOENT') return dflt; throw new Error(`${file}: ${e.message}`); }
}
export async function loadContent(dir) {
  if (!dir) return { texts: {}, blocks: [], layout: null, legal: null, prices: null, shop: null, pages: [], settings: null, filesDir: null };
  return {
    texts: await json(join(dir, 'texts.json'), {}),
    blocks: await json(join(dir, 'blocks.json'), []),
    layout: await json(join(dir, 'layout.json'), null),
    legal: await json(join(dir, 'legal.json'), null),
    prices: await json(join(dir, 'prices.json'), null),
    shop: await json(join(dir, 'shop-products.json'), null),
    pages: await json(join(dir, 'pages.json'), []),
    settings: await json(join(dir, 'settings.json'), null),
    filesDir: join(dir, 'files')
  };
}

// Порядок секций: сохранённый порядок + новые секции/блоки, которых в нём ещё нет.
export function sectionOrder(layout, blocks) {
  const all = [...SECTIONS, ...blocks.map((b) => b.id)];
  const saved = (layout?.order || []).filter((id) => all.includes(id));
  for (const id of all) if (!saved.includes(id)) saved.push(id);
  const hidden = new Set(layout?.hidden || []);
  return saved.filter((id) => !hidden.has(id));
}

// Проверка блока из панели. Тексты — по языкам ({ ru, tg, … }); ru обязателен для заголовка.
const str = (v, max) => typeof v === 'string' && v.length <= max;
const ml = (v, max, need) => isObj(v) && Object.entries(v).every(([k, s]) => LANGS.includes(k) && str(s, max)) && (!need || (v.ru && v.ru.trim()));
const safeHref = (h) => typeof h === 'string' && h.length <= 500 && /^(https:\/\/|http:\/\/|\/|#|tel:|mailto:)/.test(h) && !/^\/\//.test(h);
export function validBlock(b) {
  return isObj(b) && BLOCK_ID.test(b.id) && ml(b.title, 200, true) && (b.eyebrow == null || ml(b.eyebrow, 80)) && (b.text == null || ml(b.text, 8000))
    && (b.image == null || b.image === '' || (typeof b.image === 'string' && /^\/files\/[^/]+$/.test(b.image))) && (b.imageAlt == null || ml(b.imageAlt, 200))
    && (b.buttons == null || (Array.isArray(b.buttons) && b.buttons.length <= 4 && b.buttons.every((x) => isObj(x) && ml(x.label, 60, true) && safeHref(x.href))))
    && (b.files == null || (Array.isArray(b.files) && b.files.length <= 20 && b.files.every((x) => isObj(x) && ml(x.label, 120, true) && typeof x.href === 'string' && /^\/files\/[^/]+$/.test(x.href))))
    && (b.style == null || ['plain', 'card'].includes(b.style))
    && (b.type == null || BLOCK_TYPES.includes(b.type))
    && (b.video == null || b.video === '' || (typeof b.video === 'string' && /^\/files\/[^/]+\.mp4$/i.test(b.video)))
    && (b.items == null || (Array.isArray(b.items) && b.items.length <= 40 && b.items.every(validItem)));
}
const fileRef = (v) => v == null || v === '' || (typeof v === 'string' && /^\/files\/[^/]+$/.test(v));
const validItem = (x) => isObj(x) && (x.title == null || ml(x.title, 300)) && (x.text == null || ml(x.text, 4000)) && fileRef(x.image);

export function validPage(p) {
  return isObj(p) && PAGE_ID.test(p.id) && typeof p.slug === 'string' && /^[a-z0-9][a-z0-9-]{0,60}$/.test(p.slug) && !RESERVED_SLUGS.has(p.slug)
    && ml(p.title, 200, true) && (p.desc == null || ml(p.desc, 300)) && Array.isArray(p.blocks) && p.blocks.length <= 40 && p.blocks.every(validBlock)
    && ['inMenu', 'hidden', 'noindex'].every((k) => p[k] == null || typeof p[k] === 'boolean');
}

const HEX = /^#[0-9a-fA-F]{6}$/;
// Возвращает текст ошибки или '' — настройки подходят.
export function settingsError(s) {
  if (!isObj(s)) return 'неверный формат настроек';
  const digits = String(s.phone || '').replace(/\D/g, '');
  if (typeof s.phone !== 'string' || s.phone.length > 30 || digits.length < 10 || digits.length > 15) return 'телефон: от 10 до 15 цифр';
  if (typeof s.telegram !== 'string' || !/^https:\/\/t\.me\/[\w+]{3,64}$/.test(s.telegram)) return 'Telegram: ссылка вида https://t.me/имя';
  if (typeof s.whatsapp !== 'string' || !/^https:\/\/wa\.me\/\d{10,15}$/.test(s.whatsapp)) return 'WhatsApp: ссылка вида https://wa.me/79001234567';
  if (s.max != null && s.max !== '' && (typeof s.max !== 'string' || !/^https:\/\/max\.ru\/[\w\-./?=&%+]{1,200}$/.test(s.max))) return 'MAX: ссылка вида https://max.ru/… или пусто';
  if (!isObj(s.theme) || !Object.entries(s.theme).every(([k, v]) => k in DEFAULT_THEME && HEX.test(v))) return 'цвета: формат #RRGGBB';
  if (typeof s.customCss !== 'string' || s.customCss.length > 100000) return 'своё CSS: не больше 100 000 знаков';
  if (!Array.isArray(s.menu) || s.menu.length > 8 || !s.menu.every((x) => isObj(x) && ml(x.label, 60, true) && safeHref(x.href))) return 'меню: у пункта нужны название на русском и ссылка';
  const a = s.announce;
  if (!isObj(a) || typeof a.enabled !== 'boolean' || !ml(a.text, 300) || (a.href !== '' && !safeHref(a.href)) || (a.enabled && !(a.text.ru || '').trim())) return 'объявление: нужен текст на русском и верная ссылка';
  if (typeof s.noindex !== 'boolean') return 'noindex';
  return '';
}
export function themeCss(theme) {
  const t = { ...DEFAULT_THEME, ...theme };
  if (Object.keys(DEFAULT_THEME).every((k) => t[k].toLowerCase() === DEFAULT_THEME[k].toLowerCase())) return '';
  return `:root{--gold:${t.gold};--gold-hi:${t.goldHi};--gold-btn:linear-gradient(180deg,${t.goldHi} 0%,${t.gold} 100%);--bg:${t.bg};--text:${t.text};--muted:${t.muted}}\n`;
}

// Простая разметка текста блока: пустая строка — новый абзац, «- » — пункт списка,
// **жирный**, [текст](ссылка). Всё остальное экранируется.
const escH = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
function inline(s) {
  return escH(s)
    .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
    .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (m, t, h) => {
      const href = h.replace(/&amp;/g, '&');
      if (!safeHref(href)) return t;
      const ext = /^https?:/.test(href);
      return `<a href="${escH(href)}"${ext ? ' rel="noopener" target="_blank"' : ''}>${t}</a>`;
    });
}
export function richText(text) {
  return String(text || '').trim().split(/\n\s*\n/).map((para) => {
    const lines = para.split('\n').map((l) => l.trim()).filter(Boolean);
    if (lines.length && lines.every((l) => /^[-•]\s+/.test(l))) return `<ul class="cb-list">${lines.map((l) => `<li>${inline(l.replace(/^[-•]\s+/, ''))}</li>`).join('')}</ul>`;
    return `<p>${lines.map(inline).join('<br>')}</p>`;
  }).join('\n');
}
