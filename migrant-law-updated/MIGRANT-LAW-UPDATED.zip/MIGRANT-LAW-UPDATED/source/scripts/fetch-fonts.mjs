// Скачивает шрифты с Google Fonts и складывает их локально (src/fonts + src/fonts.css),
// чтобы сайт не зависел от fonts.googleapis.com. Запускать вручную при смене шрифтов.
import { writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const CSS_URL = 'https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36';
const KEEP = new Set(['cyrillic', 'cyrillic-ext', 'latin', 'latin-ext']);

const root = new URL('../src/', import.meta.url);
await mkdir(new URL('fonts/', root), { recursive: true });

const css = await (await fetch(CSS_URL, { headers: { 'User-Agent': UA } })).text();
const blocks = [...css.matchAll(/\/\*\s*([\w-]+)\s*\*\/\s*(@font-face\s*{[^}]+})/g)];
let out = '';
for (const [, subset, block] of blocks) {
  if (!KEEP.has(subset)) continue;
  const url = block.match(/url\((https:[^)]+\.woff2)\)/)[1];
  const family = block.match(/font-family:\s*'([^']+)'/)[1].replace(/\s+/g, '');
  const buf = Buffer.from(await (await fetch(url)).arrayBuffer());
  const name = `${family}-${subset}-${createHash('sha1').update(buf).digest('hex').slice(0, 8)}.woff2`;
  await writeFile(new URL(`fonts/${name}`, root), buf);
  out += `/* ${subset} */\n` + block.replace(/url\([^)]+\)/, `url(/fonts/${name})`) + '\n';
}
await writeFile(new URL('fonts.css', root), out);
console.log('шрифтов:', out.split('@font-face').length - 1);
