#!/bin/sh
# Включает www.sverify.online после того, как в Cloudflare появилась запись www:
# расширяет сертификат на www и добавляет в Caddy переадресацию www → sverify.online.
set -e
cd "$(dirname "$0")/.."
# Проверяем, что www доходит до этого сервера (файл в webroot certbot отдаётся по http).
probe=www-probe-$$
echo ok > /var/www/certbot/.well-known/acme-challenge/$probe
code=$(curl -s -m 10 -o /dev/null -w '%{http_code}' http://www.sverify.online/.well-known/acme-challenge/$probe || true)
rm -f /var/www/certbot/.well-known/acme-challenge/$probe
[ "$code" = 200 ] || { echo "www.sverify.online ещё не ведёт на сервер (код $code)"; exit 1; }
certbot certonly --webroot -w /var/www/certbot --cert-name sverify.online -d sverify.online -d www.sverify.online \
  --expand --non-interactive --agree-tos --register-unsafely-without-email --deploy-hook /usr/local/bin/sverify-cert-deploy.sh
if ! grep -q 'https://www.sverify.online' deploy/sverify.online.conf; then
  cat >> deploy/sverify.online.conf <<'CONF'

https://www.sverify.online {
	tls /etc/caddy/certs/sverify.online/fullchain.pem /etc/caddy/certs/sverify.online/privkey.pem
	redir https://sverify.online{uri} permanent
}
CONF
fi
install -m 0644 deploy/sverify.online.conf /etc/caddy/sites/sverify.online.conf
chown caddy:caddy /var/log/caddy/*.log
systemctl reload caddy
sleep 2
curl -s -o /dev/null -w 'https://www.sverify.online → %{http_code} %{redirect_url}\n' https://www.sverify.online/
