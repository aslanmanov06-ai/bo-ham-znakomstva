#!/bin/sh
# Выкладка sverify.online: код сайта, сервер заявок, админ-панель, конфиг Caddy.
# Сайт собирается так же, как при публикации из админ-панели: в рабочей копии /var/lib/sverify-admin/site
# с правками владельца (/var/lib/sverify-admin/content) — поэтому обновление кода их не затирает.
set -e
cd "$(dirname "$0")/.."
REPO=$(pwd)
A=/var/lib/sverify-admin
WWW=/var/www/sverify.online

# Пользователь админ-панели и общий токен внутреннего API (сервер заявок ↔ панель).
id sverify-admin >/dev/null 2>&1 || useradd --system --home-dir "$A" --no-create-home --shell /usr/sbin/nologin sverify-admin
mkdir -p /etc/sverify && chmod 0700 /etc/sverify
[ -f /etc/sverify/internal.env ] || (umask 077; echo "INTERNAL_TOKEN=$(openssl rand -hex 32)" > /etc/sverify/internal.env)

# Рабочая копия сайта (без git и результатов сборки); журнал версий согласия — общий с репозиторием.
mkdir -p "$A/site" "$A/content/files" "$A/releases" "$WWW"
rsync -a --delete --exclude .git --exclude dist --exclude screens --exclude build --exclude legal-archive --exclude node_modules "$REPO/" "$A/site/"
mkdir -p "$A/site/legal-archive" && rsync -a "$REPO/legal-archive/" "$A/site/legal-archive/"
chown -R sverify-admin:sverify-admin "$A" "$WWW"
chmod 0755 "$A"
[ -f "$A/auth.json" ] && chmod 0600 "$A/auth.json"

# Сборка от имени панели с правками владельца.
runuser -u sverify-admin -- env CONTENT_DIR="$A/content" node "$A/site/scripts/build.mjs"
rsync -a "$A/site/legal-archive/" "$REPO/legal-archive/"
runuser -u sverify-admin -- rsync -a --delete --delay-updates "$A/site/dist/" "$WWW/"
chmod -R a+rX "$WWW"

# Сервер заявок.
install -D -m 0644 server/lead-server.mjs /opt/sverify-leads/lead-server.mjs
install -m 0644 server/shop.mjs /opt/sverify-leads/shop.mjs
install -m 0644 server/internal.mjs /opt/sverify-leads/internal.mjs
install -m 0644 server/settings-env.mjs /opt/sverify-leads/settings-env.mjs
install -m 0644 src/shop-products.json /opt/sverify-leads/shop-products.json
install -m 0644 deploy/sverify-leads.service /etc/systemd/system/sverify-leads.service
# Админ-панель.
install -D -m 0644 server/admin.mjs /opt/sverify-admin/admin.mjs
install -m 0644 deploy/sverify-admin.service /etc/systemd/system/sverify-admin.service
systemctl daemon-reload
systemctl enable --now sverify-leads >/dev/null 2>&1
systemctl restart sverify-leads
systemctl enable --now sverify-admin >/dev/null 2>&1
systemctl restart sverify-admin

install -m 0644 deploy/sverify.online.conf /etc/caddy/sites/sverify.online.conf
touch /var/log/caddy/sverify.access.log && chown caddy:caddy /var/log/caddy/sverify.access.log
systemctl reload caddy
[ -f "$A/auth.json" ] || echo "⚠ пароль админ-панели не задан: node scripts/admin-passwd.mjs"
echo "выложено: https://sverify.online (панель: https://sverify.online/admin/)"
