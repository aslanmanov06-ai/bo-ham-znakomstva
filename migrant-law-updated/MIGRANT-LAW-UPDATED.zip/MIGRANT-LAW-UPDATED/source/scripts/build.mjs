// Сборка сайта: из шаблона и src/i18n.json получаются статические страницы
// для каждого языка (ru — в корне, остальные в /tj/, /kz/, /kg/, /uz/).
// Файлы со стилями и скриптом получают хэш в имени, чтобы их можно было кэшировать навсегда.
import { readFile, writeFile, mkdir, rm, cp } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { makeLegal } from './legal.mjs';
import { pathToFileURL } from 'node:url';
import { loadContent, applyTexts, sectionOrder, validBlock, validPage, richText, settingsError, themeCss, DEFAULT_SETTINGS, LANGS as CLANGS } from './content.mjs';

const ROOT = new URL('../', import.meta.url);
const SRC = new URL('src/', ROOT);
// Предпросмотр из панели собирается в отдельный каталог и не трогает журнал согласий и справку Migrant AI.
const PREVIEW = process.env.PREVIEW === '1';
const DIST = process.env.DIST_DIR ? pathToFileURL(process.env.DIST_DIR.replace(/\/?$/, '/')) : new URL('dist/', ROOT);
const SITE = 'https://sverify.online';
const ORDER = ['ru', 'tg', 'kk', 'ky', 'uz'];
const STATIONS = ['uchet', 'patent', 'rvp', 'vnzh', 'grazh', 'problem'];

// Правки из админ-панели (CONTENT_DIR, см. scripts/content.mjs) — поверх исходников из src/.
const CONTENT = await loadContent(process.env.CONTENT_DIR || '');
const SETTINGS = { ...DEFAULT_SETTINGS, ...(CONTENT.settings || {}) };
if (settingsError(SETTINGS)) throw new Error(`настройки сайта: ${settingsError(SETTINGS)}`);
const PHONE = SETTINGS.phone;
const TEL = `+${PHONE.replace(/\D/g, '')}`;
const TG = SETTINGS.telegram;
const WA = SETTINGS.whatsapp;
const PRICES = CONTENT.prices || JSON.parse(await readFile(new URL('prices.json', SRC), 'utf8'));
// Инструкции «Оформите документы самостоятельно»: значения по умолчанию. На сервере цены и тексты берутся из
// /var/lib/sverify/shop/products.json (меняет администратор), страница подтягивает их при загрузке.
const SHOP = (CONTENT.shop?.products?.length ? CONTENT.shop : JSON.parse(await readFile(new URL('shop-products.json', SRC), 'utf8'))).products.filter((p) => p.active !== false);
const L = JSON.parse(await readFile(new URL('i18n.json', SRC), 'utf8'));
{
  const skipped = applyTexts(L, CONTENT.texts);
  if (skipped.length) console.warn('⚠ правки текстов пропущены (нет такого поля или другой тип):', skipped.join(', '));
}
const LEGAL = JSON.parse(await readFile(new URL('legal.json', SRC), 'utf8'));
for (const [key, val] of Object.entries(CONTENT.legal || {})) if (key in LEGAL && typeof val === typeof LEGAL[key]) LEGAL[key] = val;
// Новые блоки из панели и порядок секций главной.
const BLOCKS = (CONTENT.blocks || []).filter((b) => { const ok = validBlock(b); if (!ok) console.warn('⚠ блок пропущен (неверный формат):', b && b.id); return ok; });
const ORDER_MAIN = sectionOrder(CONTENT.layout, BLOCKS);
// Свои страницы из конструктора. Черновики (hidden) попадают только в предпросмотр.
const PAGES = (CONTENT.pages || []).filter((p) => { const ok = validPage(p); if (!ok) console.warn('⚠ страница пропущена (неверный формат):', p && p.slug); return ok && (PREVIEW || !p.hidden); });
const { docs: DOCS, missing: MISSING } = makeLegal(LEGAL, SITE);
const DOC_ORDER = ['privacy', 'consent', 'cookies', 'terms', 'offer', 'requisites', 'withdraw'];
const CONSENT_SHA = createHash('sha256').update(DOCS.consent.html).digest('hex');

const nb = (s) => String(s).replace(/ —/g, '\u00a0—');
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const hash = (buf) => createHash('sha256').update(buf).digest('hex').slice(0, 10);

await rm(DIST, { recursive: true, force: true });
await mkdir(new URL('assets/', DIST), { recursive: true });
await cp(new URL('fonts/', SRC), new URL('fonts/', DIST), { recursive: true });

const css = (await readFile(new URL('fonts.css', SRC), 'utf8')) + '\n' + (await readFile(new URL('styles.css', SRC), 'utf8')) + '\n' + themeCss(SETTINGS.theme) + SETTINGS.customCss;
const cssName = `site.${hash(css)}.css`;
await writeFile(new URL(`assets/${cssName}`, DIST), css);
const js = await readFile(new URL('app.js', SRC), 'utf8');
const jsName = `app.${hash(js)}.js`;
await writeFile(new URL(`assets/${jsName}`, DIST), js);
await cp(new URL('favicon.svg', SRC), new URL('favicon.svg', DIST));
await cp(new URL('media/', SRC), new URL('media/', DIST), { recursive: true });
if (CONTENT.filesDir) await cp(CONTENT.filesDir, new URL('files/', DIST).pathname, { recursive: true }).catch((e) => { if (e.code !== 'ENOENT') throw e; });
// Глобус первого экрана: точки материков (scripts/make-globe.mjs) + отрисовка (src/globe.js).
const globe = `const GLOBE_DOTS=${(await readFile(new URL('globe-dots.json', SRC), 'utf8')).trim()};\n` + (await readFile(new URL('globe.js', SRC), 'utf8'));
const globeName = `globe.${hash(globe)}.js`;
await writeFile(new URL(`assets/${globeName}`, DIST), globe);
// 3D-робот Migrant AI (Spline): рантайм и сцена с нашего сервера. Рантайм по умолчанию берёт process.wasm с unpkg —
// подменяем адрес на наш /assets/spline-…/ (vendor/spline-1.9.98/README.md).
const SPLINE_DIR = 'spline-1.9.98';
const VENDOR = new URL(`vendor/${SPLINE_DIR}/`, ROOT);
await mkdir(new URL(`assets/${SPLINE_DIR}/`, DIST), { recursive: true });
{
  const UNPKG = '"https://unpkg.com/@splinetool/modelling-wasm@1.9.98/build"';
  const rt = await readFile(new URL('runtime.js', VENDOR), 'utf8');
  if (rt.split(UNPKG).length !== 2) throw new Error('spline runtime: не найден адрес process.wasm');
  await writeFile(new URL(`assets/${SPLINE_DIR}/runtime.js`, DIST), rt.replace(UNPKG, `"/assets/${SPLINE_DIR}"`));
  for (const f of ['process.js', 'process.wasm', 'robot.splinecode']) await cp(new URL(f, VENDOR), new URL(`assets/${SPLINE_DIR}/${f}`, DIST));
}
// Робот показывается в iframe /robot/: только там CSP разрешает 'unsafe-eval', который нужен рантайму Spline.
{
  const rjs = await readFile(new URL('robot.js', SRC), 'utf8');
  const rcss = 'html,body{margin:0;height:100%;background:transparent;overflow:hidden}canvas{display:block;width:100%;height:100%;outline:none}\n';
  const rjsName = `robot.${hash(rjs)}.js`, rcssName = `robot.${hash(rcss)}.css`;
  await writeFile(new URL(`assets/${rjsName}`, DIST), rjs);
  await writeFile(new URL(`assets/${rcssName}`, DIST), rcss);
  await mkdir(new URL('robot/', DIST), { recursive: true });
  await writeFile(new URL('robot/index.html', DIST), `<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Migrant AI</title>
<link rel="stylesheet" href="/assets/${rcssName}">
<script type="module" src="/assets/${rjsName}"></script>
</head>
<body><canvas id="robot"></canvas></body>
</html>
`);
}
const PR = L._prices;
const PRELOAD = [...new Set(css.match(/Montserrat-cyrillic-[0-9a-f]+\.woff2/g) || [])].map((f) => `<link rel="preload" href="/fonts/${f}" as="font" type="font/woff2" crossorigin>`).join('');
const rub = (n) => n.toLocaleString('ru-RU').replace(/\u00a0/g, ' ');
// Ситуации «У меня…» по порядку из i18n (j.sits / j.plans): ключ для заявки и услуга прайса, чья цена «от» показывается в плане.
const SITUATIONS = [
  { stage: 'uchet', item: 'Подготовка уведомления о прибытии (постановка на миграционный учёт)' },
  { stage: 'patent', item: 'Подготовка документов на продление патента' },
  { stage: 'rvp', item: 'Подготовка документов для получения РВП' },
  { stage: 'vnzh', item: 'Подготовка документов для получения ВНЖ' },
  { stage: 'grazh', item: 'Подготовка документов на гражданство России' },
  { stage: 'problem', item: 'Проверка нахождения в реестре контролируемых лиц (РКЛ)' },
  { stage: 'urgent', item: 'Срочная консультация при задержании или проверке', urgent: true },
  { stage: 'help', item: 'Юридический разбор миграционной ситуации' }
];
const DEFAULT_SITUATION = 2; // РВП — самый частый запрос
// Страна в «Найти свой этап»: от неё зависят варианты. Граждане ЕАЭС (Казахстан, Кыргызстан) работают без патента —
// вместо «нужен патент» показывается работа по трудовому договору, а в учёте — 30 дней без регистрации.
const COUNTRIES = ['tj', 'uz', 'kg', 'kz', 'md', 'other'];
const EAEU = ['kg', 'kz'];
const LANG_COUNTRY = { tg: 'tj', uz: 'uz', ky: 'kg', kk: 'kz' }; // по языку страницы страна выбрана сразу; на русском — нет
const EAEU_WORK = { stage: 'eaeu', item: 'Подготовка уведомления МВД о заключении трудового договора с иностранцем' };
const ITEM_PRICE = new Map(PRICES.blocks.flatMap((b) => b.items.map(([, name, price]) => [name, price])));
for (const p of SHOP) for (const item of p.lawyer) if (!ITEM_PRICE.has(item)) throw new Error(`shop-products.json: нет услуги в прайсе: ${item}`);
const LAW_MAX = 120000; // «под ключ» с юристом — до 120 000 ₽, зависит от сложности дела
const SHOP_ICON = {
  grazh: 'M12 3l7 3v5c0 4.4-3 8.4-7 10-4-1.6-7-5.6-7-10V6l7-3zM9 12l2 2 4-4',
  vnzh: 'M4 11l8-6 8 6M6 10v9h12v-9M10 19v-5h4v5',
  rvp: 'M7 3h7l4 4v14H7zM14 3v4h4M10 12h5M10 16h5'
};
for (const s of SITUATIONS) if (!ITEM_PRICE.has(s.item)) throw new Error(`нет услуги в прайсе: ${s.item}`);
const SERVICES_TOTAL = PRICES.blocks.reduce((n, b) => n + b.items.length, 0);

const ICON = {
  globe: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 3 2.6 15 0 18M12 3c-2.6 3-2.6 15 0 18"/></svg>',
  chevron: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>',
  next: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>',
  arrow: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  close: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  burger: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
  phone: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1z"/></svg>',
  pin: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>',
  calendar: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M8 14h2M12 14h2M8 17h2M12 17h2"/></svg>',
  bag: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 4h8l1 3H7zM5 7h14v13H5z"/><path d="M9 12h6M9 16h4"/></svg>',
  check: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5L20 7"/></svg>'
};
// Иконки преимуществ первого экрана: место, язык, цена.
const PERK_ICONS = [
  'M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11zM12 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z',
  'M3 5h11v8H8l-3 3v-3H3zM10 13v3h6l3 3v-3h2V9h-7',
  'M4 7c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 7v5c0 1.7 3.6 3 8 3s8-1.3 8-3V7M4 12v5c0 1.7 3.6 3 8 3s8-1.3 8-3v-5'
];
const svg = (d, size = 24, sw = 1.6) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${d}"/></svg>`;
// Цветные значки мессенджеров в подвале. У MAX ссылки по умолчанию нет (настройка «max» в панели) — тогда значок не кликается.
const SOCIAL = {
  telegram: '<svg width="44" height="44" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="#fff"/><path fill="#27A7E7" d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>',
  whatsapp: '<svg width="44" height="44" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="12" fill="#25D366"/><path fill="#fff" transform="translate(4.2 4.1) scale(.65)" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>',
  max: '<svg width="44" height="44" viewBox="0 0 24 24" aria-hidden="true"><defs><linearGradient id="mxg" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#3FB4FF"/><stop offset=".55" stop-color="#5A5CFF"/><stop offset="1" stop-color="#A44DFF"/></linearGradient></defs><rect width="24" height="24" rx="7" fill="url(#mxg)"/><path fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" d="M7.2 17.6V7.4l4.8 5.4 4.8-5.4v10.2"/></svg>'
};
// Иконки фактов «О нас»: место, язык, конфиденциальность, цена.
const FACT_ICONS = [
  'M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11zM12 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z',
  'M4 5h16v10H9l-5 4zM8 9h8M8 12h5',
  'M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3',
  'M4 7h16v12H4zM4 11h16M8 15h3'
];
// Фирменная эмблема (из логотипа владельца) и название.
const LOGO = (size = 56) => `<img class="logo-emb" src="/media/emblem-112.webp" srcset="/media/emblem-112.webp 1x, /media/emblem-224.webp 2x" width="${size}" height="${size}" alt="">`;
const LOGO_NAME = '<span class="logo-name">Migrant-law.ru</span>';
const gold = (parts) => `${esc(nb(parts[0]))}<span class="gold">${esc(parts[1])}</span>${esc(parts[2] || '')}`;

function requisitesLine() {
  const parts = [LEGAL.operatorFullName, LEGAL.inn && `ИНН ${LEGAL.inn}`, LEGAL.ogrn && `${LEGAL.ogrnLabel} ${LEGAL.ogrn}`, LEGAL.address, LEGAL.email].filter(Boolean);
  return parts.length ? parts.join(' · ') : '[ЗАПОЛНИТЬ: реквизиты владельца сайта — src/legal.json]';
}
// Содержимое блока по его типу: карточки, шаги, вопросы, галерея, видео, таблица.
function blockExtra(b, type, tr) {
  const items = b.items || [];
  const pic = (x) => (x.image ? `<img src="${esc(x.image)}" alt="${esc(tr(x.title))}" loading="lazy" decoding="async">` : '');
  if (type === 'cards') return `<div class="cb-grid">${items.map((x) => `<article class="cb-card">${pic(x)}<h3>${esc(tr(x.title))}</h3><div class="cb-body">${richText(tr(x.text))}</div></article>`).join('')}</div>`;
  if (type === 'steps') return `<ol class="cb-steps">${items.map((x) => `<li><h3>${esc(tr(x.title))}</h3><div class="cb-body">${richText(tr(x.text))}</div></li>`).join('')}</ol>`;
  if (type === 'faq') return `<div class="cb-faq">${items.map((x) => `<details><summary>${esc(tr(x.title))}</summary><div class="cb-body">${richText(tr(x.text))}</div></details>`).join('')}</div>`;
  if (type === 'gallery') return `<div class="cb-gallery">${items.filter((x) => x.image).map((x) => `<figure>${pic(x)}${tr(x.title) ? `<figcaption>${esc(tr(x.title))}</figcaption>` : ''}</figure>`).join('')}</div>`;
  if (type === 'video' && b.video) return `<video class="cb-video" src="${esc(b.video)}" controls preload="metadata"></video>`;
  if (type === 'table') return `<div class="cb-table-wrap"><table class="cb-table"><tbody>${items.map((x) => `<tr><th scope="row">${esc(tr(x.title))}</th><td>${esc(tr(x.text))}</td></tr>`).join('')}</tbody></table></div>`;
  return '';
}
const pageHref = (p, code) => `${L[code].path}${p.slug}/`;
function announceBar(code) {
  const a = SETTINGS.announce;
  const text = a.enabled && (a.text[code] || a.text.ru);
  if (!text) return '';
  return `<div class="announce">${a.href ? `<a href="${esc(a.href)}">${esc(text)}</a>` : esc(text)}</div>`;
}
// Новый блок из админ-панели: надзаголовок, заголовок, текст (абзацы, списки, ссылки), картинка, кнопки, файлы.
function blockHtml(b, code) {
  if (!b) return '';
  const tr = (v) => (v && (v[code] || v.ru)) || '';
  const title = tr(b.title);
  const img = b.image ? `<figure class="cb-img"><img src="${esc(b.image)}" alt="${esc(tr(b.imageAlt))}" loading="lazy" decoding="async"></figure>` : '';
  const buttons = (b.buttons || []).map((x, i) => `<a class="btn ${i ? 'btn-line' : 'btn-gold'}" href="${esc(x.href)}"${/^https?:/.test(x.href) ? ' rel="noopener" target="_blank"' : ''}>${esc(tr(x.label))}</a>`).join('');
  const files = (b.files || []).map((x) => `<li><a href="${esc(x.href)}" download>${ICON.next}<span>${esc(tr(x.label))}</span></a></li>`).join('');
  const type = b.type || 'text';
  const extra = blockExtra(b, type, tr);
  return `<section id="${b.id}" class="wrap section cblock cblock-${type}${b.style === 'card' || type === 'cta' ? ' cblock-card' : ''}${img ? ' has-img' : ''}">
<div class="cb-in">
<div class="cb-text">
${tr(b.eyebrow) ? `<p class="eyebrow">${esc(tr(b.eyebrow))}</p>` : ''}<h2 class="h2">${esc(title)}</h2>
${tr(b.text) ? `<div class="cb-body">${richText(tr(b.text))}</div>` : ''}
${extra}
${files ? `<ul class="cb-files">${files}</ul>` : ''}
${buttons ? `<div class="cb-actions">${buttons}</div>` : ''}
</div>
${img}
</div>
</section>`;
}

// Раздел «Оформите документы самостоятельно»: карточки, сравнение с юристом, окно с анкетой и заказом.
const HELP_ICON = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M8 9h8M8 13h5"/></svg>';
function shopSection(code) {
  const t = L[code];
  const s = t.k.shop;
  const j = t.j;
  const rubs = (n) => `${rub(n)} ₽`;
  const tx = (p) => Object.assign({}, p.t.ru, p.t[code]);
  const minSelf = Math.min(...SHOP.map((p) => p.price));
  const minLaw = Math.min(...SHOP.map((p) => p.lawyer.reduce((a, item) => a + ITEM_PRICE.get(item), 0)));
  const cards = SHOP.map((p) => {
    const x = tx(p);
    return `<article class="shop-card" data-p="${p.id}">
<div class="shop-top"><span class="shop-ico" aria-hidden="true"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="${SHOP_ICON[p.id] || SHOP_ICON.rvp}"/></svg></span><p class="shop-price">${esc(rubs(p.price))}</p></div>
<h3 class="shop-title">${esc(x.title)}</h3>
<p class="shop-short">${esc(x.short)}</p>
<button type="button" class="btn btn-gold shine shop-buy" data-p="${p.id}">${esc(s.buy)}</button>
<button type="button" class="btn btn-line shop-more">${esc(s.more)}</button>
<p class="shop-fmt">${esc(s.format)}</p>
<p class="shop-mini">${HELP_ICON}<span><b>${esc(s.helpTitle)}.</b> ${esc(s.help[1])} ${esc(s.helpScope)}</span></p>
<dialog class="shop-dlg info-dlg" aria-labelledby="info-${p.id}">
<div class="dlg-in">
<button type="button" class="dlg-x" aria-label="${esc(s.close)}">${ICON.close}</button>
<div class="info-head"><h3 class="dlg-h info-title" id="info-${p.id}">${esc(x.title)}</h3><p class="shop-price info-price">${esc(rubs(p.price))}</p></div>
<div class="info-cols">
<div class="info-col">
<p class="shop-inc-t">${esc(s.includes)}</p>
<ul class="shop-inc">${x.includes.map((i) => `<li>${ICON.check}<span>${esc(i)}</span></li>`).join('')}</ul>
${x.note ? `<p class="shop-note">${esc(x.note)}</p>` : '<p class="shop-note" hidden></p>'}
</div>
<div class="info-col">
<aside class="shop-help" aria-label="${esc(s.helpTitle)}">
<p class="shop-help-t"><span class="shop-help-ico" aria-hidden="true">${HELP_ICON}</span>${esc(s.helpTitle)}</p>
${s.help.map((h) => `<p>${esc(h)}</p>`).join('')}
<p class="shop-help-note">${esc(s.helpNote)}</p>
<p class="shop-help-scope">${esc(s.helpScope)}</p>
</aside>
<details class="shop-get"><summary>${esc(s.getTitle)}<span class="plus" aria-hidden="true">+</span></summary><ol>${s.getItems.map((g) => `<li>${esc(g)}</li>`).join('')}</ol></details>
</div>
</div>
<button type="button" class="btn btn-gold shine info-buy" data-p="${p.id}">${esc(s.buy)}</button>
</div>
</dialog>
</article>`;
  }).join('\n');
  const pts = (a) => `<ul>${a.map((x) => `<li>${ICON.check}<span>${esc(x)}</span></li>`).join('')}</ul>`;
  const radios = (name, opts) => opts.map(([v, l]) => `<label class="qz-opt"><input type="radio" name="${name}" value="${v}"><span>${esc(l)}</span></label>`).join('');
  return `<section id="self" class="wrap section self">
<details class="self-fold" id="self-fold">
<summary class="self-sum"><span class="self-sum-t"><h2 class="h2">${gold(s.title)}</h2><span class="self-from" data-from>${esc(j.from.replace('%', rubs(minSelf)))}</span></span><span class="plus" aria-hidden="true">+</span></summary>
<div class="self-in">
<p class="sec-sub self-sub">${esc(s.sub)}</p>
<div class="shop-grid">
${cards}
</div>
<div class="shop-cmp">
<h3 class="cmp-title">${gold(s.cmpTitle)}</h3>
<div class="cmp-grid">
<div class="cmp-col"><p class="cmp-name">${esc(s.selfName)}</p><p class="cmp-price">${esc(j.from.replace('%', rubs(minSelf)))}</p>${pts(s.selfPoints)}<a class="btn btn-gold cmp-btn" href="#self">${esc(s.buy)}</a></div>
<div class="cmp-col cmp-law"><p class="cmp-name">${esc(s.lawName)}</p><p class="cmp-price">${esc(`${rub(minLaw)} – ${rubs(LAW_MAX)}`)}</p><p class="cmp-note">${esc(s.lawNote)}</p>${pts(s.lawPoints)}<a class="btn btn-line cmp-btn" href="#contact">${esc(s.consult)}</a></div>
</div>
</div>
<div class="shop-disc"><p class="shop-disc-t">${esc(s.legalTitle)}</p>${s.legal.map((x) => `<p>${esc(x)}</p>`).join('')}</div>
</div>
</details>
<dialog class="shop-dlg" id="shop-dlg" aria-labelledby="dlg-title">
<div class="dlg-in">
<button type="button" class="dlg-x" aria-label="${esc(s.close)}">${ICON.close}</button>
<p class="dlg-prod"><span class="dlg-pt"></span> · <b class="dlg-pp"></b></p>
<div class="dlg-step" data-step="quiz">
<h3 class="dlg-h" id="dlg-title">${esc(s.qTitle)}</h3>
<p class="dlg-sub">${esc(s.qSub)}</p>
<fieldset class="qz"><legend>${esc(s.q1)}</legend><div class="qz-row">${radios('q1', [['yes', s.yes], ['no', s.no], ['unsure', s.unsure]])}</div></fieldset>
<fieldset class="qz"><legend>${esc(s.q2)}</legend><div class="qz-row">${radios('q2', [['no', s.no], ['yes', s.yes]])}</div></fieldset>
<fieldset class="qz"><legend class="qz-q3"></legend><div class="qz-row">${radios('q3', [['yes', s.yes], ['no', s.no], ['unsure', s.unsure]])}</div></fieldset>
<button type="button" class="btn btn-gold dlg-next" disabled>${esc(s.next)}</button>
</div>
<div class="dlg-step" data-step="result" hidden>
<h3 class="dlg-h res-t"></h3>
<p class="res-x"></p>
<div class="dlg-actions"><button type="button" class="btn btn-gold res-go"></button><a class="btn btn-line dlg-consult" href="#contact">${esc(s.consult)}</a></div>
</div>
<form class="dlg-step shop-form" data-step="checkout" hidden novalidate>
<h3 class="dlg-h">${esc(s.coTitle)}</h3>
<label class="field">${esc(s.email)}<input type="email" name="email" autocomplete="email" inputmode="email" maxlength="120" required placeholder="name@example.ru"></label>
<label class="hp" aria-hidden="true">Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
<div class="check-box">
<label class="check"><input type="checkbox" name="consent" value="yes" required><span>${esc(t.cbBefore)}<a href="/legal/consent/" target="_blank" hreflang="ru">${esc(t.cbLink)}</a>${esc(t.cbAfter)}</span></label>
<label class="check"><input type="checkbox" name="offer" value="yes" required><span>${esc(s.offerBefore)}<a href="/legal/offer/" target="_blank" hreflang="ru">${esc(s.offerLink)}</a>${esc(s.offerAfter)}</span></label>
</div>
<p class="co-note">${esc(s.receipt)}</p>
<p class="form-error" role="alert"></p>
<p class="co-off" hidden>${esc(s.payOff)}</p>
<div class="dlg-actions"><button type="submit" class="btn btn-gold shine co-pay"></button><a class="btn btn-line dlg-consult co-consult" href="#contact" hidden>${esc(s.consult)}</a><button type="button" class="btn-text dlg-back">${esc(s.back)}</button></div>
</form>
</div>
</dialog>
</section>`;
}

function cookieBanner(t) {
  return `<div class="cookie" role="region" aria-label="Cookie" hidden><p>${esc(t.ckText)} <a href="/legal/cookies/" hreflang="ru">${esc(t.ckMore)}</a></p><button type="button" class="btn btn-light cookie-ok">${esc(t.ckOk)}</button></div>`;
}
function footer(t, tagline) {
  const soc = (key, name, href) => (href ? `<a class="soc" href="${esc(href)}" rel="noopener" target="_blank" aria-label="${name}" title="${name}">${SOCIAL[key]}</a>` : `<span class="soc soc-off" role="img" aria-label="${name}" title="${name}">${SOCIAL[key]}</span>`);
  return `<footer class="footer" id="contacts"><div class="wrap footer-in">
<div class="footer-top">
<a class="logo footer-logo" href="${t.path}" aria-label="${esc(t.brand1 + ' — ' + t.brand2)}">${LOGO(52)}${LOGO_NAME}</a>
<div class="footer-contact"><a class="footer-phone" href="tel:${TEL}">${PHONE}</a><div class="socials">${soc('telegram', 'Telegram', TG)}${soc('whatsapp', 'WhatsApp', WA)}${soc('max', 'MAX', SETTINGS.max)}</div></div>
</div>
<div class="footer-row"><span class="footer-brand"><span>${esc(t.ftCopy)} · ${esc(tagline)}</span></span>
<nav class="footer-docs" aria-label="${esc(t.docsTitle)}">${DOC_ORDER.map((k, i) => `<a href="/legal/${k}/" hreflang="ru">${esc(t.docs[i])}</a>`).join('')}</nav></div>
<p class="footer-req">${esc(requisitesLine())}</p>
</div></footer>`;
}
function langMenu(code, t) {
  const items = ORDER.map((c) => `<a href="${L[c].path}" hreflang="${L[c].code}" lang="${L[c].code}"${c === code ? ' aria-current="page"' : ''}><span>${esc(L[c].name)}</span><small>${L[c].short}</small></a>`).join('\n');
  return `<div class="lang">
<button type="button" class="lang-btn" aria-expanded="false" aria-controls="lang-menu" aria-label="${esc(t.langLabel)}: ${esc(t.name)}">${ICON.globe}<span>${t.short}</span>${ICON.chevron}</button>
<div class="lang-menu" id="lang-menu" hidden>
${items}
</div>
</div>`;
}

function page(code) {
  const t = L[code];
  const j = t.j;
  const k = t.k;
  const url = SITE + t.path;
  const alt = ORDER.map((c) => `<link rel="alternate" hreflang="${L[c].code}" href="${SITE}${L[c].path}">`).join('\n') + `\n<link rel="alternate" hreflang="x-default" href="${SITE}/">`;
  const price = (item) => j.from.replace('%', `${rub(ITEM_PRICE.get(item))} ₽`);
  const plans = SITUATIONS.map((s, i) => {
    const [title, lead, steps, bring] = j.plans[i];
    return { stage: s.stage, urgent: !!s.urgent, title, lead, steps, bring, price: price(s.item) };
  });
  const cty = k.cty;
  const [et, el, es, eb] = cty.plan;
  const eaeuPlans = plans.map((p, i) => (i === 0 ? { ...p, lead: cty.uchet } : i === 1 ? { stage: EAEU_WORK.stage, urgent: false, title: et, lead: el, steps: es, bring: eb, price: price(EAEU_WORK.item) } : p));
  const eaeuSits = j.sits.map((s, i) => (i === 1 ? cty.sit : s));
  const country = LANG_COUNTRY[code] || '';
  const isEaeu = EAEU.includes(country);
  const ctyNote = (c) => (!c ? '' : EAEU.includes(c) ? cty.eaeuNote : c === 'other' ? cty.otherNote : cty.patentNote);
  const flag = (c) => (c === 'other' ? `<span class="cty-flag cty-globe">${ICON.globe}</span>` : `<img class="cty-flag" src="/media/fl-${c}.webp" width="48" height="32" alt="" decoding="async">`);
  const ctyHtml = `<div class="cty" role="group" aria-labelledby="cty-l">
<p class="cty-l" id="cty-l">${esc(cty.label)}</p>
<div class="cty-list">${COUNTRIES.map((c, i) => `<button type="button" class="cty-b" data-c="${c}" aria-pressed="${c === country}">${flag(c)}<span>${esc(cty.names[i])}</span></button>`).join('')}</div>
<p class="cty-note" aria-live="polite">${esc(ctyNote(country))}</p>
</div>`;
  const shown = isEaeu ? eaeuPlans : plans;
  const cur = shown[DEFAULT_SITUATION];
  const sits = (isEaeu ? eaeuSits : j.sits).map((label, i) => `<button type="button" role="radio" class="sit${plans[i].urgent ? ' urgent' : ''}" data-i="${i}" aria-checked="${i === DEFAULT_SITUATION}" tabindex="${i === DEFAULT_SITUATION ? 0 : -1}"><span class="sit-n">${String(i + 1).padStart(2, '0')}</span><span class="sit-t">${esc(label)}</span>${ICON.next}</button>`).join('\n');
  // Секции регистрируются по ходу шаблона и выводятся в порядке из админ-панели (скрытые — не выводятся).
  const SEC = {};
  const sec = (id, html) => { SEC[id] = html; return ''; };
  const mainSections = () => ORDER_MAIN.map((id) => SEC[id] ?? blockHtml(BLOCKS.find((b) => b.id === id), code)).filter(Boolean).join('\n\n');
  // Меню: «Услуги» — выбор ситуации с планом и ценой, «Консультация» — форма заявки, «Контакты» — телефон и мессенджеры в подвале.
  const nav = [['#stage', k.nav[0]], ['#contact', k.nav[1]], ['/prices/', k.nav[2]], ['#about', k.nav[3]], ['#contacts', k.nav[4]]]
    .filter(([h]) => !h.startsWith('#') || h === '#contacts' || ORDER_MAIN.includes(h.slice(1)));
  const has = (id) => ORDER_MAIN.includes(id);
  const fromSelf = SHOP.length ? j.from.replace('%', `${rub(Math.min(...SHOP.map((p) => p.price)))} ₽`) : '';
  const pageLinks = [...PAGES.filter((p) => p.inMenu && !p.hidden).map((p) => [pageHref(p, code), p.title[code] || p.title.ru]), ...SETTINGS.menu.map((m) => [m.href, m.label[code] || m.label.ru])];
  const navLinks = [...nav.map(([h, l]) => `<a href="${h}"${h === '/prices/' ? ' hreflang="ru"' : ''}>${esc(l)}</a>`), ...pageLinks.map(([h, l]) => `<a href="${esc(h)}">${esc(l)}</a>`)].join('\n');
  const data = {
    plans, wa: WA, tel: `tel:${TEL}`,
    shop: {
      products: SHOP.map((p) => ({ id: p.id, price: p.price, ready: true, ...Object.assign({}, p.t.ru, p.t[code]) })),
      s: (({ q3, less, yes, no, unsure, okTitle, okText, softText, riskTitle, riskText, anyway, next, pay, payOff, errEmail, errOffer, errPay, toPay }) => ({ q3, less, yes, no, unsure, okTitle, okText, softText, riskTitle, riskText, anyway, next, pay, payOff, errEmail, errOffer, errPay, toPay }))(k.shop),
      consentVersion: LEGAL.consentVersion
    },
    cty: { eaeu: EAEU, plans: eaeuPlans, sits: eaeuSits, baseSits: j.sits, notes: { eaeu: cty.eaeuNote, patent: cty.patentNote, other: cty.otherNote } },
    tag: j.plan, urgentTag: j.urgentTag, discuss: j.discuss, callNow: j.callNow,
    errRequired: t.errRequired, errConsent: t.errConsent, errNetwork: t.errNetwork, sending: t.sending,
    doneTitle: j.doneTitle, doneText: j.doneText, doneNo: j.doneNo, from: j.from,
    ai: { lang: code, qs: t.aiQs, def: t.aiDefault, think: t.aiThink, toLawyer: j.aiToLawyer },
    robot: '/robot/'
  };
  const ld = {
    '@context': 'https://schema.org', '@type': 'LegalService', name: `${t.brand1} ${t.brand2}`, url, telephone: TEL,
    areaServed: 'RU', address: { '@type': 'PostalAddress', addressLocality: 'Moscow', addressCountry: 'RU' },
    openingHoursSpecification: { '@type': 'OpeningHoursSpecification', dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'], opens: '09:00', closes: '19:00' },
    sameAs: [TG], inLanguage: t.code, description: t.metaDesc, logo: `${SITE}/media/emblem-224.webp`
  };
  return `<!doctype html>
<html lang="${t.code}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(t.metaTitle)}</title>
<meta name="description" content="${esc(t.metaDesc)}">
<link rel="canonical" href="${url}">
${alt}
<meta property="og:type" content="website">
<meta property="og:url" content="${url}">
<meta property="og:title" content="${esc(t.metaTitle)}">
<meta property="og:description" content="${esc(t.metaDesc)}">
<meta property="og:locale" content="${{ ru: 'ru_RU', tg: 'tg_TJ', kk: 'kk_KZ', ky: 'ky_KG', uz: 'uz_UZ' }[code]}">
<meta property="og:image" content="${SITE}/media/themis-1240.webp">
<meta name="theme-color" content="#060606">
<meta name="format-detection" content="telephone=no">
<link rel="icon" href="/media/icon-32.png" type="image/png" sizes="32x32">
<link rel="apple-touch-icon" href="/media/icon-180.png">
${PRELOAD}
<link rel="stylesheet" href="/assets/${cssName}">
<script type="application/ld+json">${JSON.stringify(ld).replace(/</g, '\\u003c')}</script>
<script src="/assets/${globeName}" defer></script>
<script src="/assets/${jsName}" defer></script>
</head>
<body>
<a class="skip" href="#main">${esc(t.skip)}</a>
${announceBar(code)}
<div class="page">
<div class="bg" aria-hidden="true"></div>
<header class="header">
<div class="wrap header-row">
<a class="logo" href="${t.path}" aria-label="${esc(t.brand1 + ' — ' + t.brand2)}">${LOGO(56)}${LOGO_NAME}</a>
<span class="header-sep" aria-hidden="true"></span>
<nav class="nav" aria-label="${esc(t.menu)}">
${navLinks}
</nav>
<div class="header-actions">
${langMenu(code, t)}
<a class="header-phone" href="tel:${TEL}">${ICON.phone}<span>${PHONE}</span></a>
<a class="btn btn-gold shine header-call" href="tel:${TEL}" aria-label="${esc(k.call)} ${PHONE}">${ICON.phone}<span>${esc(k.call)}</span></a>
<button type="button" class="menu-btn" aria-expanded="false" aria-controls="mnav" aria-label="${esc(k.menu)}">${ICON.burger}${ICON.close}</button>
</div>
</div>
<nav class="mnav" id="mnav" aria-label="${esc(t.menu)}" hidden>
<div class="wrap">
${navLinks}
<a class="btn btn-gold mnav-call" href="tel:${TEL}">${esc(k.call)} · ${PHONE}</a>
</div>
</nav>
</header>

<main id="main">
<section class="hero">
<div class="aurora" aria-hidden="true"><i></i><i></i><i></i></div>
<div class="wrap hero-row">
<div class="hero-text">
<h1 class="h1 in">${gold(k.h1)}</h1>
<p class="lead in in2">${esc(k.lead)}</p>
<ul class="perks in in3">${k.perks.map((x, i) => `<li>${svg(PERK_ICONS[i], 30, 1.5)}<span>${esc(x)}</span></li>`).join('')}</ul>
<div class="acts in in4" id="services">
${has('contact') ? `<a class="btn btn-gold btn-xl shine act-main" href="#contact">${esc(k.ctaMain)}${ICON.arrow}</a>` : `<a class="btn btn-gold btn-xl shine act-main" href="tel:${TEL}">${esc(k.call)}${ICON.arrow}</a>`}
${has('self') && SHOP.length ? `<a class="act act-self" href="#self"><span class="act-top"><b>${esc(k.shop.title.join(''))}</b><span class="act-price" data-from>${esc(fromSelf)}</span></span><span class="act-x">${esc(k.acts.selfText)}</span><span class="act-go">${esc(k.acts.selfBtn)}${ICON.arrow}</span></a>` : ''}
${has('stage') ? `<a class="act act-stage" href="#stage"><span class="act-top"><b>${esc(k.ctaStage)}</b>${ICON.calendar}</span><span class="act-x">${esc(k.acts.stageText)}</span><span class="act-go act-go-ic">${ICON.arrow}</span></a>` : ''}
</div>
</div>
<div class="hero-art" aria-hidden="true">
<div class="hero-halo"></div>
<canvas class="globe" width="760" height="760"></canvas>
</div>
</div>
<svg class="hero-line" viewBox="0 0 1440 70" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="hl" x1="0" x2="1"><stop offset="0" stop-color="#E2B865" stop-opacity="0"/><stop offset=".4" stop-color="#F7DFA6" stop-opacity=".9"/><stop offset=".68" stop-color="#E2B865" stop-opacity=".55"/><stop offset=".88" stop-color="#5CE1E6" stop-opacity=".7"/><stop offset="1" stop-color="#5CE1E6" stop-opacity="0"/></linearGradient><filter id="hlb"><feGaussianBlur stdDeviation="5"/></filter></defs><path class="flick" d="M0 58C380 58 620 22 1440 14" stroke="url(#hl)" stroke-width="6" fill="none" filter="url(#hlb)"/><path d="M0 58C380 58 620 22 1440 14" stroke="url(#hl)" stroke-width="1.4" fill="none"/></svg>
</section>

${sec('ai', `<section id="ai" class="wrap section">
<div class="ai-card">
<div class="spot" aria-hidden="true"></div>
<div class="ai-row">
<div class="ai-left">
<h2 class="ai-title">Migrant AI</h2>
<p class="ai-text">${esc(k.aiText)}</p>
<div class="ai-chips">${k.aiChips.map((q) => `<button type="button" class="ai-chip">${esc(q)}</button>`).join('')}</div>
<div class="ai-log" aria-live="polite"></div>
<form class="ai-form" role="search">
<label class="sr-only" for="ai-q">${esc(k.aiPh)}</label>
<input id="ai-q" name="q" type="text" placeholder="${esc(k.aiPh)}" autocomplete="off" maxlength="300">
<button type="submit" class="ai-send">${esc(k.aiAsk)}</button>
</form>
<p class="ai-note">${esc(j.aiNote)}</p>
</div>
<div class="ai-right">
<div class="ai-loader" aria-hidden="true"><span class="loader"></span></div>
<div class="robot-slot" data-title="${esc(k.aiRobot)}"></div>
</div>
</div>
</div>
</section>`)}

${sec('stage', `<section id="stage" class="wrap section stage">
<div class="sec-head">
<div><p class="eyebrow">${esc(k.stageEyebrow)}</p><h2 class="h2">${gold(k.stageTitle)}</h2></div>
<p class="sec-sub">${esc(k.stageSub)}</p>
</div>
${ctyHtml}
<div class="picker">
<div class="sits">
<p class="sr-only" id="sits-label">${esc(j.iHave)}</p>
<div class="sits-list" role="radiogroup" aria-labelledby="sits-label">
${sits}
</div>
</div>
<article class="plan${cur.urgent ? ' is-urgent' : ''}" id="plan" aria-live="polite">
<div class="plan-in">
<div class="plan-head">
<div><p class="plan-tag">${esc(j.plan)}</p><h3 class="plan-title">${esc(cur.title)}</h3></div>
<div class="plan-cost"><p>${esc(j.cost)}</p><p class="plan-price">${esc(cur.price)}</p></div>
</div>
<p class="plan-lead">${esc(cur.lead)}</p>
<ol class="plan-steps">${cur.steps.map((s, i) => `<li><b>${i + 1}</b><span>${esc(s)}</span></li>`).join('')}</ol>
<p class="plan-bring">${ICON.bag}<span><b>${esc(j.bringLabel)}</b> <span class="plan-bring-v">${esc(cur.bring)}</span></span></p>
<div class="plan-actions">
<a class="btn btn-gold shine plan-cta" href="#contact">${esc(j.discuss)}</a>
<a class="btn btn-line" href="${WA}" rel="noopener" target="_blank">${esc(j.wa)}</a>
<a class="plan-all" href="/prices/" hreflang="ru">${esc(j.priceAll.replace('107', String(SERVICES_TOTAL)))} →</a>
</div>
</div>
</article>
</div>
<p class="price-note">${esc(j.priceNote)}</p>
</section>`)}

${sec('contact', `<section id="contact" class="wrap section contact">
<div class="contact-card">
<div class="contact-text">
<p class="eyebrow">${esc(k.ctEyebrow)}</p>
<h2 class="h2">${gold([k.ctTitle[0], k.ctTitle[1], ''])}</h2>
<p>${esc(j.ctText)}</p>
<a class="contact-phone" href="tel:${TEL}">${PHONE}</a>
<p class="hours">${esc(j.hours)}</p>
<div class="pills">
<a class="pill" href="${WA}" rel="noopener" target="_blank">WhatsApp</a>
<a class="pill" href="${TG}" rel="noopener" target="_blank">Telegram</a>
${LEGAL.email ? `<a class="pill" href="mailto:${esc(LEGAL.email)}">${esc(LEGAL.email)}</a>` : ''}
</div>
</div>
<div class="form-slot">
<form class="form" action="/api/lead" method="post" novalidate>
<input type="hidden" name="lang" value="${t.code}">
<input type="hidden" name="stage" value="${cur.stage}">
<input type="hidden" name="country" value="${country}">
<label class="field">${esc(j.fSit)}<input type="text" name="situation" value="${esc(cur.title)}" readonly tabindex="-1"></label>
<label class="field">${esc(j.fName)}<input type="text" name="name" autocomplete="name" maxlength="80" required></label>
<label class="field">${esc(j.fContact)}<input type="text" name="contact" autocomplete="tel" inputmode="tel" maxlength="80" required></label>
<label class="field">${esc(j.fMsg)}<textarea name="message" rows="3" maxlength="1000" placeholder="${esc(j.fMsgPh)}"></textarea></label>
<label class="hp" aria-hidden="true">Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
<input type="hidden" name="consent_version" value="${esc(LEGAL.consentVersion)}">
<div class="check-box">
<label class="check"><input type="checkbox" name="consent" value="yes" required><span>${esc(t.cbBefore)}<a href="/legal/consent/" target="_blank" hreflang="ru">${esc(t.cbLink)}</a>${esc(t.cbAfter)}</span></label>
<p class="consent">${esc(t.policyNote)}<a href="/legal/privacy/" target="_blank" hreflang="ru">${esc(t.policyLink)}</a>${esc(t.docsRu)}</p>
</div>
<p class="form-error" role="alert"></p>
<button type="submit" class="btn btn-gold shine submit">${esc(j.fSubmit)}</button>
</form>
</div>
</div>
</section>`)}

${sec('self', shopSection(code))}

${sec('how', `<section id="how" class="wrap section how">
<p class="eyebrow">${esc(k.howEyebrow)}</p>
<h2 class="h2">${gold([k.howTitle[0], k.howTitle[1], ''])}</h2>
<ol class="how-grid">
${j.how.map(([when, title, text, result], i) => `<li class="how-step"><span class="how-n" aria-hidden="true">0${i + 1}</span><span class="how-k">${esc(when)}</span><h3>${esc(title)}</h3><p>${esc(text)}</p><p class="how-get"><span>${esc(j.youGet)}</span> ${esc(result)}</p></li>`).join('\n')}
</ol>
</section>`)}

${sec('about', `<section id="about" class="wrap section about">
<div class="about-text">
<p class="eyebrow">${esc(k.aboutEyebrow)}</p>
<h2 class="h2">${gold(k.aboutTitle)}</h2>
<p>${esc(k.aboutText)}</p>
</div>
<ul class="facts" aria-label="${esc(j.factsLabel)}">
${j.facts.map(([title, sub], i) => `<li class="fact"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${FACT_ICONS[i]}"/></svg><b>${esc(title)}</b><span>${esc(sub)}</span></li>`).join('\n')}
</ul>
</section>`)}

${sec('faq', `<section id="faq" class="wrap section faq">
<h2 class="h2">${gold([k.faqTitle[0], k.faqTitle[1], ''])}</h2>
<div class="faq-list">
${j.faq.map(([q, a]) => `<details class="q"><summary>${esc(q)}<span class="plus" aria-hidden="true">+</span></summary><p>${esc(a)}</p></details>`).join('\n')}
</div>
</section>`)}
${mainSections()}
</main>

${footer(t, j.footer)}
</div>
${cookieBanner(t)}
<script type="application/json" id="page-data">${JSON.stringify(data).replace(/</g, '\\u003c')}</script>
</body>
</html>
`;
}

for (const code of ORDER) {
  const dir = new URL('.' + L[code].path, DIST);
  await mkdir(dir, { recursive: true });
  await writeFile(new URL('index.html', dir), page(code).replace(/\n{3,}/g, '\n\n'));
}
function legalPage(key) {
  const t = L.ru;
  const nav = DOC_ORDER.map((k, i) => `<a href="/legal/${k}/"${k === key ? ' aria-current="page"' : ''}>${esc(t.docs[i])}</a>`).join('');
  return subPage({ ...DOCS[key], path: `/legal/${key}/`, nav: `<nav class="doc-nav" aria-label="Документы">${nav}</nav>` });
}
// Полный прайс (на русском): 14 разделов-раскрывашек, у каждой услуги — «Спросить» в WhatsApp с готовым текстом.
function pricesPage() {
  const rub = (n) => n.toLocaleString('ru-RU').replace(/\u00a0/g, ' ');
  const ask = (name) => `${WA}?text=${encodeURIComponent(`Здравствуйте! Интересует услуга: «${name}».`)}`;
  const nav = PRICES.blocks.map((b, i) => `<a href="#b${i + 1}">${esc(b.title)}</a>`).join('');
  const html = `<p class="lead-doc">Точная цена зависит от вашей ситуации — её называют после первой консультации. Все цены указаны «от» и не являются публичной офертой (ст. 437 ГК РФ). Стоимость и объём работ закрепляются в договоре.</p>
${PRICES.blocks.map((b, i) => `<details class="pblock" id="b${i + 1}"${i === 0 ? ' open' : ''}><summary><span>${esc(b.title)}</span><small>${b.items.length}</small></summary>
<ul class="plist">${b.items.map(([n, name, price]) => `<li><span class="pname">${esc(name)}</span><span class="pprice">от ${rub(price)} ₽</span><a class="pask" href="${ask(name)}" rel="noopener" target="_blank" aria-label="Спросить в WhatsApp: ${esc(name)}">Спросить</a></li>`).join('')}</ul></details>`).join('\n')}
<p>Не нашли свою ситуацию? Позвоните <a href="tel:${TEL}">${PHONE}</a>, напишите в <a href="${TG}" rel="noopener" target="_blank">Telegram</a>, <a href="${WA}" rel="noopener" target="_blank">WhatsApp</a>${LEGAL.email ? ` или на <a href="mailto:${esc(LEGAL.email)}">${esc(LEGAL.email)}</a>` : ''}.</p>`;
  return subPage({ title: 'Цены на услуги', html, path: '/prices/', nav: `<nav class="doc-nav doc-nav-prices" aria-label="Разделы прайса">${nav}</nav>`, desc: 'Цены на услуги миграционного юриста: РВП, ВНЖ, гражданство, патент, обжалование запрета на въезд и другие — 107 услуг.' });
}
function subPage({ title, html, path, nav, desc }) {
  const t = L.ru;
  return `<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)} — ${esc(t.brand1)}</title>
<meta name="description" content="${esc(desc || `${title} сайта ${SITE.replace('https://', '')}`)}">
<link rel="canonical" href="${SITE}${path}">
<meta name="theme-color" content="#060606">
<link rel="icon" href="/media/icon-32.png" type="image/png" sizes="32x32">
<link rel="apple-touch-icon" href="/media/icon-180.png">
${PRELOAD}
<link rel="stylesheet" href="/assets/${cssName}">
<script src="/assets/${jsName}" defer></script>
</head>
<body class="doc-page">
<a class="skip" href="#main">${esc(t.skip)}</a>
<div class="page">
<div class="bg" aria-hidden="true"></div>
<header class="header doc-header"><div class="wrap header-row">
<a class="logo" href="/" aria-label="${esc(t.brand1 + ' — ' + t.brand2)}">${LOGO(44)}${LOGO_NAME}</a>
<a class="btn btn-line doc-back" href="/">← На главную</a>
</div></header>
<main id="main" class="wrap doc">
${nav}
<article class="doc-body">
<h1>${esc(title)}</h1>
${html}
</article>
</main>
${footer(t, t.j.footer)}
</div>
${cookieBanner(t)}
</body>
</html>
`;
}
function customPage(p, code) {
  const t = L[code];
  const title = p.title[code] || p.title.ru;
  const desc = (p.desc && (p.desc[code] || p.desc.ru)) || title;
  return `<!doctype html>
<html lang="${t.code}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)} — ${esc(t.brand1)}</title>
<meta name="description" content="${esc(desc)}">
${p.noindex || p.hidden ? '<meta name="robots" content="noindex">\n' : ''}<link rel="canonical" href="${SITE}${pageHref(p, code)}">
${ORDER.map((a) => `<link rel="alternate" hreflang="${L[a].code}" href="${SITE}${pageHref(p, a)}">`).join('\n')}
<meta name="theme-color" content="#060606">
<link rel="icon" href="/media/icon-32.png" type="image/png" sizes="32x32">
<link rel="apple-touch-icon" href="/media/icon-180.png">
${PRELOAD}
<link rel="stylesheet" href="/assets/${cssName}">
<script src="/assets/${jsName}" defer></script>
</head>
<body class="doc-page cpage">
<a class="skip" href="#main">${esc(t.skip)}</a>
${announceBar(code)}
<div class="page">
<div class="bg" aria-hidden="true"></div>
<header class="header doc-header"><div class="wrap header-row">
<a class="logo" href="${t.path}" aria-label="${esc(t.brand1 + ' — ' + t.brand2)}">${LOGO(44)}${LOGO_NAME}</a>
<nav class="cpage-langs" aria-label="${esc(t.langLabel)}">${ORDER.map((a) => `<a href="${pageHref(p, a)}" hreflang="${L[a].code}"${a === code ? ' aria-current="page"' : ''}>${L[a].code.toUpperCase()}</a>`).join('')}</nav>
<a class="btn btn-gold doc-back" href="tel:${TEL}">${esc(t.k.call)}</a>
</div></header>
<main id="main">
<div class="wrap cpage-head"><h1 class="h2">${esc(title)}</h1></div>
${p.blocks.map((b) => blockHtml(b, code)).join('\n\n')}
</main>
${footer(t, t.j.footer)}
</div>
${cookieBanner(t)}
</body>
</html>
`;
}
for (const p of PAGES) for (const code of ORDER) {
  const dir = new URL(`.${pageHref(p, code)}`, DIST);
  await mkdir(dir, { recursive: true });
  await writeFile(new URL('index.html', dir), customPage(p, code));
}
for (const key of DOC_ORDER) {
  const dir = new URL(`legal/${key}/`, DIST);
  await mkdir(dir, { recursive: true });
  await writeFile(new URL('index.html', dir), legalPage(key));
}
// Страница заказа инструкции: сюда ЮKassa возвращает покупателя (?t=токен&l=язык). Статус и ссылки на файлы —
// с сервера по токену; страница одна на все языки, тексты выбираются по ?l=.
{
  const strings = Object.fromEntries(ORDER.map((c) => {
    const s = L[c].k.shop;
    return [c, { title: s.oTitle, wait: s.oWait, paid: s.oPaid, save: s.oSave, canceled: s.oCanceled, expired: s.oExpired, notFound: s.oNotFound, retry: s.oRetry, help: s.oHelp, download: s.download, order: s.order, path: L[c].path }];
  }));
  const html = `<div class="order" id="order" aria-live="polite"><p class="order-msg">Загрузка…</p></div>
<script type="application/json" id="order-data">${JSON.stringify({ strings, tel: TEL, phone: PHONE, wa: WA }).replace(/</g, '\\u003c')}</script>`;
  await mkdir(new URL('self/order/', DIST), { recursive: true });
  await writeFile(new URL('self/order/index.html', DIST), subPage({ title: 'Ваш заказ', html, path: '/self/order/', nav: '', desc: 'Статус заказа и скачивание материалов' }).replace('<head>', '<head>\n<meta name="robots" content="noindex">\n<meta name="referrer" content="no-referrer">'));
}
// Админ-панель (/admin/): страница и свои скрипт и стили; API — server/admin.mjs, доступ только по паролю.
{
  const acss = (await readFile(new URL('fonts.css', SRC), 'utf8')) + '\n' + (await readFile(new URL('admin/admin.css', SRC), 'utf8'));
  const ajs = await readFile(new URL('admin/admin.js', SRC), 'utf8');
  const acssName = `admin.${hash(acss)}.css`;
  const ajsName = `admin.${hash(ajs)}.js`;
  await writeFile(new URL(`assets/${acssName}`, DIST), acss);
  await writeFile(new URL(`assets/${ajsName}`, DIST), ajs);
  await mkdir(new URL('admin/', DIST), { recursive: true });
  await writeFile(new URL('admin/index.html', DIST), `<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<meta name="referrer" content="no-referrer">
<title>Админ-панель — Migrant-law.ru</title>
<link rel="icon" href="/media/icon-32.png" type="image/png" sizes="32x32">
<link rel="stylesheet" href="/assets/${acssName}">
<script src="/assets/${ajsName}" defer></script>
</head>
<body>
<div id="app" class="login-wrap"><p class="muted">Загрузка…</p></div>
<div id="toast" class="toast" role="status" aria-live="polite"></div>
</body>
</html>
`);
}
await mkdir(new URL('prices/', DIST), { recursive: true });
await writeFile(new URL('prices/index.html', DIST), pricesPage());
// Журнал версий согласия: точный текст каждой версии хранится в репозитории (доказательство,
// на какой текст давалось согласие), а сервер заявок получает версию и хэш действующей.
if (!PREVIEW) {
const archive = new URL(`legal-archive/consent-${LEGAL.consentVersion}.html`, ROOT);
await mkdir(new URL('legal-archive/', ROOT), { recursive: true });
let archived = null;
try { archived = await readFile(archive, 'utf8'); } catch { /* новая версия */ }
if (archived === null) await writeFile(archive, DOCS.consent.html);
else if (archived !== DOCS.consent.html && !archived.includes('[ЗАПОЛНИТЬ') && !MISSING.length) throw new Error(`Текст согласия изменился, а версия ${LEGAL.consentVersion} та же — поднимите consentVersion в src/legal.json`);
else if (archived !== DOCS.consent.html) await writeFile(archive, DOCS.consent.html);
}
await writeFile(new URL('consent-meta.json', DIST), JSON.stringify({ version: LEGAL.consentVersion, sha256: CONSENT_SHA, date: LEGAL.docsDate }));
// Справка для Migrant AI (сервер /api/ai): только то, что уже опубликовано на сайте —
// этапы, услуги с ценами «от», ответы на частые вопросы. Модель не должна выходить за её пределы.
if (!PREVIEW) {
  const r = L.ru;
  const kb = [
    'ЭТАПЫ (маршрут мигранта):',
    ...r.stT.map((t, i) => `- ${t}: ${r.stS[i]} Что делаем: ${r.stTodo[i].join('; ')}.`),
    '',
    'УСЛУГИ И ЦЕНЫ (цены «от», точная стоимость — после консультации):',
    ...r.groups.map((g, i) => `- ${g[0]} (${g[1]}): ${g[2].map((n, j) => `${n} — от ${rub(PR[i][j])} ₽`).join('; ')}.`),
    `Полный прайс: ${SITE}/prices/`,
    '',
    `ВАЖНО: ${r.eaeuNote.replace(' — эти услуги скрыты', '')}`,
    '',
    'ЧАСТЫЕ ВОПРОСЫ (как отвечает юрист):',
    ...r.aiQs.map((q) => `- ${q[0]}: ${q[1]}`),
    '',
    `КОНТАКТЫ: форма «Консультация» на сайте (${SITE}/#contact), телефон и WhatsApp ${PHONE}, Telegram ${TG}.`
  ].join('\n');
  await mkdir(new URL('build/', ROOT), { recursive: true });
  await writeFile(new URL('build/ai-knowledge.txt', ROOT), kb + '\n');
}
if (MISSING.length) console.warn('⚠ не заполнено в src/legal.json:', MISSING.join('; '));

await writeFile(new URL('robots.txt', DIST), SETTINGS.noindex ? 'User-agent: *\nDisallow: /\n' : `User-agent: *\nDisallow: /admin/\nDisallow: /self/order/\nAllow: /\nSitemap: ${SITE}/sitemap.xml\n`);
const today = new Date().toISOString().slice(0, 10);
await writeFile(new URL('sitemap.xml', DIST), `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
${ORDER.map((c) => `<url><loc>${SITE}${L[c].path}</loc><lastmod>${today}</lastmod>
${ORDER.map((a) => `<xhtml:link rel="alternate" hreflang="${L[a].code}" href="${SITE}${L[a].path}"/>`).join('\n')}
</url>`).join('\n')}
<url><loc>${SITE}/prices/</loc><lastmod>${today}</lastmod></url>
${PAGES.filter((p) => !p.noindex && !p.hidden).flatMap((p) => ORDER.map((c) => `<url><loc>${SITE}${pageHref(p, c)}</loc><lastmod>${today}</lastmod></url>`)).join('\n')}
</urlset>
`);
console.log('собрано:', ORDER.map((c) => L[c].path).join(' '), cssName, jsName);
