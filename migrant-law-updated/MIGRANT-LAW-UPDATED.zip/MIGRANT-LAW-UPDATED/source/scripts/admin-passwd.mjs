#!/usr/bin/env node
// Пароль админ-панели (/admin/). Запускать на сервере от root:
//   node scripts/admin-passwd.mjs            — придумать надёжный пароль и показать его
//   node scripts/admin-passwd.mjs 'пароль'   — задать свой (не короче 12 символов)
//   node scripts/admin-passwd.mjs 'пароль' логин — другому пользователю (по умолчанию admin). Сбрасывает 2FA и включает учётную запись.
// Хранится только хэш (scrypt) в /var/lib/sverify-admin/users.json (до первого запуска панели — auth.json); после смены все входы сбрасываются.
import { readFile, writeFile, rename, chown, stat, mkdir } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { randomBytes, scryptSync } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const FILE = process.env.AUTH_FILE || '/var/lib/sverify-admin/auth.json';
let pw = process.argv[2];
const generated = !pw;
if (generated) pw = randomBytes(12).toString('base64url');
if (pw.length < 12) { console.error('пароль — не короче 12 символов'); process.exit(1); }
const N = 32768, r = 8, p = 1;
const salt = randomBytes(16);
const hash = scryptSync(pw, salt, 32, { N, r, p, maxmem: 128 * 1024 * 1024 });
await mkdir(dirname(FILE), { recursive: true, mode: 0o755 }); // до первой выкладки каталога ещё нет — права выставит deploy.sh
const stored = `scrypt$${N}$${r}$${p}$${salt.toString('base64')}$${hash.toString('base64')}`;
const USERS = join(dirname(FILE), 'users.json');
const LOGIN = process.argv[3] || 'admin';
const doc = await readFile(USERS, 'utf8').then(JSON.parse, (e) => { if (e.code === 'ENOENT') return null; throw e; });
if (doc) {
  let u = doc.users.find((x) => x.login === LOGIN);
  if (!u) { u = { id: 'u' + randomBytes(6).toString('hex'), login: LOGIN, name: LOGIN, role: 'superadmin', createdAt: new Date().toISOString() }; doc.users.push(u); }
  u.hash = stored; delete u.totp; delete u.totpPending; u.disabled = false;
}
const target = doc ? USERS : FILE;
const tmp = target + '.tmp';
await writeFile(tmp, JSON.stringify(doc || { hash: stored, set: new Date().toISOString() }) + '\n', { mode: 0o600 });
try { const st = await stat(new URL('.', 'file://' + FILE).pathname); await chown(tmp, st.uid, st.gid); } catch { /* каталога ещё нет у пользователя — права выставит deploy.sh */ }
await rename(tmp, target);
try { execFileSync('systemctl', ['restart', 'sverify-admin'], { stdio: 'ignore' }); } catch { /* сервис ещё не установлен */ }
console.log(generated ? `Новый пароль админ-панели: ${pw}\nВход: https://sverify.online/admin/` : 'Пароль изменён. Вход: https://sverify.online/admin/');
