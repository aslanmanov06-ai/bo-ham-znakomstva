#!/usr/bin/env node
// Инструкции «Оформите документы самостоятельно»: цены, тексты, PDF и заказы — без правки кода (запускать на сервере от root).
// Изменения действуют сразу: сервер читает файлы при каждом запросе, сайт подтягивает цены при загрузке.
//   node scripts/shop-admin.mjs list                              — товары: цена, видимость, файлы
//   node scripts/shop-admin.mjs price <id> <рубли>                — новая цена (id: grazh, vnzh, rvp)
//   node scripts/shop-admin.mjs text <id> <язык> title|short "…"  — название или описание (язык: ru, tg, kk, ky, uz)
//   node scripts/shop-admin.mjs includes <id> <язык> "пункт 1|пункт 2|…" — «Что внутри»
//   node scripts/shop-admin.mjs hide <id> | show <id>             — снять с продажи / вернуть
//   node scripts/shop-admin.mjs add-file <id> <путь к файлу>      — добавить PDF или образец (выдаётся после оплаты)
//   node scripts/shop-admin.mjs rm-file <id> <имя файла>          — убрать файл
//   node scripts/shop-admin.mjs orders                            — заказы
//   node scripts/shop-admin.mjs order <№>                         — заказ полностью
//   node scripts/shop-admin.mjs relink <№>                        — новая ссылка на заказ (если покупатель её потерял); доступ — ещё 30 дней
//   node scripts/shop-admin.mjs refunded <№>                      — отметить возврат (доступ к файлам закрывается)
// Можно править и вручную: /var/lib/sverify/shop/products.json, файлы — /var/lib/sverify/shop/files/<id>/.
import { readFile, writeFile, rename, stat, chown, mkdir, copyFile, readdir, unlink } from 'node:fs/promises';
import { join, basename } from 'node:path';
import { randomBytes, createHash } from 'node:crypto';

const DIR = process.env.SHOP_DIR || '/var/lib/private/sverify/shop';
const PRODUCTS = join(DIR, 'products.json');
const ORDERS = join(DIR, 'orders.json');
const FILES = join(DIR, 'files');
const SITE = process.env.SITE_URL || 'https://sverify.online';
const LANGS = ['ru', 'tg', 'kk', 'ky', 'uz'];
const die = (m) => { console.error(m); process.exit(1); };

// Владелец — пользователь сервиса (DynamicUser): новые файлы отдаём ему, иначе сервер их не прочитает.
async function owner() { const st = await stat(DIR); return [st.uid, st.gid]; }
async function own(path) { const [u, g] = await owner(); await chown(path, u, g); }
async function save(file, obj) {
  const tmp = file + '.tmp';
  await writeFile(tmp, JSON.stringify(obj, null, 1) + '\n', { mode: 0o600 });
  await own(tmp);
  await rename(tmp, file);
}
const readJson = async (f, d) => { try { return JSON.parse(await readFile(f, 'utf8')); } catch (e) { if (e.code === 'ENOENT') return d; throw e; } };
const files = async (id) => { try { return (await readdir(join(FILES, id))).filter((f) => !f.startsWith('.')).sort(); } catch { return []; } };

try { await stat(PRODUCTS); } catch { die(`нет ${PRODUCTS} — сервер создаёт его при первом запуске (scripts/deploy.sh)`); }
const doc = await readJson(PRODUCTS, { products: [] });
const prod = (id) => doc.products.find((p) => p.id === id) || die(`нет товара ${id}. Есть: ${doc.products.map((p) => p.id).join(', ')}`);
const lang = (l) => (LANGS.includes(l) ? l : die(`язык: ${LANGS.join(', ')}`));
const [cmd, a, b, ...rest] = process.argv.slice(2);

switch (cmd) {
  case 'list':
    for (const p of doc.products) {
      const f = await files(p.id);
      console.log(`${p.id.padEnd(6)} ${String(p.price).padStart(7)} ₽  ${p.active === false ? 'скрыт' : 'в продаже'}  «${p.t?.ru?.title}»  файлов: ${f.length}${f.length ? ' — ' + f.join(', ') : ' (без файлов купить нельзя)'}`);
    }
    break;
  case 'price': {
    const n = Number(b);
    if (!Number.isInteger(n) || n < 1) die('цена — целое число рублей');
    prod(a).price = n; await save(PRODUCTS, doc); console.log(`${a}: ${n} ₽`);
    break;
  }
  case 'text': {
    const p = prod(a); const l = lang(b); const [field, ...v] = rest;
    if (!['title', 'short'].includes(field) || !v.length) die('text <id> <язык> title|short "текст"');
    p.t[l] = Object.assign({}, p.t[l], { [field]: v.join(' ') }); await save(PRODUCTS, doc); console.log('сохранено');
    break;
  }
  case 'includes': {
    const p = prod(a); const l = lang(b);
    const list = rest.join(' ').split('|').map((s) => s.trim()).filter(Boolean);
    if (!list.length) die('includes <id> <язык> "пункт 1|пункт 2"');
    p.t[l] = Object.assign({}, p.t[l], { includes: list }); await save(PRODUCTS, doc); console.log(`пунктов: ${list.length}`);
    break;
  }
  case 'hide': case 'show':
    prod(a).active = cmd === 'show'; await save(PRODUCTS, doc); console.log(`${a}: ${cmd === 'show' ? 'в продаже' : 'скрыт'}`);
    break;
  case 'add-file': {
    prod(a);
    if (!b) die('add-file <id> <путь>');
    const dir = join(FILES, a);
    await mkdir(dir, { recursive: true, mode: 0o700 }); await own(dir);
    const to = join(dir, basename(b));
    await copyFile(b, to); await own(to);
    console.log(`добавлен: ${to}`);
    break;
  }
  case 'rm-file': {
    prod(a);
    const name = basename(String(b || ''));
    if (!(await files(a)).includes(name)) die(`нет файла ${name}`);
    await unlink(join(FILES, a, name)); console.log(`удалён: ${name}`);
    break;
  }
  case 'orders': {
    const list = await readJson(ORDERS, []);
    for (const o of list) console.log(`№${o.id}  ${o.at.slice(0, 16).replace('T', ' ')}  ${o.status.padEnd(8)} ${o.product} ${o.price} ₽  ${o.email}${o.paidAt ? '  оплачен ' + o.paidAt.slice(0, 10) : ''}  скачиваний: ${o.downloads || 0}`);
    if (!list.length) console.log('заказов нет');
    break;
  }
  case 'order': case 'relink': case 'refunded': {
    const list = await readJson(ORDERS, []);
    const o = list.find((x) => String(x.id) === String(a)) || die(`нет заказа ${a}`);
    if (cmd === 'order') { console.log(JSON.stringify({ ...o, tokenHash: '(скрыт)' }, null, 2)); break; }
    if (cmd === 'refunded') { o.status = 'refunded'; o.refundedAt = new Date().toISOString(); await save(ORDERS, list); console.log(`№${o.id}: возврат отмечен, доступ закрыт`); break; }
    if (o.status !== 'paid') die(`заказ №${o.id} не оплачен (${o.status})`);
    const token = randomBytes(24).toString('hex');
    o.tokenHash = createHash('sha256').update(token).digest('hex');
    o.paidAtOriginal = o.paidAtOriginal || o.paidAt;
    o.paidAt = new Date().toISOString(); // срок доступа — 30 дней с этого момента
    o.downloads = 0;
    await save(ORDERS, list);
    console.log(`новая ссылка для №${o.id} (старая больше не работает):\n${SITE}/self/order/?t=${token}&l=${o.lang || 'ru'}`);
    break;
  }
  default:
    console.log((await readFile(new URL(import.meta.url), 'utf8')).split('\n').filter((l) => l.startsWith('//')).map((l) => l.slice(3)).join('\n'));
}
