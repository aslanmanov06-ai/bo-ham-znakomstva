#!/usr/bin/env node
// Работа с персональными данными из заявок (запускать на сервере от root).
//   node scripts/pd-admin.mjs list                 — заявки (кратко)
//   node scripts/pd-admin.mjs show <id>            — заявка полностью, с фактом согласия
//   node scripts/pd-admin.mjs find <контакт>       — заявки по телефону / нику (для ответа на запрос субъекта)
//   node scripts/pd-admin.mjs block <id>           — заблокировать (прекратить обработку)
//   node scripts/pd-admin.mjs destroy <id> [причина] — уничтожить ПДн (останется обезличенная запись)
//   node scripts/pd-admin.mjs requests             — обращения субъектов (отзыв, запросы)
//   node scripts/pd-admin.mjs request-done <id>    — отметить обращение выполненным
import { readFile, writeFile, rename, stat, chown } from 'node:fs/promises';
import { join } from 'node:path';

const DIR = process.env.DATA_DIR || '/var/lib/private/sverify';
const LEADS = join(DIR, 'leads.jsonl');
const REQUESTS = join(DIR, 'requests.jsonl');

async function read(file) {
  try { return (await readFile(file, 'utf8')).split('\n').filter(Boolean).map((l) => JSON.parse(l)); }
  catch (e) { if (e.code === 'ENOENT') return []; throw e; }
}
// Пишем атомарно и сохраняем владельца файла: сервис работает от динамического пользователя.
async function write(file, list) {
  const st = await stat(file);
  const tmp = file + '.tmp';
  await writeFile(tmp, list.map((x) => JSON.stringify(x)).join('\n') + (list.length ? '\n' : ''), { mode: 0o600 });
  await chown(tmp, st.uid, st.gid);
  await rename(tmp, file);
}
const digits = (s) => String(s || '').replace(/\D/g, '');
const norm = (s) => String(s || '').toLowerCase().replace(/[\s@+()\-]/g, '');
const same = (a, b) => (digits(a).length >= 7 && digits(b).length >= 7 ? digits(a).slice(-10) === digits(b).slice(-10) : norm(a) && norm(a) === norm(b));
const state = (l) => (l.destroyedAt ? `уничтожена ${l.destroyedAt.slice(0, 10)} (${l.destroyReason})` : l.blockedAt ? `заблокирована ${l.blockedAt.slice(0, 10)}` : 'активна');

const [cmd, arg, ...rest] = process.argv.slice(2);
const leads = await read(LEADS);
const byId = (id) => { const l = leads.find((x) => String(x.id) === String(id)); if (!l) { console.error('нет заявки', id); process.exit(1); } return l; };

switch (cmd) {
  case 'list':
    for (const l of leads) console.log(`#${l.id}  ${l.at.slice(0, 16).replace('T', ' ')}  ${state(l)}${l.destroyedAt ? '' : `  ${l.name} · ${l.contact} · ${l.stage || '-'} · ${l.country || 'страна не выбрана'} · ${l.lang}${l.message ? ' · есть описание (show)' : ''}`}`);
    if (!leads.length) console.log('заявок нет');
    break;
  case 'show':
    console.log(JSON.stringify(byId(arg), null, 2));
    break;
  case 'find':
    for (const l of leads.filter((x) => !x.destroyedAt && same(x.contact, arg))) console.log(JSON.stringify(l, null, 2));
    break;
  case 'block': {
    const l = byId(arg);
    if (!l.destroyedAt && !l.blockedAt) { l.blockedAt = new Date().toISOString(); l.blockReason = rest.join(' ') || 'по требованию субъекта'; await write(LEADS, leads); }
    console.log(`#${l.id}: ${state(l)}`);
    break;
  }
  case 'destroy': {
    const i = leads.findIndex((x) => String(x.id) === String(arg));
    if (i < 0) { console.error('нет заявки', arg); process.exit(1); }
    const l = leads[i];
    if (!l.destroyedAt) {
      leads[i] = { id: l.id, at: l.at, destroyedAt: new Date().toISOString(), destroyReason: rest.join(' ') || 'по требованию субъекта', consent: l.consent ? { version: l.consent.version, at: l.consent.at } : undefined };
      await write(LEADS, leads);
    }
    console.log(`#${l.id}: ${state(leads[i])}. Оформите акт об уничтожении ПДн (приказ РКН № 179 от 28.10.2022).`);
    break;
  }
  case 'requests':
    for (const r of await read(REQUESTS)) console.log(`№${r.id}  ${r.at.slice(0, 16).replace('T', ' ')}  ${r.kind}  ${r.status}  контакт: ${r.contact}  заявки: ${r.leads.join(', ') || 'не найдены'}${r.comment ? `  «${r.comment}»` : ''}`);
    break;
  case 'request-done': {
    const reqs = await read(REQUESTS);
    const r = reqs.find((x) => String(x.id) === String(arg));
    if (!r) { console.error('нет обращения', arg); process.exit(1); }
    r.status = 'done'; r.doneAt = new Date().toISOString();
    await write(REQUESTS, reqs);
    console.log(`обращение №${r.id} выполнено`);
    break;
  }
  default:
    console.log('команды: list | show <id> | find <контакт> | block <id> | destroy <id> [причина] | requests | request-done <id>');
}
