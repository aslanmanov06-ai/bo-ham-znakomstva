// Проверка сайта в настоящем браузере: скриншоты (компьютер и телефон) и основные сценарии.
// Запуск: node scripts/check.mjs [адрес] — по умолчанию локальная сборка из dist/ с тестовым сервером заявок.
// Нужен Playwright: путь к папке с node_modules — в переменной PLAYWRIGHT_DIR (по умолчанию ищется в известных местах).
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, mkdtemp, cp } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { extname, join } from 'node:path';
import { tmpdir } from 'node:os';
import { spawn, execFileSync } from 'node:child_process';
import { scryptSync, randomBytes } from 'node:crypto';

const PW_DIR = [process.env.PLAYWRIGHT_DIR, '/root/bo-ham-web', '/opt/node-tools', process.cwd()].find((d) => d && existsSync(join(d, 'node_modules/playwright')));
if (!PW_DIR) { console.error('Не найден Playwright: установите его (npm i playwright) и укажите папку в PLAYWRIGHT_DIR'); process.exit(1); }
const require = createRequire(join(PW_DIR, 'package.json'));
const { chromium } = require('playwright');
const ROOT = new URL('../', import.meta.url).pathname;
const OUT = join(ROOT, 'screens');
await mkdir(OUT, { recursive: true });

let base = process.argv[2];
let stop = () => {};
if (!base) {
  const dataDir = await mkdtemp(join(tmpdir(), 'sverify-'));
  // Имитация API языковой модели: на вопросы со словом «нейро» отвечает потоком, на остальные — ошибкой
  // (так проверяется и ответ модели, и запасной режим с готовыми ответами).
  const model = createServer(async (req, res) => {
    const chunks = []; for await (const c of req) chunks.push(c);
    const q = JSON.parse(Buffer.concat(chunks)).messages[1].content;
    if (!q.includes('нейро')) { res.writeHead(500); return res.end(); }
    res.writeHead(200, { 'content-type': 'text/event-stream' });
    for (const w of ['**Ответ** ', 'модели: ', 'РВП от 25 000 ₽.']) res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: w } }] })}\n\n`);
    res.end('data: [DONE]\n\n');
  }).listen(3912);
  // Имитация API ЮKassa: создание платежа, страница оплаты (/pay/<id> — «оплачивает» и возвращает на сайт), статус.
  const yk = { payments: new Map(), auth: '', idem: '', receipt: null };
  const ykSrv = createServer(async (req, res) => {
    const chunks = []; for await (const c of req) chunks.push(c);
    const u = new URL(req.url, 'http://x');
    const json = (s, o) => { res.writeHead(s, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
    if (req.method === 'POST' && u.pathname === '/v3/payments') {
      const b = JSON.parse(Buffer.concat(chunks));
      const id = 'pay-' + (yk.payments.size + 1);
      yk.auth = req.headers.authorization || ''; yk.idem = req.headers['idempotence-key'] || ''; yk.receipt = b.receipt;
      yk.payments.set(id, { id, status: 'pending', amount: b.amount, metadata: b.metadata, ret: b.confirmation.return_url });
      return json(200, { id, status: 'pending', confirmation: { type: 'redirect', confirmation_url: `http://127.0.0.1:3913/pay/${id}` } });
    }
    const m = u.pathname.match(/^\/v3\/payments\/(.+)$/);
    if (req.method === 'GET' && m) { const p = yk.payments.get(m[1]); return p ? json(200, { id: p.id, status: p.status, amount: p.amount, metadata: p.metadata }) : json(404, {}); }
    const pay = u.pathname.match(/^\/pay\/(.+)$/);
    if (pay && yk.payments.get(pay[1])) { const p = yk.payments.get(pay[1]); p.status = 'succeeded'; res.writeHead(302, { location: p.ret }); return res.end(); }
    json(404, {});
  }).listen(3913);
  globalThis.__yk = yk;
  const shopDir = join(dataDir, 'shop');
  await mkdir(join(shopDir, 'files/rvp'), { recursive: true });
  await writeFile(join(shopDir, 'files/rvp/RVP-instrukciya.pdf'), '%PDF-1.4 test');
  const lead = spawn('node', [join(ROOT, 'server/lead-server.mjs')], { env: { ...process.env, SHOP_DIR: shopDir, SHOP_DEFAULTS: join(ROOT, 'src/shop-products.json'), YK_SHOP_ID: 'test-shop', YK_SECRET_KEY: 'test-key', YK_API: 'http://127.0.0.1:3913/v3', SITE_URL: 'http://127.0.0.1:3910', PORT: '3911', INTERNAL_PORT: '3914', INTERNAL_TOKEN: 'test-internal-token-0123456789abcdef', DATA_DIR: dataDir, TELEGRAM_BOT_TOKEN: '', CONSENT_FILE: join(ROOT, 'dist/consent-meta.json'), AI_URL: 'http://127.0.0.1:3912/v1/chat/completions', AI_MODEL: 'test', AI_KNOWLEDGE: join(ROOT, 'build/ai-knowledge.txt') }, stdio: 'inherit' });
  globalThis.__dataDir = dataDir;
  // Админ-панель: копия сайта, свои каталоги правок и публикации, пароль «test-admin-password».
  const adm = join(dataDir, 'admin');
  await mkdir(join(adm, 'www'), { recursive: true });
  // Копия сайта для панели: rsync, а где его нет — средствами Node.
  const SKIP_COPY = ['.git', 'screens', 'dist', 'node_modules'];
  try { execFileSync('rsync', ['-a', ...SKIP_COPY.flatMap((x) => ['--exclude', x]), ROOT, join(adm, 'site') + '/']); }
  catch { await cp(ROOT, join(adm, 'site'), { recursive: true, filter: (src) => !SKIP_COPY.some((x) => src.replace(ROOT, '').split('/')[0] === x) }); }
  const salt = randomBytes(16);
  await writeFile(join(adm, 'auth.json'), JSON.stringify({ hash: `scrypt$16384$8$1$${salt.toString('base64')}$${scryptSync('test-admin-password', salt, 32, { N: 16384, r: 8, p: 1 }).toString('base64')}` }));
  const admin = spawn('node', [join(ROOT, 'server/admin.mjs')], { env: { ...process.env, ADMIN_PORT: '3920', ADMIN_HOME: adm, SITE_DIR: join(adm, 'site'), WWW_DIR: join(adm, 'www'), SITE_URL: 'http://127.0.0.1:3910', INTERNAL_URL: 'http://127.0.0.1:3914', INTERNAL_TOKEN: 'test-internal-token-0123456789abcdef', COOKIE_SECURE: '0' }, stdio: 'inherit' });
  globalThis.__admin = adm;
  const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.xml': 'application/xml', '.txt': 'text/plain', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.png': 'image/png', '.wasm': 'application/wasm', '.bin': 'application/octet-stream' };
  // CSP — как в deploy/sverify.online.conf: строгая для всех страниц, своя для рамки с роботом /robot/.
  const conf = await readFile(join(ROOT, 'deploy/sverify.online.conf'), 'utf8');
  const CSP = conf.match(/header @notrobot Content-Security-Policy "([^"]+)"/)[1];
  const CSP_ROBOT = conf.match(/header @robot Content-Security-Policy "([^"]+)"/)[1];
  const srv = createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x');
    if (u.pathname.startsWith('/api/')) {
      const chunks = []; for await (const c of req) chunks.push(c);
      const port = u.pathname.startsWith('/api/admin/') ? 3920 : 3911;
      const fwd = { 'content-type': req.headers['content-type'] || '' };
      for (const hname of ['cookie', 'x-admin', 'origin']) if (req.headers[hname]) fwd[hname] = req.headers[hname];
      const r = await fetch(`http://127.0.0.1:${port}` + u.pathname + u.search, { method: req.method, headers: fwd, body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks) });
      const out = { 'content-type': r.headers.get('content-type') || '' };
      if (r.headers.get('set-cookie')) out['set-cookie'] = r.headers.get('set-cookie');
      if (r.headers.get('content-security-policy')) out['content-security-policy'] = r.headers.get('content-security-policy');
      res.writeHead(r.status, out); return res.end(Buffer.from(await r.arrayBuffer()));
    }
    let p = join(ROOT, 'dist', decodeURIComponent(u.pathname));
    if (p.endsWith('/')) p += 'index.html';
    try { const b = await readFile(p); res.writeHead(200, { 'content-type': types[extname(p)] || 'application/octet-stream', 'content-security-policy': u.pathname.startsWith('/robot/') ? CSP_ROBOT : CSP }); res.end(b); }
    catch { res.writeHead(404); res.end('nf'); }
  }).listen(3910);
  base = 'http://127.0.0.1:3910';
  stop = () => { srv.close(); model.close(); ykSrv.close(); lead.kill(); admin.kill(); };
  await new Promise((r) => setTimeout(r, 400));
}

process.on('unhandledRejection', (e) => { console.error(e); stop(); process.exit(1); });
const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'] }); // WebGL для глобуса и робота
const errors = [];
const fail = (m) => { errors.push(m); console.log('✗', m); };
const ok = (m) => console.log('✓', m);

async function open(path, viewport, opts = {}) {
  const ctx = await browser.newContext({ viewport, deviceScaleFactor: 1, ...opts });
  const page = await ctx.newPage();
  page.on('console', (m) => { if (m.type() === 'error' && !/status of (422|503)/.test(m.text()) && !(path.startsWith('/admin/') && /status of (401|403|404|409)|connect-src 'none'|Refused to connect/.test(m.text()))) fail(`console ${path}: ${m.text()}`); });
  page.on('pageerror', (e) => fail(`pageerror ${path}: ${e.message}`));
  await page.goto(base + path, { waitUntil: 'networkidle' });
  return { ctx, page };
}

// 1. Компьютер и телефон, все языки: скриншоты всей страницы и ничего не вылезает за экран.
const SKIP_OVERFLOW = '.bg, .hero-art, .aurora'; // фон, свечение и глобус намеренно обрезаются краем (overflow-x: clip)
// Секции появляются при прокрутке — перед снимком всей страницы прокручиваем её до конца.
const scrollAll = async (page) => {
  const h = await page.evaluate(() => document.documentElement.scrollHeight);
  const vh = page.viewportSize().height;
  for (let y = 0; y < h; y += vh * 0.7) { await page.evaluate((v) => scrollTo(0, v), y); await page.waitForTimeout(120); }
  await page.evaluate(() => scrollTo(0, 0));
  await page.waitForTimeout(900);
};
for (const [kind, viewport, opts] of [['desktop', { width: 1440, height: 900 }, {}], ['phone', { width: 390, height: 844 }, { isMobile: true, hasTouch: true }]]) {
  for (const path of ['/', '/tj/', '/kz/', '/kg/', '/uz/']) {
    const { ctx, page } = await open(path, viewport, opts);
    await page.waitForTimeout(600);
    const ow = await page.evaluate((skip) => {
      const vw = window.innerWidth; const bad = [];
      document.querySelectorAll('body *').forEach((el) => {
        const r = el.getBoundingClientRect();
        if (r.width && r.right > vw + 1 && !el.closest(skip)) bad.push(el.className || el.tagName);
      });
      return { sw: document.documentElement.scrollWidth - vw, vw, bad: [...new Set(bad)].slice(0, 6) };
    }, SKIP_OVERFLOW);
    if (ow.vw !== viewport.width) fail(`${path} ${kind}: страница шире экрана, браузер уменьшил масштаб (${ow.vw}px)`);
    ow.sw > 0 || ow.bad.length ? fail(`${path} ${kind}: вылезает за экран ${ow.sw}px ${ow.bad.join(', ')}`) : ok(`${path} ${kind} без вылезания`);
    const name = path === '/' ? 'ru' : path.replace(/\//g, '');
    await scrollAll(page);
    await page.screenshot({ path: join(OUT, `${kind}-${name}.png`), fullPage: true });
    await ctx.close();
  }
}

// 2. Главная (компьютер): ситуация → план, цены без повторов, заявка.
{
  const { ctx, page } = await open('/', { width: 1440, height: 900 });
  const nav = await page.$$eval('.nav a', (a) => a.map((x) => x.getAttribute('href')));
  nav.join() === '#stage,#contact,/prices/,#about,#contacts' ? ok('меню: Услуги, Консультация, Цены, О нас, Контакты') : fail('меню неверное: ' + nav);
  (await page.$('#contacts .footer-phone')) && (await page.$$('#contacts .soc')).length === 3 && (await page.getAttribute('#contacts a.soc[aria-label="Telegram"]', 'href')).startsWith('https://t.me/') && (await page.getAttribute('#contacts a.soc[aria-label="WhatsApp"]', 'href')).startsWith('https://wa.me/') && !(await page.$('#contacts a.soc[aria-label="MAX"]'))
    ? ok('подвал: логотип, телефон, Telegram и WhatsApp со ссылками, MAX без выдуманной ссылки') : fail('подвал: контакты или значки мессенджеров неверные');
  (await page.getAttribute('.header-call', 'href')) === 'tel:+79771238898' && (await page.textContent('.header-phone')).includes('+7 977 123-88-98') ? ok('в шапке телефон и «Позвонить»') : fail('нет телефона или «Позвонить» в шапке');
  (await page.getAttribute('.acts .act-main', 'href')) === '#contact' && (await page.getAttribute('.acts .act-self', 'href')) === '#self' && (await page.getAttribute('.acts .act-stage', 'href')) === '#stage' ? ok('три действия первого экрана: заявка, инструкции, выбор этапа') : fail('действия первого экрана ведут не туда');
  (await page.textContent('.act-price')).replace(/\s/g, ' ').includes('25 000') ? ok('на первом экране цена инструкций «от 25 000 ₽»') : fail('нет цены инструкций на первом экране');
  !(await page.$('#services.cards, .card[data-sit]')) ? ok('отдельной строки карточек РВП / ВНЖ / гражданство больше нет') : fail('карточки РВП / ВНЖ / гражданство остались');
  {
    const ids = await page.$$eval('main > section[id]', (a) => a.map((x) => x.id));
    ids.join() === 'stage,ai,how,about,self,contact,faq' ? ok('порядок секций: этап, Migrant AI, как работаем, о нас, самостоятельно, заявка, вопросы') : fail('порядок секций неверный: ' + ids);
  }
  const frame = () => page.evaluate(() => document.querySelector('canvas.globe').toDataURL());
  const f1 = await frame(); await page.waitForTimeout(700); const f2 = await frame();
  f1 !== f2 && f1.length > 5000 ? ok('глобус нарисован и вращается') : fail('глобус не рисуется или стоит');
  const sticky = await page.evaluate(() => { scrollTo(0, 2000); return document.querySelector('.header').getBoundingClientRect().top; });
  sticky === 0 ? ok('шапка остаётся сверху при прокрутке') : fail('шапка уехала при прокрутке');
  await page.evaluate(() => scrollTo(0, 0));
  await page.click('.lang-btn');
  (await page.isVisible('#lang-menu')) ? ok('меню языков открывается') : fail('меню языков не открылось');
  await page.keyboard.press('Escape');
  (await page.isHidden('#lang-menu')) ? ok('Escape закрывает меню языков') : fail('меню языков не закрылось');

  (await page.textContent('.plan-title')).includes('временное проживание') && (await page.textContent('.plan-price')).includes('25 000') ? ok('по умолчанию план РВП, от 25 000 ₽') : fail('план по умолчанию неверный');
  const prices = await page.evaluate(() => {
    const main = document.querySelector('main').cloneNode(true);
    main.querySelector('#plan').remove();
    main.querySelector('#self').remove(); // раздел платных инструкций — свои цены
    main.querySelector('.act-price').remove(); // цена инструкций «от» на первом экране (по просьбе владельца)
    return (main.textContent.match(/₽/g) || []).length;
  });
  prices === 0 ? ok('цены на главной только в «Ваш план»') : fail(`цены повторяются вне плана: ${prices}`);

  await page.click('.sit[data-i="1"]');
  (await page.textContent('.plan-price')).includes('10 000') && (await page.inputValue('input[name=situation]')).includes('Патент') ? ok('выбор «патент»: цена и ситуация в заявке') : fail('выбор ситуации не обновил план или заявку');
  await page.click('.sit[data-i="6"]');
  const urgent = await page.evaluate(() => ({ cls: document.querySelector('#plan').classList.contains('is-urgent'), href: document.querySelector('.plan-cta').getAttribute('href') }));
  urgent.cls && urgent.href === 'tel:+79771238898' ? ok('«задержали»: красный план и кнопка звонка') : fail('срочный план не включился');
  await page.focus('.sit[data-i="6"]');
  await page.keyboard.press('ArrowDown');
  (await page.getAttribute('.sit[data-i="7"]', 'aria-checked')) === 'true' ? ok('стрелки переключают ситуацию') : fail('стрелки не работают');
  await page.evaluate(() => scrollTo(0, 0));
  await page.click('.act-stage');
  await page.waitForTimeout(1200);
  {
    const top = await page.evaluate(() => document.querySelector('.cty').getBoundingClientRect().top);
    top > 0 && top < 700 ? ok('«Найти свой этап» прокручивает к выбору страны') : fail(`выбор страны не виден после «Найти свой этап» (top=${top})`);
  }
  await page.evaluate(() => scrollTo(0, 0));
  await page.click('.act-self');
  await page.waitForTimeout(1500);
  {
    const st = await page.evaluate(() => ({ open: document.querySelector('#self-fold').open, top: document.querySelector('#self').getBoundingClientRect().top, cards: document.querySelectorAll('.shop-card').length }));
    st.open && st.top > -50 && st.top < 400 && st.cards === 3 ? ok('«Выбрать инструкцию» раскрывает раздел с тремя инструкциями (без дубликатов)') : fail('«Выбрать инструкцию» не раскрыла раздел: ' + JSON.stringify(st));
  }
  await page.evaluate(() => scrollTo(0, 0));
  await page.click('.acts .act-main');
  await page.waitForTimeout(1200);
  {
    const top = await page.evaluate(() => document.querySelector('#contact').getBoundingClientRect().top);
    top > -50 && top < 400 ? ok('«Получить консультацию» ведёт к форме заявки') : fail(`форма не видна после «Получить консультацию» (top=${top})`);
  }
  await page.click('.sit[data-i="3"]');
  (await page.textContent('.plan-price')).includes('30 000') && (await page.getAttribute('.sit[data-i="3"]', 'aria-checked')) === 'true' ? ok('ситуация «ВНЖ» открывает план ВНЖ') : fail('ситуация ВНЖ не выбрала план');
  (await page.$$('.cty-b')).length === 6 && !(await page.$('.cty-b[aria-pressed="true"]')) ? ok('на русской странице 6 стран, ни одна не выбрана') : fail('выбор страны неверный');
  await page.click('.cty-b[data-c="kz"]');
  await page.click('.sit[data-i="1"]');
  (await page.textContent('.plan-title')).includes('ЕАЭС') && (await page.inputValue('input[name=stage]')) === 'eaeu' && (await page.textContent('.cty-note')).includes('патент не нужен') ? ok('Казахстан: вместо патента — работа по договору (ЕАЭС)') : fail('для Казахстана остался патент');
  await page.click('.cty-b[data-c="tj"]');
  (await page.textContent('.plan-title')).includes('Патент') && (await page.inputValue('input[name=stage]')) === 'patent' ? ok('Таджикистан: план «Патент»') : fail('для Таджикистана нет патента');
  await page.screenshot({ path: join(OUT, 'plan-desktop.png'), clip: await page.locator('.picker').boundingBox() });

  await page.locator('#contact').scrollIntoViewIfNeeded();
  await page.click('.submit');
  (await page.textContent('.form .form-error')).length ? ok('пустая форма — ошибка') : fail('пустая форма ушла');
  await page.fill('.form input[name=name]', 'Тест Проверка');
  await page.fill('.form input[name=contact]', '+7 900 000-00-00');
  (await page.getAttribute('textarea[name=message]', 'required')) === null ? ok('поле «Коротко о ситуации» необязательное') : fail('поле описания ситуации обязательное');
  await page.fill('textarea[name=message]', 'Патент просрочен на неделю');
  (await page.isChecked('.form input[name=consent]')) ? fail('чекбокс согласия отмечен по умолчанию') : ok('чекбокс согласия не отмечен по умолчанию');
  await page.click('.submit');
  (await page.textContent('.form .form-error')).includes('согласие') && !(await page.$('.done')) ? ok('без согласия заявка не уходит') : fail('заявка ушла без согласия');
  (await page.getAttribute('.form .check a', 'href')) === '/legal/consent/' ? ok('рядом с чекбоксом ссылка на согласие') : fail('нет ссылки на согласие');
  await page.click('.cty-b[data-c="tj"]');
  await page.check('.form input[name=consent]');
  await page.click('.submit');
  await page.waitForSelector('.done', { timeout: 5000 }).then(() => ok('заявка ушла, показано «Заявка принята»')).catch(() => fail('нет подтверждения заявки'));
  (await page.textContent('.done-no').catch(() => '')).startsWith('ML-') ? ok('в подтверждении номер заявки') : fail('нет номера заявки');
  await page.screenshot({ path: join(OUT, 'contact-done.png'), clip: await page.locator('#contact').boundingBox() });
  (await page.$('a[href="mailto:Jami777@yandex.ru"]')) ? ok('e-mail в контактах') : fail('нет e-mail');
  await ctx.close();
}

// 3. Migrant AI: чат в карточке и 3D-робот в рамке /robot/.
{
  const { ctx, page } = await open('/', { width: 1440, height: 900 });
  const csp = (await page.request.get(base + '/')).headers()['content-security-policy'] || '';
  if (base.includes('127.0.0.1') || csp) !csp.includes('unsafe-eval') ? ok('на главной CSP без unsafe-eval') : fail('на главной разрешён unsafe-eval');
  await page.locator('#ai').scrollIntoViewIfNeeded();
  await page.waitForSelector('.ai-card.robot-ready', { timeout: 60000 }).then(() => ok('3D-робот загрузился')).catch(() => fail('3D-робот не загрузился'));
  const box = await page.locator('.ai-card').boundingBox();
  await page.mouse.move(box.x + 120, box.y + 120);
  await page.waitForTimeout(300);
  (await page.getAttribute('.ai-card', 'class')).includes('lit') ? ok('прожектор появляется под курсором') : fail('нет прожектора');
  const ask = async (q, want) => {
    await page.fill('#ai-q', q);
    await page.click('.ai-send');
    await page.waitForFunction((w) => [...document.querySelectorAll('.msg-bot')].pop().textContent.includes(w), want, { timeout: 8000 }).catch(() => {});
    return page.evaluate(() => [...document.querySelectorAll('.msg-bot')].pop().textContent);
  };
  (await ask('мне запретили въезд, что делать?', 'запрет')).includes('запрет') ? ok('Migrant AI: запасной ответ по ключевым словам') : fail('свободный текст не распознан');
  (await ask('хочу рвпо', 'переселен')).includes('переселен') ? ok('«рвпо» не путается с РВП') : fail('«рвпо» распознан неверно');
  if (base.includes('127.0.0.1')) {
    const t = await ask('вопрос для нейросети', 'Ответ модели');
    t.includes('Ответ модели: РВП от 25 000 ₽.') && !t.includes('**') ? ok('Migrant AI отвечает через языковую модель') : fail('нет ответа модели: ' + t);
  }
  const before = await page.$$eval('.msg-me', (m) => m.length);
  await page.click('.ai-chip');
  (await page.$$eval('.msg-me', (m) => m.length)) === before + 1 ? ok('пример вопроса отправляется кнопкой') : fail('пример вопроса не отправился');
  await page.waitForSelector('.ai-go', { timeout: 60000 }).catch(() => {}); // живая модель отвечает до ~10 с
  (await page.$('.ai-go')) ? ok('после ответа — ссылка «Обсудить с юристом»') : fail('нет перехода к юристу');
  await page.locator('.ai-card').screenshot({ path: join(OUT, 'ai-desktop.png') });
  await ctx.close();
}

// 4. Телефон: выбор ситуации показывает план.
{
  const { ctx, page } = await open('/kg/', { width: 390, height: 844 }, { isMobile: true, hasTouch: true });
  await page.click('.sit[data-i="4"]');
  await page.waitForTimeout(900);
  const top = await page.evaluate(() => document.querySelector('#plan').getBoundingClientRect().top);
  top >= -2 && top < 300 ? ok('на телефоне план прокручивается в видимую область') : fail(`план не виден после выбора (top=${top})`);
  await page.screenshot({ path: join(OUT, 'plan-phone.png') });
  await page.click('.menu-btn');
  (await page.isVisible('#mnav')) && (await page.$$eval('#mnav a', (a) => a.length)) === 6 ? ok('меню на телефоне открывается') : fail('меню на телефоне не открылось');
  await page.click('#mnav a[href="#contact"]');
  (await page.isHidden('#mnav')) ? ok('пункт меню закрывает меню') : fail('меню не закрылось');
  const w = await page.evaluate(() => document.querySelector('.ai-card').getBoundingClientRect());
  w.left >= 0 && w.right <= 390 ? ok('Migrant AI на телефоне помещается в экран') : fail('Migrant AI вылезает за экран');
  await page.locator('#ai').scrollIntoViewIfNeeded();
  await page.waitForSelector('.ai-card.robot-ready', { timeout: 60000 }).catch(() => {});
  await page.locator('.ai-card').screenshot({ path: join(OUT, 'ai-phone.png') });
  await ctx.close();
}

// 4а. Инструкции: анкета → заказ → оплата (подменная ЮKassa) → скачивание; без оплаты файл не отдаётся.
if (globalThis.__yk) {
  const { ctx, page } = await open('/', { width: 1440, height: 900 });
  const yk = globalThis.__yk;
  await page.locator('#self').scrollIntoViewIfNeeded();
  !(await page.isVisible('.shop-grid')) ? ok('раздел «Самостоятельно» свёрнут по умолчанию') : fail('раздел «Самостоятельно» не свёрнут');
  await page.click('.self-sum');
  (await page.isVisible('.shop-grid')) ? ok('раздел «Самостоятельно» раскрывается по нажатию') : fail('раздел не раскрылся');
  const cards = await page.$$eval('.shop-card:not([hidden])', (c) => c.map((x) => x.querySelector('.shop-price').textContent.replace(/\s/g, ' ')));
  cards.join() === '35 000 ₽,30 000 ₽,25 000 ₽' ? ok('три инструкции: гражданство, ВНЖ, РВП с ценами') : fail('карточки инструкций: ' + cards);
  (await page.textContent('.shop-disc')).includes('не гарантирует') ? ok('оговорка: инструкция не гарантирует результат') : fail('нет оговорки о гарантии');
  (await page.$$('.shop-card .shop-help')).length === 3 && (await page.$$('.shop-card .shop-get')).length === 3 ? ok('во всех карточках: «Бесплатная помощь юриста» и «Что я получу после оплаты?»') : fail('нет блока помощи юриста или «Что я получу»');
  {
    await page.click('.shop-card[data-p="rvp"] .shop-more');
    const n = await page.$$eval('.info-dlg[open] .shop-inc li', (l) => l.filter((x) => x.offsetHeight).length);
    const fit = await page.$eval('.info-dlg[open]', (d) => d.getBoundingClientRect().right <= innerWidth);
    await page.click('.info-dlg[open] .info-buy');
    const quiz = await page.isVisible('#shop-dlg');
    await page.click('#shop-dlg .dlg-x');
    n === 17 && fit && quiz ? ok('«Подробнее»: окно с 17 пунктами РВПО, оттуда открывается покупка') : fail(`«Подробнее»: ${n} ${fit} ${quiz}`);
  }
  {
    await page.mouse.move(0, 0); await page.waitForTimeout(400);
    const tops = await page.$$eval('.shop-buy', (b) => b.map((x) => { const c = x.closest('.shop-card'); return Math.round(x.getBoundingClientRect().top - c.getBoundingClientRect().top + c.offsetTop); }));
    new Set(tops).size === 1 ? ok('кнопки покупки выровнены по низу карточек') : fail('кнопки покупки на разной высоте: ' + tops);
  }
  (await page.getAttribute('.cmp-law .cmp-btn', 'href')) === '#contact' ? ok('«Самостоятельно или с юристом?» с переходом к консультации') : fail('нет перехода к юристу в сравнении');
  await page.locator('.shop-grid').screenshot({ path: join(OUT, 'shop-desktop.png') });
  // ВНЖ: файлов нет — оплатить нельзя, предлагается консультация.
  await page.click('.shop-buy[data-p="vnzh"]');
  await page.check('input[name=q1][value=yes]'); await page.check('input[name=q2][value=no]'); await page.check('input[name=q3][value=yes]');
  await page.click('.dlg-next'); await page.click('.res-go');
  (await page.isVisible('.co-off')) && !(await page.isVisible('.co-pay')) ? ok('без PDF инструкцию купить нельзя') : fail('товар без файлов можно оплатить');
  await page.click('#shop-dlg .dlg-x');
  // РВП: анкета с риском → «лучше с юристом».
  await page.click('.shop-buy[data-p="rvp"]');
  (await page.isDisabled('.dlg-next')) ? ok('анкета: «Далее» только после ответов') : fail('анкету можно пропустить');
  await page.check('input[name=q1][value=yes]'); await page.check('input[name=q2][value=yes]'); await page.check('input[name=q3][value=yes]');
  await page.click('.dlg-next');
  (await page.getAttribute('[data-step="result"]', 'class')).includes('is-risk') ? ok('анкета: при отказах советует юриста') : fail('анкета не заметила риск');
  await page.screenshot({ path: join(OUT, 'shop-quiz.png') });
  await page.click('.res-go');
  await page.click('.co-pay');
  (await page.textContent('.shop-form .form-error')).includes('e-mail') ? ok('без e-mail оплата не начинается') : fail('оплата без e-mail');
  await page.fill('.shop-form input[name=email]', 'buyer@example.ru');
  await page.click('.co-pay');
  (await page.textContent('.shop-form .form-error')).includes('согласие') ? ok('без согласия на ПДн оплата не начинается') : fail('оплата без согласия');
  await page.check('.shop-form input[name=consent]');
  await page.click('.co-pay');
  (await page.textContent('.shop-form .form-error')).includes('оферт') ? ok('без принятия оферты оплата не начинается') : fail('оплата без оферты');
  await page.check('.shop-form input[name=offer]');
  await page.screenshot({ path: join(OUT, 'shop-checkout.png') });
  await Promise.all([page.waitForURL(/\/self\/order\/\?t=/, { timeout: 15000 }), page.click('.co-pay')]).catch(() => {});
  const p1 = yk.payments.get('pay-1');
  p1 && p1.amount.value === '25000.00' && yk.receipt?.customer?.email === 'buyer@example.ru' && yk.receipt.items[0].payment_mode === 'full_payment' && yk.auth.startsWith('Basic ') && yk.idem ? ok('платёж ЮKassa: 25 000 ₽, чек на e-mail, ключ идемпотентности') : fail('платёж в ЮKassa создан неверно');
  await page.waitForSelector('.order-ok', { timeout: 15000 }).then(() => ok('после оплаты — страница заказа «Оплата прошла»')).catch(() => fail('страница заказа не показала оплату'));
  const href = await page.getAttribute('.order-files a', 'href').catch(() => '');
  const file = href ? await page.request.get(base + href) : null;
  file && file.status() === 200 && (await file.text()) === '%PDF-1.4 test' ? ok('PDF скачивается после оплаты') : fail('PDF не скачивается');
  (await page.evaluate(() => document.querySelector('meta[name=referrer]')?.content)) === 'no-referrer' ? ok('ссылка на заказ не уходит в Referer') : fail('нет no-referrer на странице заказа');
  await page.screenshot({ path: join(OUT, 'shop-order.png'), fullPage: true });
  // Без оплаты: заказ создан, файл не отдаётся; подделанный токен — 404; оплата через уведомление ЮKassa.
  const o2 = await (await page.request.post(base + '/api/shop/order', { data: { product: 'rvp', email: 'b2@example.ru', consent: true, offer: true, consent_version: JSON.parse(await readFile(join(ROOT, 'dist/consent-meta.json'), 'utf8')).version, lang: 'ru' } })).json();
  const denied = await page.request.get(`${base}/api/shop/file?t=${o2.token}&f=RVP-instrukciya.pdf`);
  denied.status() === 403 ? ok('до оплаты файл не скачать (403)') : fail(`файл без оплаты: ${denied.status()}`);
  (await page.request.get(`${base}/api/shop/status?t=${'0'.repeat(48)}`)).status() === 404 ? ok('чужой токен — заказ не найден') : fail('подбор токена возможен');
  (await page.request.post(base + '/api/shop/order', { data: { product: 'rvp', email: 'b3@example.ru', consent: true, lang: 'ru' } })).status() === 422 ? ok('сервер не принимает заказ без оферты') : fail('заказ без оферты принят');
  yk.payments.get('pay-2').status = 'succeeded';
  await page.request.post(base + '/api/shop/webhook', { data: { event: 'payment.succeeded', object: { id: 'pay-2' } } });
  (await (await page.request.get(`${base}/api/shop/status?t=${o2.token}`)).json()).status === 'paid' ? ok('уведомление ЮKassa → заказ оплачен (статус перепроверен в API)') : fail('уведомление об оплате не сработало');
  await ctx.close();
  const m = await open('/', { width: 390, height: 844 }, { isMobile: true, hasTouch: true });
  await m.page.locator('#self').scrollIntoViewIfNeeded();
  await m.page.click('.self-sum');
  await m.page.click('.shop-buy[data-p="rvp"]');
  const dw = await m.page.evaluate(() => { const r = document.querySelector('#shop-dlg').getBoundingClientRect(); return r.left >= 0 && r.right <= 390; });
  dw ? ok('окно покупки на телефоне помещается в экран') : fail('окно покупки шире экрана');
  await m.page.screenshot({ path: join(OUT, 'shop-phone.png') });
  await m.ctx.close();
}

// 4б. Админ-панель: вход, защита, тексты, файлы, блоки, порядок, публикация и откат, инструкции, заявки.
if (globalThis.__admin) {
  const adm = globalThis.__admin;
  const { ctx, page } = await open('/admin/', { width: 1440, height: 900 });
  const A = (method, path, data, raw) => page.evaluate(async ([m, p, d, rw]) => {
    const opts = { method: m, headers: { 'X-Admin': '1' } };
    if (rw != null) { opts.body = new Blob([rw]); } else if (d !== undefined) { opts.body = JSON.stringify(d); opts.headers['Content-Type'] = 'application/json'; }
    const r = await fetch('/api/admin' + p, opts);
    return { status: r.status, body: await r.json().catch(() => ({})) };
  }, [method, path, data, raw]);
  (await A('GET', '/texts')).status === 401 ? ok('админка: без входа — 401') : fail('админка открыта без пароля');
  await page.waitForSelector('.login input[type=password]');
  if (/admin/.test(await page.locator('.login').innerText()) || /admin/.test(await page.locator('.login input[autocomplete=username]').getAttribute('placeholder'))) fail('форма входа раскрывает логин'); else ok('форма входа не раскрывает логин');
  await page.fill('.login input[autocomplete=username]', 'admin');
  await page.fill('.login input[type=password]', 'неверный');
  await page.click('.login button');
  await page.waitForFunction(() => document.querySelector('.login-err').textContent.length > 0);
  ok('админка: неверный пароль не пускает');
  await page.fill('.login input[type=password]', 'test-admin-password');
  await page.click('.login button');
  await page.waitForSelector('.side').then(() => ok('админка: вход по паролю')).catch(() => fail('не удалось войти в админку'));
  const cookie = (await ctx.cookies()).find((c) => c.name === 'sva');
  cookie && cookie.httpOnly && cookie.sameSite === 'Strict' ? ok('сессия: cookie HttpOnly и SameSite=Strict') : fail('cookie сессии без защиты');
  const noHeader = await page.evaluate(async () => (await fetch('/api/admin/texts', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ lang: 'ru', path: 'k.lead', value: 'x' }) })).status);
  noHeader === 403 ? ok('изменения без заголовка X-Admin отклоняются (CSRF)') : fail(`CSRF-защита: ${noHeader}`);
  await page.screenshot({ path: join(OUT, 'admin-publish.png') });
  // Тексты через интерфейс.
  await page.click('.side-btn[data-tab="texts"]');
  await page.waitForSelector('.field');
  await page.click('.group >> nth=1'); // «Первый экран»
  const badge = page.locator('.field', { has: page.locator('code', { hasText: /^k\.lead$/ }) });
  await badge.locator('textarea').fill('Москва и онлайн — ТЕСТ-ПАНЕЛИ');
  await badge.locator('.btn-gold').click();
  await page.waitForSelector('.toast.show');
  await page.screenshot({ path: join(OUT, 'admin-texts.png') });
  (await A('PUT', '/texts', { lang: 'ru', path: 'k.h1', value: 'строка вместо списка' })).status === 422 ? ok('тексты: неверный формат не сохраняется') : fail('тексты: принят неверный формат');
  (await A('PUT', '/texts', { lang: 'tg', path: 'j.faq', value: [['Савол?', 'Ҷавоб.']] })).status === 200 ? ok('тексты: список вопросов можно сократить/дополнить') : fail('тексты: список не сохранился');
  // Файлы, блоки, порядок.
  (await A('PUT', '/files/Прайс 2026.pdf', undefined, '%PDF-test')).body.url === '/files/Прайс-2026.pdf' ? ok('файл загружен (имя очищено)') : fail('файл не загрузился');
  (await A('PUT', '/files/evil.html', undefined, '<script>')).status === 422 ? ok('HTML и скрипты загрузить нельзя') : fail('загружен HTML-файл');
  const block = { id: 'b-test01', style: 'card', title: { ru: 'Блок из панели', uz: 'Paneldan blok' }, text: { ru: 'Текст **жирный**\n\n- пункт' }, buttons: [{ label: { ru: 'Позвонить' }, href: 'tel:+79771238898' }], files: [{ label: { ru: 'Скачать прайс' }, href: '/files/Прайс-2026.pdf' }] };
  (await A('PUT', '/blocks', { blocks: [{ ...block, buttons: [{ label: { ru: 'x' }, href: 'javascript:alert(1)' }] }] })).status === 422 ? ok('блок со ссылкой javascript: не сохраняется') : fail('сохранён блок с javascript:');
  const order = ['stage', 'b-test01', 'ai', 'how', 'about', 'self', 'contact', 'faq'];
  (await A('PUT', '/blocks', { blocks: [block], layout: { order, hidden: ['about'] } })).status === 200 ? ok('новый блок и порядок секций сохранены') : fail('блок не сохранён');
  // Публикация.
  const pub = await A('POST', '/publish');
  pub.status === 200 ? ok('публикация прошла') : fail('публикация: ' + pub.body.error + '\n' + (pub.body.log || '').slice(-800));
  const html = await readFile(join(adm, 'www/index.html'), 'utf8').catch(() => '');
  const ids = [...html.matchAll(/<section id="([a-z0-9-]+)"/g)].map((m) => m[1]).join();
  html.includes('ТЕСТ-ПАНЕЛИ') && ids === 'stage,b-test01,ai,how,self,contact,faq' && html.includes('href="/files/Прайс-2026.pdf"') ? ok('на сайте: новый текст, блок на своём месте, «О нас» скрыт') : fail('публикация не применила правки: ' + ids);
  (await readFile(join(adm, 'www/uz/index.html'), 'utf8')).includes('Paneldan blok') ? ok('блок на узбекском — свой заголовок') : fail('перевод блока не применён');
  (await readFile(join(adm, 'www/files/Прайс-2026.pdf'), 'utf8').catch(() => '')) === '%PDF-test' ? ok('загруженный файл опубликован в /files/') : fail('файл не опубликован');
  // Вторая публикация и откат к копии.
  await new Promise((r) => setTimeout(r, 1100));
  await A('PUT', '/texts', { lang: 'ru', path: 'k.lead', value: 'ВТОРАЯ-ВЕРСИЯ' });
  await A('POST', '/publish');
  (await readFile(join(adm, 'www/index.html'), 'utf8')).includes('ВТОРАЯ-ВЕРСИЯ') ? ok('вторая публикация') : fail('вторая публикация не применилась');
  const st = (await A('GET', '/status')).body;
  const back = await A('POST', '/rollback', { id: st.releases[0] });
  back.status === 200 && (await readFile(join(adm, 'www/index.html'), 'utf8')).includes('ТЕСТ-ПАНЕЛИ') ? ok('откат к резервной копии') : fail('откат не сработал');
  // Ошибка сборки не ломает сайт.
  const pricesDoc = (await A('GET', '/prices')).body;
  const broken = JSON.parse(JSON.stringify(pricesDoc));
  broken.blocks[0].items = broken.blocks[0].items.slice(3); // убираем услуги, на которые ссылается главная
  await A('PUT', '/prices', broken);
  const bad = await A('POST', '/publish');
  bad.status === 422 && (await readFile(join(adm, 'www/index.html'), 'utf8')).includes('ТЕСТ-ПАНЕЛИ') ? ok('ошибка сборки: сайт остаётся прежним, панель показывает причину') : fail('сломанная сборка попала на сайт');
  await A('PUT', '/prices', pricesDoc);
  // Инструкции и заявки — через сервер заявок.
  const shop = (await A('GET', '/shop')).body;
  shop.doc && shop.doc.products.length === 3 ? ok('инструкции видны в панели') : fail('инструкции не загрузились');
  shop.doc.products.find((p) => p.id === 'grazh').price = 33000;
  (await A('PUT', '/shop/products', shop.doc)).status === 200 && (await (await page.request.get(base + '/api/shop/products')).json()).products.find((p) => p.id === 'grazh').price === 33000 ? ok('цена инструкции меняется сразу') : fail('цена инструкции не изменилась');
  (await A('PUT', '/shop/files/grazh/Grazhdanstvo.pdf', undefined, '%PDF-g')).status === 200 && (await (await page.request.get(base + '/api/shop/products')).json()).products.find((p) => p.id === 'grazh').ready ? ok('PDF инструкции загружен из панели') : fail('PDF инструкции не загрузился');
  const leads = (await A('GET', '/leads')).body;
  Array.isArray(leads) && leads.some((l) => String(l.name).startsWith('Тест')) ? ok('заявки видны в панели') : fail('заявки не видны');
  (await page.request.get('http://127.0.0.1:3914/leads')).status() === 403 ? ok('внутренний API без токена закрыт') : fail('внутренний API открыт');
  // Конструктор: типы блоков, страницы, настройки, предпросмотр.
  const cards = { id: 'b-cards01', type: 'cards', title: { ru: 'Карточки' }, items: [{ title: { ru: 'Раз' }, text: { ru: 'Текст раз' }, image: '' }] };
  const newPage = { id: 'p-test01', slug: 'akcii', title: { ru: 'Акции', uz: 'Aksiyalar' }, blocks: [cards], inMenu: true, hidden: false, noindex: false };
  (await A('PUT', '/pages', [{ ...newPage, slug: 'admin' }])).status === 422 ? ok('страница с занятым адресом не сохраняется') : fail('занятый адрес принят');
  (await A('PUT', '/pages', [newPage, { ...newPage, id: 'p-draft01', slug: 'chernovik', hidden: true, inMenu: false }])).status === 200 ? ok('страницы сохранены') : fail('страницы не сохранились');
  const st0 = (await A('GET', '/settings')).body.settings;
  (await A('PUT', '/settings', { ...st0, phone: '123' })).status === 422 ? ok('неверный телефон не сохраняется') : fail('неверный телефон принят');
  (await A('PUT', '/settings', { ...st0, phone: '+7 900 111-22-33', theme: { gold: '#ff0000' }, customCss: '.tst-css{color:red}', announce: { enabled: true, text: { ru: 'ОБЪЯВЛЕНИЕ' }, href: '' } })).status === 200 ? ok('настройки сохранены') : fail('настройки не сохранились');
  const pv = await A('POST', '/preview');
  pv.status === 200 ? ok('черновик собран') : fail('предпросмотр: ' + (pv.body.log || pv.body.error));
  const wwwBefore = await readFile(join(adm, 'www/index.html'), 'utf8');
  wwwBefore.includes('ОБЪЯВЛЕНИЕ') ? fail('черновик попал на сайт') : ok('предпросмотр не меняет сайт');
  const pvHtml = await page.evaluate(async () => { const r = await fetch('/api/admin/preview/chernovik/'); return { csp: r.headers.get('content-security-policy'), t: await r.text() }; });
  /connect-src 'none'/.test(pvHtml.csp) && pvHtml.t.includes('/api/admin/preview/assets/') ? ok('предпросмотр: черновик виден, запросы к API запрещены') : fail('предпросмотр: пути или CSP');
  (await page.evaluate(async () => (await fetch('/api/admin/preview/..%2F..%2Fusers.json')).status)) === 404 ? ok('предпросмотр: выход за каталог закрыт') : fail('предпросмотр: выход за каталог');
  await A('POST', '/publish');
  const home = await readFile(join(adm, 'www/index.html'), 'utf8');
  home.includes('ОБЪЯВЛЕНИЕ') && home.includes('tel:+79001112233') && home.includes('href="/akcii/"') ? ok('на сайте: контакты, объявление, пункт меню') : fail('настройки не применились');
  (await readFile(join(adm, 'www/uz/akcii/index.html'), 'utf8')).includes('Aksiyalar') ? ok('своя страница на языке') : fail('своя страница не собрана');
  (await readFile(join(adm, 'www/chernovik/index.html'), 'utf8').catch(() => '')) === '' ? ok('черновик страницы не опубликован') : fail('черновик опубликован');
  // Пользователи и роли.
  const mk = await A('POST', '/users', { login: 'manager1', name: 'М', role: 'manager', password: 'manager-password-1' });
  mk.status === 200 ? ok('пользователь создан') : fail('пользователь не создан: ' + mk.body.error);
  (await A('POST', '/users', { login: 'x1y', role: 'editor', password: 'short' })).status === 422 ? ok('короткий пароль отклонён') : fail('короткий пароль принят');
  const me = (await A('GET', '/me')).body.user;
  (await A('PUT', '/users/' + me.id, { role: 'editor' })).status === 422 ? ok('последний суперадмин защищён') : fail('можно понизить последнего суперадмина');
  const setup = (await A('POST', '/me/totp/setup')).body;
  setup.secret ? ok('2FA: ключ выдан') : fail('2FA: нет ключа');
  (await A('POST', '/me/totp/enable', { code: '000000' })).status === 422 ? ok('2FA: неверный код отклонён') : fail('2FA: принят неверный код');
  const lead1 = (await A('GET', '/leads')).body.find((l) => !l.destroyedAt && !l.blockedAt);
  (await A('PUT', '/leads/' + lead1.id, { status: 'bad', note: '' })).status === 422 ? ok('заявка: неверный статус отклонён') : fail('неверный статус принят');
  (await A('PUT', '/leads/' + lead1.id, { status: 'work', note: 'перезвонить' })).status === 200 && (await A('GET', '/leads')).body.find((l) => l.id === lead1.id).crm.note === 'перезвонить' ? ok('заявка: статус и заметка') : fail('заявка: статус не сохранён');
  const intg = (await A('GET', '/integrations')).body;
  intg.YK_SECRET_KEY && intg.YK_SECRET_KEY.value === '' ? ok('интеграции: секрет не возвращается') : fail('интеграции: секрет виден');
  (await A('GET', '/dashboard')).body.leads ? ok('сводка') : fail('нет сводки');
  (await A('GET', '/system')).body.disk ? ok('состояние сервера') : fail('нет состояния сервера');
  const aud = (await A('GET', '/audit')).body;
  aud.some((a) => a.action.includes('публикация')) && !JSON.stringify(aud).includes(lead1.contact) ? ok('журнал: действия есть, контактов клиентов нет') : fail('журнал неверный');
  const snaps = (await A('GET', '/snapshots')).body;
  await A('PUT', '/pages', []);
  (await A('POST', '/snapshots/' + snaps[0].id + '/restore')).status === 200 && (await A('GET', '/pages')).body.length === 2 ? ok('версии: восстановление') : fail('версии: не восстановилось');
  // UI-разделы открываются без ошибок.
  for (const tab of ['dash', 'builder', 'design', 'versions', 'leads', 'orders', 'users', 'audit', 'integrations', 'system', 'profile']) {
    await page.click(`.side-btn[data-tab="${tab}"]`);
    await page.waitForFunction(() => document.querySelector('#main .mhead'), null, { timeout: 15000 }).then(() => ok(`раздел ${tab}`)).catch(() => fail(`раздел ${tab} не открылся`));
    await page.screenshot({ path: join(OUT, `admin-${tab}.png`) });
  }
  await page.click('.side-btn[data-tab="builder"]');
  await page.waitForSelector('.kind[data-kind="faq"]');
  await page.waitForFunction(() => /preview/.test(document.querySelector('#pv-frame').src), null, { timeout: 30000 }).then(() => ok('конструктор: предпросмотр загружен')).catch(() => fail('конструктор: нет предпросмотра'));
  await page.click('.kind[data-kind="faq"]');
  await page.fill('input[name="block-title"]', 'Новые вопросы');
  await page.click('.b-form .btn-gold');
  await page.waitForSelector('.b-row:has-text("Новые вопросы")').then(() => ok('конструктор: блок добавлен через интерфейс')).catch(() => fail('конструктор: блок не добавлен'));
  await page.waitForTimeout(600);
  await page.screenshot({ path: join(OUT, 'admin-builder.png') });
  // Проход улучшений: файл в использовании, проверка перед публикацией, поиск, предупреждение о правках.
  (await A('PUT', '/files/used.png', undefined, 'x')).status === 200 && (await A('PUT', '/blocks', { blocks: [{ ...block, image: '/files/used.png' }] })).status === 200 ? ok('файл привязан к блоку') : fail('файл не привязан');
  (await A('DELETE', '/files/used.png')).status === 409 ? ok('используемый файл не удаляется без подтверждения') : fail('используемый файл удалён');
  const pf = (await A('POST', '/preflight', {})).body;
  pf.buildError === '' && Array.isArray(pf.untranslated) && Array.isArray(pf.missingFiles) ? ok('проверка перед публикацией') : fail('проверка перед публикацией: ' + JSON.stringify(pf).slice(0, 200));
  (await A('POST', '/translate', { lang: 'xx', strings: ['a'] })).status === 422 ? ok('перевод: неверный язык отклонён') : fail('перевод: неверный язык');
  await page.keyboard.press('Control+k');
  await page.waitForSelector('.palette input').then(() => ok('поиск по панели открывается')).catch(() => fail('поиск по панели'));
  await page.fill('.palette input', 'журнал');
  await page.keyboard.press('Enter');
  await page.waitForSelector('.side-btn.on[data-tab="audit"]').then(() => ok('поиск ведёт в раздел')).catch(() => fail('поиск не ведёт в раздел'));
  await page.click('.side-btn[data-tab="design"]');
  await page.waitForSelector('input[name="phone"]');
  await page.fill('input[name="phone"]', '+7 900 000-00-01');
  await page.click('.side-btn[data-tab="audit"]');
  await page.waitForSelector('dialog.dlg').then(() => ok('несохранённые правки: предупреждение')).catch(() => fail('нет предупреждения о правках'));
  await page.click('dialog.dlg .btn-line');
  (await page.inputValue('input[name="phone"]')) === '+7 900 000-00-01' ? ok('отмена ухода сохраняет ввод') : fail('ввод потерян');
  await page.fill('input[name="phone"]', st0.phone);
  await page.click('.mhead-act .btn-gold');
  await page.waitForTimeout(300);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForSelector('.side-toggle').then(() => ok('панель на телефоне: кнопка меню')).catch(() => fail('нет кнопки меню'));
  const over = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  over > 0 ? fail(`панель шире экрана на ${over}px`) : ok('панель на телефоне без вылезания');
  await page.screenshot({ path: join(OUT, 'admin-phone.png') });
  await page.setViewportSize({ width: 1440, height: 900 });
  // Менеджер не видит содержимое сайта и пользователей (проверка на сервере).
  await A('POST', '/logout');
  (await A('POST', '/login', { login: 'manager1', password: 'manager-password-1' })).status === 200 ? ok('вход менеджера') : fail('менеджер не вошёл');
  (await A('GET', '/users')).status === 403 && (await A('PUT', '/texts', { lang: 'ru', path: 'k.lead', value: 'x' })).status === 403 && (await A('POST', '/publish')).status === 403 ? ok('менеджеру закрыты пользователи, тексты, публикация') : fail('права менеджера не работают');
  (await A('POST', '/leads/' + lead1.id + '/destroy', {})).status === 403 ? ok('менеджер не может уничтожить данные') : fail('менеджер уничтожил данные');
  (await A('GET', '/leads')).status === 200 ? ok('менеджеру доступны заявки') : fail('менеджеру закрыты заявки');
  await A('POST', '/logout');
  (await A('GET', '/texts')).status === 401 ? ok('выход из панели') : fail('после выхода доступ остался');
  await ctx.close();
}

// 5. Документы, отзыв согласия, проверка сервера без согласия.
{
  const { ctx, page } = await open('/legal/privacy/', { width: 1440, height: 900 });
  for (const k of ['privacy', 'consent', 'cookies', 'terms', 'offer', 'requisites', 'withdraw']) {
    const r = await page.goto(base + `/legal/${k}/`);
    r.status() === 200 ? ok(`документ /legal/${k}/`) : fail(`документ /legal/${k}/ → ${r.status()}`);
  }
  await page.screenshot({ path: join(OUT, 'legal-withdraw.png'), fullPage: true });
  await page.fill('.wform input[name=contact]', '+7 900 000-00-00');
  await page.click('.wform button[type=submit]');
  await page.waitForSelector('.wdone:not([hidden])', { timeout: 5000 }).then(() => ok('обращение об отзыве принято')).catch(() => fail('обращение не принято'));
  await page.goto(base + '/legal/consent/');
  await page.screenshot({ path: join(OUT, 'legal-consent.png'), fullPage: true });
  const r = await page.evaluate(async () => (await fetch('/api/lead', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'x', contact: '1234567', lang: 'ru' }) })).status);
  r === 422 ? ok('сервер отклоняет заявку без согласия') : fail(`сервер принял заявку без согласия (${r})`);
  await ctx.close();
}
{
  const { ctx, page } = await open('/', { width: 1440, height: 900 });
  (await page.isVisible('.cookie')) ? ok('уведомление о cookie показано') : fail('нет уведомления о cookie');
  await page.click('.cookie-ok');
  await page.reload();
  (await page.isVisible('.cookie')) ? fail('уведомление о cookie показывается снова') : ok('уведомление о cookie запомнено');
  (await page.$$('.footer-docs a')).length === 7 ? ok('7 документов в подвале') : fail('в подвале не все документы');
  await page.click('.plan-all');
  await page.waitForLoadState('networkidle');
  const n = await page.$$eval('.plist li', (l) => l.length);
  n === 107 ? ok('прайс: 107 услуг') : fail(`прайс: ${n} услуг`);
  const href = await page.getAttribute('.pask', 'href');
  href.startsWith('https://wa.me/79771238898?text=') ? ok('«Спросить» ведёт в WhatsApp с текстом') : fail('ссылка «Спросить» неверная');
  await page.click('.doc-nav a[href="#b5"]');
  await page.waitForSelector('#b5 .plist', { state: 'visible', timeout: 3000 }).then(() => ok('раздел прайса раскрывается')).catch(() => fail('раздел не раскрылся'));
  await page.screenshot({ path: join(OUT, 'prices-desktop.png') });
  await ctx.close();
  const m = await open('/prices/', { width: 390, height: 844 }, { isMobile: true, hasTouch: true });
  const sw = await m.page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  sw > 0 ? fail(`прайс на телефоне шире экрана на ${sw}px`) : ok('прайс на телефоне без вылезания');
  await m.page.screenshot({ path: join(OUT, 'prices-phone.png'), fullPage: true });
  await m.ctx.close();
}
if (globalThis.__dataDir) {
  const { readFile } = await import('node:fs/promises');
  const leads = (await readFile(join(globalThis.__dataDir, 'leads.jsonl'), 'utf8')).split('\n').filter(Boolean).map((l) => JSON.parse(l));
  const c = leads[0] && leads[0].consent;
  c && c.version && c.sha256 && c.at && c.form ? ok(`согласие записано: v${c.version}, ${c.at}, форма ${c.form}`) : fail('факт согласия не записан');
  leads[0] && leads[0].stage === 'patent' ? ok('в заявке записана ситуация «патент»') : fail(`ситуация не записана: ${leads[0] && leads[0].stage}`);
  leads[0] && leads[0].country === 'tj' ? ok('страна (флаг) записана в заявку') : fail(`страна не записана: ${leads[0] && leads[0].country}`);
  leads[0] && leads[0].message === 'Патент просрочен на неделю' ? ok('описание ситуации записано в заявку') : fail(`описание не записано: ${leads[0] && leads[0].message}`);
  leads[0] && leads[0].blockedAt ? ok('после отзыва заявка заблокирована') : fail('после отзыва заявка не заблокирована');
}

await browser.close();
stop();
console.log(errors.length ? `\nОшибок: ${errors.length}` : '\nВсё в порядке');
process.exit(errors.length ? 1 : 0);
