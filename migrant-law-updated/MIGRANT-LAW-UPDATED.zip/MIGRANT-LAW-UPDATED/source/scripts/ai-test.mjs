// Проверка Migrant AI на настоящей модели: по вопросу на каждом языке и вопрос не по теме.
// Запуск: node scripts/ai-test.mjs [файл окружения, по умолчанию /etc/sverify/leads.env]
// Поднимает сервер заявок на свободном порту с ключом из файла и печатает ответы и время.
import { spawn } from 'node:child_process';
import { readFile, mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const ROOT = new URL('../', import.meta.url).pathname;
const envFile = process.argv[2] || '/etc/sverify/leads.env';
const env = Object.fromEntries((await readFile(envFile, 'utf8')).split('\n')
  .map((l) => l.trim()).filter((l) => l && !l.startsWith('#') && l.includes('='))
  .map((l) => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1).replace(/^['"]|['"]$/g, '')])
  .filter(([k]) => k.startsWith('AI_')));
const PORT = '3913';
const srv = spawn('node', [join(ROOT, 'server/lead-server.mjs')], {
  env: { ...process.env, ...env, PORT, DATA_DIR: await mkdtemp(join(tmpdir(), 'aitest-')), TELEGRAM_BOT_TOKEN: '', AI_KNOWLEDGE: join(ROOT, 'build/ai-knowledge.txt') },
  stdio: ['ignore', 'ignore', 'inherit']
});
await new Promise((r) => setTimeout(r, 600));

const QS = [
  ['ru', 'Я из Таджикистана, живу в Москве 2 года по патенту. Как получить РВП и сколько стоит помощь?'],
  ['tg', 'Ман дар Россия кор мекунам. Патентам тамом шуд, чӣ кор кунам?'],
  ['kk', 'Мен Қазақстан азаматымын. Ресейде жұмыс істеу үшін патент керек пе?'],
  ['ky', 'Мага Россияга кирүүгө тыюу салынды. Эмне кылышым керек?'],
  ['uz', 'Men Oʻzbekistondanman. Rossiya fuqaroligini olish uchun nima qilish kerak?'],
  ['ru', 'Напиши рецепт плова']
];
let bad = 0;
for (const [lang, q] of QS) {
  const t0 = Date.now();
  let first = 0, text = '';
  try {
    const r = await fetch(`http://127.0.0.1:${PORT}/api/ai`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ q, lang }) });
    if (!r.ok) throw new Error(`HTTP ${r.status} ${await r.text()}`);
    const dec = new TextDecoder();
    for await (const c of r.body) for (const p of dec.decode(c, { stream: true }).split('\n\n')) {
      if (!p.startsWith('data:')) continue;
      try { const d = JSON.parse(p.slice(5)); if (d.t) { first ||= Date.now(); text += d.t; } if (d.error) text += ' [ОБРЫВ]'; } catch { /* часть строки */ }
    }
  } catch (e) { text = `ОШИБКА: ${e.message}`; }
  if (!text || text.startsWith('ОШИБКА') || text.includes('[ОБРЫВ]')) bad++;
  console.log(`\n[${lang}] ${q}\n  первые слова: ${first ? ((first - t0) / 1000).toFixed(1) + ' с' : '—'}, всего: ${((Date.now() - t0) / 1000).toFixed(1)} с\n  ${text.trim().replace(/\n/g, '\n  ')}`);
}
srv.kill();
console.log(bad ? `\nНеудачных ответов: ${bad}` : '\nВсе ответы получены');
process.exit(bad ? 1 : 0);
