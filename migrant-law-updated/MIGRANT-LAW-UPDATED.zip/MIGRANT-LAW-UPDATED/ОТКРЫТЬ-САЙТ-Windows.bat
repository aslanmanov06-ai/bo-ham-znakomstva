@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Для просмотра сайта нужна бесплатная программа Node.js.
  echo Сейчас откроется сайт nodejs.org: нажмите зелёную кнопку LTS,
  echo установите скачанный файл ^(кнопки "Next" до конца^),
  echo затем снова дважды щёлкните этот файл.
  echo.
  start "" https://nodejs.org/
  pause
  exit /b
)
echo Сайт открывается в браузере: http://localhost:4173/
echo Чтобы остановить просмотр, закройте это окно.
node open-site.mjs
pause
