@echo off
cd /d "%~dp0"
node open-site.mjs
pause
